--
-- PostgreSQL database dump
--

\restrict yK1mJ7eyWxNZ17MTpP8tFz8Edw3LQFP7yh6dOOTNFZrTaeyCtBFC0ELj6Pg94Ib

-- Dumped from database version 16.13 (Ubuntu 16.13-0ubuntu0.24.04.1)
-- Dumped by pg_dump version 16.13 (Ubuntu 16.13-0ubuntu0.24.04.1)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- PostgreSQL database dump complete
--

\unrestrict yK1mJ7eyWxNZ17MTpP8tFz8Edw3LQFP7yh6dOOTNFZrTaeyCtBFC0ELj6Pg94Ib

