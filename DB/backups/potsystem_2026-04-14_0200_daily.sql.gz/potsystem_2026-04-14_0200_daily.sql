--
-- PostgreSQL database dump
--

\restrict 2h4FsPUy2nnSLfGk4j21taq5CksF7rN2MKL4tY9IP8QFXTlipidGCCz4Fvnyyx1

-- Dumped from database version 16.13 (Ubuntu 16.13-0ubuntu0.24.04.1)
-- Dumped by pg_dump version 16.13 (Ubuntu 16.13-0ubuntu0.24.04.1)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: aux_deciles; Type: TABLE; Schema: public; Owner: sm
--

CREATE TABLE public.aux_deciles (
    indicator character varying(50) NOT NULL,
    decile integer NOT NULL,
    upper_limit numeric(18,6),
    lower_limit numeric(18,6)
);


ALTER TABLE public.aux_deciles OWNER TO sm;

--
-- Name: aux_win_loss; Type: TABLE; Schema: public; Owner: sm
--

CREATE TABLE public.aux_win_loss (
    daynum integer NOT NULL,
    ticker character varying(20) NOT NULL,
    pred_label_20d character varying(10),
    p_win_20d numeric(18,15),
    p_loss_20d numeric(18,15),
    pred_label_50d character varying(10),
    p_win_50d numeric(18,15),
    p_loss_50d numeric(18,15)
);


ALTER TABLE public.aux_win_loss OWNER TO sm;

--
-- Name: cal; Type: TABLE; Schema: public; Owner: sm
--

CREATE TABLE public.cal (
    daynum integer NOT NULL,
    date date NOT NULL
);


ALTER TABLE public.cal OWNER TO sm;

--
-- Name: longi; Type: TABLE; Schema: public; Owner: sm
--

CREATE TABLE public.longi (
    ticker character varying(20) NOT NULL,
    daynum integer NOT NULL,
    indicator character varying(50) NOT NULL,
    value numeric(18,6)
);


ALTER TABLE public.longi OWNER TO sm;

--
-- Name: longi_grp; Type: TABLE; Schema: public; Owner: sm
--

CREATE TABLE public.longi_grp (
    group_label character varying(100) NOT NULL,
    daynum integer NOT NULL,
    indicator character varying(50) NOT NULL,
    value numeric(18,6)
);


ALTER TABLE public.longi_grp OWNER TO sm;

--
-- Name: prices; Type: TABLE; Schema: public; Owner: sm
--

CREATE TABLE public.prices (
    ticker character varying(20) NOT NULL,
    daynum integer NOT NULL,
    close numeric(18,6)
);


ALTER TABLE public.prices OWNER TO sm;

--
-- Name: stocks; Type: TABLE; Schema: public; Owner: sm
--

CREATE TABLE public.stocks (
    ticker character varying(20) NOT NULL,
    google_id character varying(100),
    name character varying(200),
    sector character varying(100),
    homeland character varying(50),
    gics character varying(100),
    link_summary character varying(500),
    link_yahoo character varying(500),
    company_website character varying(500),
    stam_note character varying(500),
    sm_ejet boolean,
    fk_analyse boolean,
    fkplus numeric(6,4),
    fkyr integer,
    oprettet date,
    valuta character varying(10),
    nper_adr numeric(10,4),
    sgrp1 character varying(50),
    protected boolean,
    sector2 character varying(100),
    check_flag character varying(50),
    exchange character varying(20),
    zone character varying(20),
    core_index character varying(20),
    yahoo2 character varying(20)
);


ALTER TABLE public.stocks OWNER TO sm;

--
-- Name: yfinance; Type: TABLE; Schema: public; Owner: sm
--

CREATE TABLE public.yfinance (
    ticker character varying(20) NOT NULL,
    fetched_date timestamp with time zone NOT NULL,
    currency character varying(10),
    previous_close numeric(18,6),
    current_price numeric(18,6),
    dividend_rate numeric(10,6),
    dividend_yield_pct numeric(10,6),
    ex_div_date date,
    pe_ttm numeric(12,4),
    pe_fwd numeric(12,4),
    ps_ttm numeric(12,4),
    profit_margin numeric(10,6),
    float_shares numeric(20,0),
    book_value numeric(12,4),
    pb numeric(12,4),
    eps_ttm numeric(12,4),
    eps_fwd numeric(12,4),
    dividend_last numeric(10,6),
    date_dividend_last date,
    target_high_price numeric(12,4),
    target_low_price numeric(12,4),
    target_mean_price numeric(12,4),
    target_median_price numeric(12,4),
    recommendation_mean numeric(6,4),
    recommendation_key character varying(20),
    number_of_analysts integer,
    revenue_total numeric(20,0),
    revenue_per_share numeric(12,4),
    free_cash_flow numeric(20,0),
    earnings_growth numeric(10,6),
    revenue_growth numeric(10,6),
    gross_margin numeric(10,6),
    ebitda_margin numeric(10,6),
    operating_margin numeric(10,6),
    trailing_peg numeric(12,4),
    full_time_employees integer
);


ALTER TABLE public.yfinance OWNER TO sm;

--
-- Data for Name: aux_deciles; Type: TABLE DATA; Schema: public; Owner: sm
--

COPY public.aux_deciles (indicator, decile, upper_limit, lower_limit) FROM stdin;
\.


--
-- Data for Name: aux_win_loss; Type: TABLE DATA; Schema: public; Owner: sm
--

COPY public.aux_win_loss (daynum, ticker, pred_label_20d, p_win_20d, p_loss_20d, pred_label_50d, p_win_50d, p_loss_50d) FROM stdin;
\.


--
-- Data for Name: cal; Type: TABLE DATA; Schema: public; Owner: sm
--

COPY public.cal (daynum, date) FROM stdin;
2152	2026-05-22
2151	2026-05-21
2150	2026-05-20
2149	2026-05-19
2148	2026-05-18
2147	2026-05-15
2146	2026-05-14
2145	2026-05-13
2144	2026-05-12
2143	2026-05-11
2142	2026-05-08
2141	2026-05-07
2140	2026-05-06
2139	2026-05-05
2138	2026-05-04
2137	2026-05-01
2136	2026-04-30
2135	2026-04-29
2134	2026-04-28
2133	2026-04-27
2132	2026-04-24
2131	2026-04-23
2130	2026-04-22
2129	2026-04-21
2128	2026-04-20
2127	2026-04-17
2126	2026-04-16
2125	2026-04-15
2124	2026-04-14
2123	2026-04-13
2122	2026-04-10
2121	2026-04-09
2120	2026-04-08
2119	2026-04-07
2118	2026-04-02
2117	2026-04-01
2116	2026-03-31
1240	2022-10-25
1239	2022-10-24
1238	2022-10-21
1237	2022-10-20
1236	2022-10-19
1235	2022-10-18
1234	2022-10-17
1233	2022-10-14
1232	2022-10-13
1231	2022-10-12
1230	2022-10-11
1229	2022-10-10
1228	2022-10-07
1227	2022-10-06
1226	2022-10-05
1225	2022-10-04
1208	2022-09-09
1207	2022-09-08
1206	2022-09-07
1205	2022-09-06
1204	2022-09-05
1203	2022-09-02
1202	2022-09-01
1201	2022-08-31
1200	2022-08-30
1199	2022-08-29
1198	2022-08-26
1197	2022-08-25
1196	2022-08-24
1195	2022-08-23
1194	2022-08-22
2115	2026-03-30
2114	2026-03-27
2113	2026-03-26
2112	2026-03-25
2111	2026-03-24
2110	2026-03-23
2109	2026-03-20
2108	2026-03-19
2107	2026-03-18
2106	2026-03-17
2105	2026-03-16
2104	2026-03-13
2103	2026-03-12
2102	2026-03-11
2101	2026-03-10
2100	2026-03-09
2099	2026-03-06
2098	2026-03-05
2097	2026-03-04
2096	2026-03-03
2095	2026-03-02
2094	2026-02-27
2093	2026-02-26
2092	2026-02-25
2091	2026-02-24
2090	2026-02-23
2089	2026-02-20
2088	2026-02-19
2087	2026-02-18
2086	2026-02-17
2085	2026-02-16
2084	2026-02-13
2083	2026-02-12
2082	2026-02-11
2081	2026-02-10
2080	2026-02-09
2079	2026-02-06
2078	2026-02-05
2077	2026-02-04
2076	2026-02-03
2075	2026-02-02
2074	2026-01-30
2073	2026-01-29
2072	2026-01-28
2071	2026-01-27
2070	2026-01-26
2069	2026-01-23
2068	2026-01-22
2067	2026-01-21
2066	2026-01-20
2065	2026-01-19
2064	2026-01-16
2063	2026-01-15
2062	2026-01-14
2061	2026-01-13
2060	2026-01-12
2059	2026-01-09
2058	2026-01-08
2057	2026-01-07
2056	2026-01-06
2055	2026-01-05
2054	2026-01-02
2053	2025-12-30
2052	2025-12-29
2051	2025-12-23
2050	2025-12-22
2049	2025-12-19
2048	2025-12-18
2047	2025-12-17
2046	2025-12-16
2045	2025-12-15
2044	2025-12-12
2043	2025-12-11
2042	2025-12-10
2041	2025-12-09
2040	2025-12-08
2039	2025-12-05
2038	2025-12-04
2037	2025-12-03
2036	2025-12-02
2035	2025-12-01
2034	2025-11-28
2033	2025-11-27
2032	2025-11-26
2031	2025-11-25
2030	2025-11-24
2029	2025-11-21
2028	2025-11-20
2027	2025-11-19
2026	2025-11-18
2025	2025-11-17
2024	2025-11-14
2023	2025-11-13
2022	2025-11-12
2021	2025-11-11
2020	2025-11-10
2019	2025-11-07
2018	2025-11-06
2017	2025-11-05
2016	2025-11-04
2015	2025-11-03
2014	2025-10-31
2013	2025-10-30
2012	2025-10-29
2011	2025-10-28
2010	2025-10-27
2009	2025-10-24
2008	2025-10-23
2007	2025-10-22
2006	2025-10-21
2005	2025-10-20
2004	2025-10-17
2003	2025-10-16
2002	2025-10-15
2001	2025-10-14
2000	2025-10-13
1999	2025-10-10
1998	2025-10-09
1997	2025-10-08
1996	2025-10-07
1995	2025-10-06
1994	2025-10-03
1993	2025-10-02
1992	2025-10-01
1991	2025-09-30
1990	2025-09-29
1989	2025-09-26
1988	2025-09-25
1987	2025-09-24
1986	2025-09-23
1985	2025-09-22
1984	2025-09-19
1983	2025-09-18
1982	2025-09-17
1981	2025-09-16
1980	2025-09-15
1979	2025-09-12
1978	2025-09-11
1977	2025-09-10
1976	2025-09-09
1975	2025-09-08
1974	2025-09-05
1973	2025-09-04
1972	2025-09-03
1971	2025-09-02
1970	2025-09-01
1969	2025-08-29
1968	2025-08-28
1967	2025-08-27
1966	2025-08-26
1965	2025-08-25
1964	2025-08-22
1963	2025-08-21
1962	2025-08-20
1961	2025-08-19
1960	2025-08-18
1959	2025-08-15
1958	2025-08-14
1957	2025-08-13
1956	2025-08-12
1955	2025-08-11
1954	2025-08-08
1953	2025-08-07
1952	2025-08-06
1951	2025-08-05
1950	2025-08-04
1949	2025-08-01
1948	2025-07-31
1947	2025-07-30
1946	2025-07-29
1945	2025-07-28
1944	2025-07-25
1943	2025-07-24
1942	2025-07-23
1941	2025-07-22
1940	2025-07-21
1939	2025-07-18
1938	2025-07-17
1937	2025-07-16
1936	2025-07-15
1935	2025-07-14
1934	2025-07-11
1933	2025-07-10
1932	2025-07-09
1931	2025-07-08
1930	2025-07-07
1929	2025-07-04
1928	2025-07-03
1927	2025-07-02
1926	2025-07-01
1925	2025-06-30
1924	2025-06-27
1923	2025-06-26
1922	2025-06-25
1921	2025-06-24
1920	2025-06-23
1919	2025-06-20
1918	2025-06-19
1917	2025-06-18
1916	2025-06-17
1915	2025-06-16
1914	2025-06-13
1913	2025-06-12
1912	2025-06-11
1911	2025-06-10
1910	2025-06-09
1909	2025-06-06
1908	2025-06-05
1907	2025-06-04
1906	2025-06-03
1905	2025-06-02
1904	2025-05-30
1903	2025-05-29
1902	2025-05-28
1901	2025-05-27
1900	2025-05-26
1899	2025-05-23
1898	2025-05-22
1897	2025-05-21
1896	2025-05-20
1895	2025-05-19
1894	2025-05-16
1893	2025-05-15
1892	2025-05-14
1891	2025-05-13
1890	2025-05-12
1889	2025-05-09
1888	2025-05-08
1887	2025-05-07
1886	2025-05-06
1885	2025-05-05
1884	2025-05-02
1883	2025-05-01
1882	2025-04-30
1881	2025-04-29
1880	2025-04-28
1879	2025-04-25
1878	2025-04-24
1877	2025-04-23
1876	2025-04-22
1875	2025-04-21
1874	2025-04-17
1873	2025-04-16
1872	2025-04-15
1871	2025-04-14
1870	2025-04-11
1869	2025-04-10
1868	2025-04-09
1867	2025-04-08
1866	2025-04-07
1865	2025-04-04
1864	2025-04-03
1863	2025-04-02
1862	2025-04-01
1861	2025-03-31
1860	2025-03-28
1859	2025-03-27
1858	2025-03-26
1857	2025-03-25
1856	2025-03-24
1855	2025-03-21
1854	2025-03-20
1853	2025-03-19
1852	2025-03-18
1851	2025-03-17
1850	2025-03-14
1849	2025-03-13
1848	2025-03-12
1847	2025-03-10
1846	2025-03-07
1845	2025-03-06
1844	2025-03-05
1843	2025-03-04
1842	2025-03-03
1841	2025-02-28
1840	2025-02-27
1839	2025-02-26
1838	2025-02-25
1837	2025-02-24
1836	2025-02-21
1835	2025-02-20
1834	2025-02-19
1833	2025-02-18
1832	2025-02-17
1831	2025-02-14
1830	2025-02-13
1829	2025-02-12
1828	2025-02-11
1827	2025-02-10
1826	2025-02-07
1825	2025-02-06
1824	2025-02-05
1823	2025-02-04
1822	2025-02-03
1821	2025-01-31
1820	2025-01-30
1819	2025-01-29
1818	2025-01-28
1817	2025-01-27
1816	2025-01-24
1815	2025-01-23
1814	2025-01-22
1813	2025-01-21
1812	2025-01-20
1811	2025-01-17
1810	2025-01-16
1809	2025-01-15
1808	2025-01-14
1807	2025-01-13
1806	2025-01-10
1805	2025-01-09
1804	2025-01-08
1803	2025-01-07
1802	2025-01-06
1801	2025-01-03
1800	2025-01-02
1799	2024-12-31
1798	2024-12-30
1797	2024-12-27
1796	2024-12-25
1795	2024-12-20
1794	2024-12-19
1793	2024-12-18
1792	2024-12-17
1791	2024-12-16
1790	2024-12-13
1789	2024-12-12
1788	2024-12-11
1787	2024-12-10
1786	2024-12-09
1785	2024-12-06
1784	2024-12-05
1783	2024-12-04
1782	2024-12-03
1781	2024-12-02
1780	2024-11-29
1779	2024-11-28
1778	2024-11-27
1777	2024-11-26
1776	2024-11-25
1775	2024-11-22
1774	2024-11-21
1773	2024-11-20
1772	2024-11-19
1771	2024-11-18
1770	2024-11-15
1769	2024-11-14
1768	2024-11-13
1767	2024-11-12
1766	2024-11-11
1765	2024-11-08
1764	2024-11-07
1763	2024-11-06
1762	2024-11-05
1761	2024-11-04
1760	2024-11-01
1759	2024-10-31
1758	2024-10-30
1757	2024-10-29
1756	2024-10-28
1755	2024-10-25
1754	2024-10-24
1753	2024-10-23
1752	2024-10-22
1751	2024-10-21
1750	2024-10-18
1749	2024-10-17
1748	2024-10-16
1747	2024-10-15
1746	2024-10-14
1745	2024-10-11
1744	2024-10-10
1743	2024-10-09
1742	2024-10-08
1741	2024-10-07
1740	2024-10-04
1739	2024-10-03
1738	2024-10-02
1737	2024-10-01
1736	2024-09-30
1735	2024-09-27
1734	2024-09-26
1733	2024-09-25
1732	2024-09-24
1731	2024-09-23
1730	2024-09-20
1729	2024-09-19
1728	2024-09-18
1727	2024-09-17
1726	2024-09-16
1725	2024-09-13
1724	2024-09-12
1723	2024-09-11
1722	2024-09-10
1721	2024-09-09
1720	2024-09-06
1719	2024-09-05
1718	2024-09-04
1717	2024-09-03
1716	2024-09-02
1715	2024-08-30
1714	2024-08-29
1713	2024-08-28
1712	2024-08-27
1711	2024-08-26
1710	2024-08-23
1709	2024-08-22
1708	2024-08-21
1707	2024-08-20
1706	2024-08-19
1705	2024-08-16
1704	2024-08-15
1703	2024-08-14
1702	2024-08-13
1701	2024-08-12
1700	2024-08-09
1699	2024-08-08
1698	2024-08-07
1697	2024-08-06
1696	2024-08-05
1695	2024-08-02
1694	2024-08-01
1693	2024-07-31
1692	2024-07-30
1691	2024-07-29
1690	2024-07-26
1689	2024-07-25
1688	2024-07-24
1687	2024-07-23
1686	2024-07-22
1685	2024-07-19
1684	2024-07-18
1683	2024-07-17
1682	2024-07-16
1681	2024-07-15
1680	2024-07-12
1679	2024-07-11
1678	2024-07-10
1677	2024-07-09
1676	2024-07-08
1675	2024-07-05
1674	2024-07-04
1673	2024-07-03
1672	2024-07-02
1671	2024-07-01
1670	2024-06-28
1669	2024-06-27
1668	2024-06-26
1667	2024-06-25
1666	2024-06-24
1665	2024-06-21
1664	2024-06-20
1663	2024-06-19
1662	2024-06-18
1661	2024-06-17
1660	2024-06-14
1659	2024-06-13
1658	2024-06-12
1657	2024-06-11
1656	2024-06-10
1655	2024-06-07
1654	2024-06-06
1653	2024-06-05
1652	2024-06-04
1651	2024-06-03
1650	2024-05-31
1649	2024-05-30
1648	2024-05-29
1647	2024-05-28
1646	2024-05-27
1645	2024-05-24
1644	2024-05-23
1643	2024-05-22
1642	2024-05-21
1641	2024-05-20
1640	2024-05-17
1639	2024-05-16
1638	2024-05-15
1637	2024-05-14
1636	2024-05-13
1635	2024-05-10
1634	2024-05-09
1633	2024-05-08
1632	2024-05-07
1631	2024-05-06
1630	2024-05-03
1629	2024-05-02
1628	2024-05-01
1627	2024-04-30
1626	2024-04-29
1625	2024-04-26
1624	2024-04-25
1623	2024-04-24
1622	2024-04-23
1621	2024-04-22
1620	2024-04-19
1619	2024-04-18
1618	2024-04-17
1617	2024-04-16
1616	2024-04-15
1615	2024-04-12
1614	2024-04-11
1613	2024-04-10
1612	2024-04-09
1611	2024-04-08
1610	2024-04-05
1609	2024-04-04
1608	2024-04-03
1607	2024-04-02
1606	2024-04-01
1605	2024-03-28
1604	2024-03-27
1603	2024-03-26
1602	2024-03-25
1601	2024-03-22
1600	2024-03-21
1599	2024-03-20
1598	2024-03-19
1597	2024-03-18
1596	2024-03-15
1595	2024-03-14
1594	2024-03-13
1593	2024-03-12
1592	2024-03-11
1591	2024-03-08
1590	2024-03-07
1589	2024-03-06
1588	2024-03-05
1587	2024-03-04
1586	2024-03-01
1585	2024-02-29
1584	2024-02-28
1583	2024-02-27
1582	2024-02-26
1581	2024-02-23
1580	2024-02-22
1579	2024-02-21
1578	2024-02-20
1577	2024-02-19
1576	2024-02-16
1575	2024-02-15
1574	2024-02-14
1573	2024-02-13
1572	2024-02-12
1571	2024-02-09
1570	2024-02-08
1569	2024-02-07
1568	2024-02-06
1567	2024-02-05
1566	2024-02-02
1565	2024-02-01
1564	2024-01-31
1563	2024-01-30
1562	2024-01-29
1561	2024-01-26
1560	2024-01-25
1559	2024-01-24
1558	2024-01-23
1557	2024-01-22
1556	2024-01-19
1555	2024-01-18
1554	2024-01-17
1553	2024-01-16
1552	2024-01-15
1551	2024-01-12
1550	2024-01-11
1549	2024-01-10
1548	2024-01-09
1547	2024-01-08
1546	2024-01-05
1545	2024-01-04
1544	2024-01-03
1543	2024-01-02
1542	2023-12-29
1541	2023-12-28
1540	2023-12-27
1539	2023-12-22
1538	2023-12-21
1537	2023-12-20
1536	2023-12-19
1535	2023-12-18
1534	2023-12-15
1533	2023-12-14
1532	2023-12-13
1531	2023-12-12
1530	2023-12-11
1529	2023-12-08
1528	2023-12-07
1527	2023-12-06
1526	2023-12-05
1525	2023-12-04
1524	2023-12-01
1523	2023-11-30
1522	2023-11-29
1521	2023-11-28
1520	2023-11-27
1519	2023-11-24
1518	2023-11-23
1517	2023-11-22
1516	2023-11-21
1515	2023-11-20
1514	2023-11-17
1513	2023-11-16
1512	2023-11-15
1511	2023-11-14
1510	2023-11-13
1509	2023-11-10
1508	2023-11-09
1507	2023-11-08
1506	2023-11-07
1505	2023-11-06
1504	2023-11-03
1503	2023-11-02
1502	2023-11-01
1501	2023-10-31
1500	2023-10-30
1499	2023-10-27
1498	2023-10-26
1497	2023-10-25
1496	2023-10-24
1495	2023-10-23
1494	2023-10-20
1493	2023-10-19
1492	2023-10-18
1491	2023-10-17
1490	2023-10-16
1489	2023-10-13
1488	2023-10-12
1487	2023-10-11
1486	2023-10-10
1485	2023-10-09
1484	2023-10-06
1483	2023-10-05
1482	2023-10-04
1481	2023-10-03
1480	2023-10-02
1479	2023-09-29
1478	2023-09-28
1477	2023-09-27
1476	2023-09-26
1475	2023-09-25
1474	2023-09-22
1473	2023-09-21
1472	2023-09-20
1471	2023-09-19
1470	2023-09-18
1469	2023-09-15
1468	2023-09-14
1467	2023-09-13
1466	2023-09-12
1465	2023-09-11
1464	2023-09-08
1463	2023-09-07
1462	2023-09-06
1461	2023-09-05
1460	2023-09-04
1459	2023-09-01
1458	2023-08-31
1457	2023-08-30
1456	2023-08-29
1455	2023-08-28
1454	2023-08-25
1453	2023-08-24
1452	2023-08-23
1451	2023-08-22
1450	2023-08-21
1449	2023-08-18
1448	2023-08-17
1447	2023-08-16
1446	2023-08-15
1445	2023-08-14
1444	2023-08-11
1443	2023-08-10
1442	2023-08-09
1441	2023-08-08
1440	2023-08-07
1439	2023-08-04
1438	2023-08-03
1437	2023-08-02
1436	2023-08-01
1435	2023-07-31
1434	2023-07-28
1433	2023-07-27
1432	2023-07-26
1431	2023-07-25
1430	2023-07-24
1429	2023-07-21
1428	2023-07-20
1427	2023-07-19
1426	2023-07-18
1425	2023-07-17
1424	2023-07-14
1423	2023-07-13
1422	2023-07-12
1421	2023-07-11
1420	2023-07-10
1419	2023-07-07
1418	2023-07-06
1417	2023-07-05
1416	2023-07-04
1415	2023-07-03
1414	2023-06-30
1413	2023-06-29
1412	2023-06-28
1411	2023-06-27
1410	2023-06-26
1409	2023-06-23
1408	2023-06-22
1407	2023-06-21
1406	2023-06-20
1405	2023-06-19
1404	2023-06-16
1403	2023-06-15
1402	2023-06-14
1401	2023-06-13
1400	2023-06-12
1399	2023-06-09
1398	2023-06-08
1397	2023-06-07
1396	2023-06-06
1395	2023-06-05
1394	2023-06-02
1393	2023-06-01
1392	2023-05-31
1391	2023-05-30
1390	2023-05-26
1389	2023-05-25
1388	2023-05-24
1387	2023-05-23
1386	2023-05-22
1385	2023-05-19
1384	2023-05-18
1383	2023-05-17
1382	2023-05-16
1381	2023-05-15
1380	2023-05-12
1379	2023-05-11
1378	2023-05-10
1377	2023-05-09
1376	2023-05-08
1375	2023-05-05
1374	2023-05-04
1373	2023-05-03
1372	2023-05-02
1371	2023-05-01
1370	2023-04-28
1369	2023-04-27
1368	2023-04-26
1367	2023-04-25
1366	2023-04-24
1365	2023-04-21
1364	2023-04-20
1363	2023-04-19
1362	2023-04-18
1361	2023-04-17
1360	2023-04-14
1359	2023-04-13
1358	2023-04-12
1357	2023-04-11
1356	2023-04-06
1355	2023-04-05
1354	2023-04-04
1353	2023-04-03
1352	2023-03-31
1351	2023-03-30
1350	2023-03-29
1349	2023-03-28
1348	2023-03-27
1347	2023-03-24
1346	2023-03-23
1345	2023-03-22
1344	2023-03-21
1343	2023-03-20
1342	2023-03-17
1341	2023-03-16
1340	2023-03-15
1339	2023-03-14
1338	2023-03-13
1337	2023-03-10
1336	2023-03-09
1335	2023-03-08
1334	2023-03-07
1333	2023-03-06
1332	2023-03-03
1331	2023-03-02
1330	2023-03-01
1329	2023-02-28
1328	2023-02-27
1327	2023-02-24
1326	2023-02-23
1325	2023-02-22
1324	2023-02-21
1323	2023-02-20
1322	2023-02-17
1321	2023-02-16
1320	2023-02-15
1319	2023-02-14
1318	2023-02-13
1317	2023-02-10
1316	2023-02-09
1315	2023-02-08
1314	2023-02-07
1313	2023-02-06
1312	2023-02-03
1311	2023-02-02
1310	2023-02-01
1309	2023-01-31
1308	2023-01-30
1307	2023-01-27
1306	2023-01-26
1305	2023-01-25
1304	2023-01-24
1303	2023-01-23
1302	2023-01-20
1301	2023-01-19
1300	2023-01-18
1299	2023-01-17
1298	2023-01-16
1297	2023-01-13
1296	2023-01-12
1295	2023-01-11
1294	2023-01-10
1293	2023-01-09
1292	2023-01-06
1291	2023-01-05
1290	2023-01-04
1289	2023-01-03
1288	2023-01-02
1287	2022-12-30
1286	2022-12-29
1285	2022-12-28
1284	2022-12-27
1283	2022-12-23
1282	2022-12-22
1281	2022-12-21
1280	2022-12-20
1279	2022-12-19
1278	2022-12-16
1277	2022-12-15
1276	2022-12-14
1275	2022-12-13
1274	2022-12-12
1273	2022-12-09
1272	2022-12-08
1271	2022-12-07
1270	2022-12-06
1269	2022-12-05
1268	2022-12-02
1267	2022-12-01
1266	2022-11-30
1265	2022-11-29
1264	2022-11-28
1263	2022-11-25
1262	2022-11-24
1261	2022-11-23
1260	2022-11-22
1259	2022-11-21
1258	2022-11-18
1257	2022-11-17
1256	2022-11-16
1255	2022-11-15
1254	2022-11-14
1253	2022-11-11
1252	2022-11-10
1251	2022-11-09
1250	2022-11-08
1249	2022-11-07
1248	2022-11-04
1247	2022-11-03
1246	2022-11-02
1245	2022-11-01
1244	2022-10-31
1243	2022-10-28
1242	2022-10-27
1241	2022-10-26
1224	2022-10-03
1223	2022-09-30
1222	2022-09-29
1221	2022-09-28
1220	2022-09-27
1219	2022-09-26
1218	2022-09-23
1217	2022-09-22
1216	2022-09-21
1215	2022-09-20
1214	2022-09-19
1213	2022-09-16
1212	2022-09-15
1211	2022-09-14
1210	2022-09-13
1209	2022-09-12
1193	2022-08-19
1192	2022-08-18
1191	2022-08-17
1190	2022-08-16
1189	2022-08-15
1188	2022-08-12
1187	2022-08-11
1186	2022-08-10
1185	2022-08-09
1184	2022-08-08
1183	2022-08-05
1182	2022-08-04
1181	2022-08-03
1180	2022-08-02
1179	2022-08-01
1178	2022-07-29
1177	2022-07-28
1176	2022-07-27
1175	2022-07-26
1174	2022-07-25
1173	2022-07-22
1172	2022-07-21
1171	2022-07-20
1170	2022-07-19
1169	2022-07-18
1168	2022-07-15
1167	2022-07-14
1166	2022-07-13
1165	2022-07-12
1164	2022-07-11
1163	2022-07-08
1162	2022-07-07
1161	2022-07-06
1160	2022-07-05
1159	2022-07-04
1158	2022-07-01
1157	2022-06-30
1156	2022-06-29
1155	2022-06-28
1154	2022-06-27
1153	2022-06-24
1152	2022-06-23
1151	2022-06-22
1150	2022-06-21
1149	2022-06-20
1148	2022-06-17
1147	2022-06-16
1146	2022-06-15
1145	2022-06-14
1144	2022-06-13
1143	2022-06-10
1142	2022-06-09
1141	2022-06-08
1140	2022-06-07
1139	2022-06-06
1138	2022-06-03
1137	2022-06-02
1136	2022-06-01
1135	2022-05-31
1134	2022-05-30
1133	2022-05-27
1132	2022-05-26
1131	2022-05-25
1130	2022-05-24
1129	2022-05-23
1128	2022-05-20
1127	2022-05-19
1126	2022-05-18
1125	2022-05-17
1124	2022-05-16
1123	2022-05-13
1122	2022-05-12
1121	2022-05-11
1120	2022-05-10
1119	2022-05-09
1118	2022-05-06
1117	2022-05-05
1116	2022-05-04
1115	2022-05-03
1114	2022-05-02
1113	2022-04-29
1112	2022-04-28
1111	2022-04-27
1110	2022-04-26
1109	2022-04-25
1108	2022-04-22
1107	2022-04-21
1106	2022-04-20
1105	2022-04-19
1104	2022-04-14
1103	2022-04-13
1102	2022-04-12
1101	2022-04-11
1100	2022-04-08
1099	2022-04-07
1098	2022-04-06
1097	2022-04-05
1096	2022-04-04
1095	2022-04-01
1094	2022-03-31
1093	2022-03-30
1092	2022-03-29
1091	2022-03-28
1090	2022-03-25
1089	2022-03-24
1088	2022-03-23
1087	2022-03-22
1086	2022-03-21
1085	2022-03-18
1084	2022-03-17
1083	2022-03-16
1082	2022-03-15
1081	2022-03-14
1080	2022-03-11
1079	2022-03-10
1078	2022-03-09
1077	2022-03-08
1076	2022-03-07
1075	2022-03-04
1074	2022-03-03
1073	2022-03-02
1072	2022-03-01
1071	2022-02-28
1070	2022-02-25
1069	2022-02-24
1068	2022-02-23
1067	2022-02-22
1066	2022-02-21
1065	2022-02-18
1064	2022-02-17
1063	2022-02-16
1062	2022-02-15
1061	2022-02-14
1060	2022-02-11
1059	2022-02-10
1058	2022-02-09
1057	2022-02-08
1056	2022-02-07
1055	2022-02-04
1054	2022-02-03
1053	2022-02-02
1052	2022-02-01
1051	2022-01-31
1050	2022-01-28
1049	2022-01-27
1048	2022-01-26
1047	2022-01-25
1046	2022-01-24
1045	2022-01-21
1044	2022-01-20
1043	2022-01-19
1042	2022-01-18
1041	2022-01-17
1040	2022-01-14
1039	2022-01-13
1038	2022-01-12
1037	2022-01-11
1036	2022-01-10
1035	2022-01-07
1034	2022-01-06
1033	2022-01-05
1032	2022-01-04
1031	2022-01-03
\.


--
-- Data for Name: longi; Type: TABLE DATA; Schema: public; Owner: sm
--

COPY public.longi (ticker, daynum, indicator, value) FROM stdin;
\.


--
-- Data for Name: longi_grp; Type: TABLE DATA; Schema: public; Owner: sm
--

COPY public.longi_grp (group_label, daynum, indicator, value) FROM stdin;
\.


--
-- Data for Name: prices; Type: TABLE DATA; Schema: public; Owner: sm
--

COPY public.prices (ticker, daynum, close) FROM stdin;
\.


--
-- Data for Name: stocks; Type: TABLE DATA; Schema: public; Owner: sm
--

COPY public.stocks (ticker, google_id, name, sector, homeland, gics, link_summary, link_yahoo, company_website, stam_note, sm_ejet, fk_analyse, fkplus, fkyr, oprettet, valuta, nper_adr, sgrp1, protected, sector2, check_flag, exchange, zone, core_index, yahoo2) FROM stdin;
^AEX	INDEXEURO:AEX	Amsterdam Exchange index	Index	NL	Index	https://finance.yahoo.com/quote/%5ECRWDSPME/	https://finance.yahoo.com/quote/%5ECRWDSPME/	\N	\N	t	\N	\N	\N	\N	\N	\N	\N	\N	Index	\N	.AS	LON	^AEX	^AEX
EMR	EMR	Emerson Electric Co	Manuf_Big	US	Indu	https://www.marketscreener.com/quote/stock/EMERSON-ELECTRIC-CO-12451/	\N	https://www.emerson.com	\N	\N	\N	0.3500	2026	\N	USD	\N	\N	\N	Manuf_Big	\N	.US	NY	^GSPC	EMR
T	T	AT&T	Telecom	US	Tele	https://www.marketscreener.com/quote/stock/AT-T-INC-14324/	\N	https://www.att.com	\N	t	\N	0.4400	2026	\N	USD	\N	\N	\N	Telecom	\N	.US	NY	^GSPC	T
^BTC	BTCUSD	Bitcoin to USD rate	Index	US	Index	https://www.marketscreener.com/quote/cryptocurrency/BITCOIN-BTC-USD-45553945/	https://finance.yahoo.com/quote/BTC-USD?p=BTC-USD&.tsrc=fin-srch	\N	\N	t	\N	\N	\N	\N	\N	\N	\N	\N	Index	\N	.US	NY	^GSPC	^BTC
^DJAFK	INDEXDJX:DJAFK	Dow Jones Africa Titans 50 Index	Index	Sydafrika	Index	https://www.marketscreener.com/quote/index/DOW-JONES-AFRICA-TITANS-5-3966403/	https://finance.yahoo.com/quote/%5EDJAFK?p=^DJAFK&.tsrc=fin-srch	\N	\N	t	\N	\N	\N	\N	\N	\N	\N	\N	Index	\N	.JO	Other	^DJAFK	^DJAFK
^FCHI	INDEXEURO:PX1	Paris: CAC 40	Index	FR	Index	https://finance.yahoo.com/quote/%5EFCHI?p=^FCHI	https://finance.yahoo.com/quote/%5EFCHI?p=^FCHI	\N	\N	t	\N	\N	\N	\N	\N	\N	\N	\N	Index	\N	.PA	LON	^FCHI	^FCHI
^FTSE	UKX	London: Fin. Times 100	Index	UK	Index	https://finance.yahoo.com/quote/%5EFTSE?p=^FTSE	https://finance.yahoo.com/quote/%5EFTSE?p=^FTSE	\N	\N	t	\N	\N	\N	\N	\N	\N	\N	\N	Index	\N	.L	LON	^FTSE	^FTSE
^GDAXI	INDEXDB:DAX	Frankfurt: DAX	Index	DE	Index	https://finance.yahoo.com/quote/%5EGDAXI?p=^GDAXI	https://finance.yahoo.com/quote/%5EGDAXI?p=^GDAXI	\N	\N	t	\N	\N	\N	\N	\N	\N	\N	\N	Index	\N	.DE	LON	^GDAXI	^GDAXI
^GSPC	INDEXSP:.INX	NewYork: S&P 500	Index	US	Index	https://www.marketscreener.com/quote/index/S-P-500-4985/	https://finance.yahoo.com/quote/%5EGSPC?p=^GSPC&.tsrc=fin-srch	\N	CSPX.L tracker (USD,Acc), se denne for flere alternativer	t	\N	\N	\N	\N	\N	\N	\N	\N	Index	\N	.US	NY	^GSPC	^GSPC
ZG	ZG	Zillow	TechToCons	US	Tech	https://www.marketscreener.com/quote/stock/ZILLOW-GROUP-INC-20814107/	\N	https://www.zillowgroup.com	Buy & sell houses	\N	\N	0.4700	2026	\N	USD	\N	\N	\N	TechToCons	\N	.US	NY	^GSPC	ZG
^HSI	INDEXHANGSENG:HSI	Hongkong: Hang Seng	Index	China	Index	https://www.marketscreener.com/quote/index/HONG-KONG-HANG-SENG-101835/	https://finance.yahoo.com/quote/%5EHSI/	\N	CNYA.L og FXC.L er relevante	t	\N	\N	\N	\N	\N	\N	\N	\N	Index	\N	.HK	HKG	^HSI	^HSI
^IXIC	INDEXNASDAQ:.IXIC	Nasdaq Commposite	Index	US	Index	https://finance.yahoo.com/quote/%5EIXIC?p=^IXIC	https://finance.yahoo.com/quote/%5EIXIC?p=^IXIC	\N	Mere end 3000 aktier på NASDAQ	t	\N	\N	\N	\N	\N	\N	\N	\N	Index	\N	.US	NY	^GSPC	^IXIC
^OMX	INDEXNASDAQ:OMXS30	Stockholm S30	Index	SE	Index	https://finance.google.com/finance?q=INDEXNASDAQ%3AOMXS30&ei=o-WXWoiINI3isAH9q6DIBQ	https://finance.google.com/finance?q=INDEXNASDAQ%3AOMXS30&ei=o-WXWoiINI3isAH9q6DIBQ	\N	\N	t	\N	\N	\N	\N	\N	\N	\N	\N	Index	\N	.ST	LON	^OMX	^OMX
^OMXC20	INDEXNASDAQ:OMXC20	Copenhagen C20	Index	DK	Index	https://finance.google.com/finance?q=INDEXNASDAQ%3AOMXC20&ei=huWXWoj2OczWswGU75bIDQ	https://finance.google.com/finance?q=INDEXNASDAQ%3AOMXC20&ei=huWXWoj2OczWswGU75bIDQ	\N	\N	t	\N	\N	\N	\N	\N	\N	\N	\N	Index	\N	.CO	LON	^OMXC20	^OMXC20
^OSEBX	\N	Oslo Børs Benchmark Index_GI	Index	NO	Index	https://finance.yahoo.com/quote/OSEBX.OL	https://finance.yahoo.com/quote/OSEBX.OL	\N	\N	t	\N	\N	\N	\N	\N	\N	\N	\N	Index	\N	.OL	LON	^OSEBX	^OSEBX
^STOXX	INDEXSTOXX:SXXP	STOXX EUROPE 600 (inkl. Schweiz og UK)	Index	DE	Index	https://www.marketscreener.com/STOXX-EUROPE-600-7477/	https://finance.yahoo.com/quote/%5ESTOXX?p=^STOXX	\N	Xtracker XSX6.L (pænt stor), iShares EXSA.DE (størst, ikke på LST)	t	\N	\N	\N	\N	\N	\N	\N	\N	Index	\N	.DE	LON	^GDAXI	^STOXX
0100.HK	HKG:0100	Minimax Group	TechToProfs	China	Tech	https://www.marketscreener.com/quote/stock/MINIMAX-GROUP-INC-201432992/	https://finance.yahoo.com/quote/0100.HK/	https://www.minimaxi.com/	LLM-modeller, specielt til kodning. Adgang via deres hjemmeside	\N	\N	0.4700	2026	\N	HKD	\N	\N	\N	TechToProfs	\N	.HK	HKG	^HSI	0100.HK
012450.KS	KRX:012450	Hanwha Aerospace	Defense	Sydkorea	Indu	https://www.marketscreener.com/quote/stock/HAVITLA-AEROSPACE-CO-LTD-6493920/	https://finance.yahoo.com/quote/012450.KS/	http://www.hanwhaaerospace.co.kr/	Aerospace, defense systems, munitions.	\N	\N	0.5500	2026	\N	KRW	\N	\N	\N	Defense	\N	.KS	HKG	^HSI	012450.KS
0270.HK	HKG:0270	Guangdong Investment	Investment	China	Fina	https://www.marketscreener.com/quote/stock/GUANGDONG-INVESTMENT-LIMI-1412630/	https://finance.yahoo.com/quote/0270.HK/	https://www.gdi.com.hk	Investeringer i vand og spildevandbehandling	\N	\N	0.6000	2026	\N	HKD	\N	\N	\N	Investment	\N	.HK	HKG	^HSI	0270.HK
0285.HK	HKG:0285	BYD Electronic Intl	ElectrComponents	China	Tech	https://www.marketscreener.com/quote/stock/BYD-ELECTRONIC-INTERNATI-6165785/	https://finance.yahoo.com/quote/0285.HK	https://electronics.byd.com	Alle slags elektroniske komponenter og moduler	\N	\N	0.5000	2026	\N	HKD	\N	\N	\N	ElectrComponents	\N	.HK	HKG	^HSI	0285.HK
0388.HK	HKG:0388	Hong Kong Exchanges and Clearing	Services(Fina)	China	Fina	https://www.marketscreener.com/quote/stock/HONG-KONG-EXCHANGES-AND-C-1412659/	https://finance.yahoo.com/quote/0388.HK/	https://www.hkex.com.hk	\N	\N	\N	0.5500	2026	\N	HKD	\N	\N	\N	Services(Fina)	\N	.HK	HKG	^HSI	0388.HK
0522.HK	HKG:0522	ASMPT (tidl: ASM Pacific Technology)	Semi	Singapore	Tech	https://www.marketscreener.com/quote/stock/ASM-PACIFIC-TECHNOLOGY-LI-1412677/	https://finance.yahoo.com/quote/0522.HK	https://www.asmpacific.com	Maskiner til chip-fremstilling	\N	\N	0.5000	2026	\N	HKD	\N	\N	\N	Semi	\N	.HK	HKG	^HSI	0522.HK
0636.HK	HKG:0636	Kerry Logistics Network	Trpt_Other	China	Indu	https://www.marketscreener.com/quote/stock/KERRY-LOGISTICS-NETWORK-L-15252882/	https://finance.yahoo.com/quote/0636.HK?p=0636.HK&.tsrc=fin-srch	https://www.kerrylogistics.com	Logistik, mest i Sydøstasien	\N	\N	0.2600	2026	\N	HKD	\N	\N	\N	Trpt_Other	\N	.HK	HKG	^HSI	0636.HK
0700.HK	HKG:0700	Tencent Hldgs	TechToCons	China	Tech	https://www.marketscreener.com/quote/stock/TENCENT-HOLDINGS-LIMITED-3045861/	\N	https://www.tencent.com	Internet services: Apps, games, payment, marketing	\N	\N	0.6000	2026	\N	HKD	\N	\N	\N	TechToCons	\N	.HK	HKG	^HSI	0700.HK
0868.HK	HKG:0868	Xinyi Glass Holdings	Manuf_Special	China	Indu	https://www.marketscreener.com/quote/stock/XINYI-GLASS-HOLDINGS-LTD-6170707/	\N	https://www.xinyiglass.com	XYIGF (og XYIGY) hvis OTC ønskes	\N	\N	0.4500	2026	\N	HKD	\N	\N	\N	Manuf_Special	\N	.HK	HKG	^HSI	0868.HK
0883.HK	HKG:0883	CNOOC (China National Offshore Oil Corp)	Oil&Gas	China	Ener	https://www.marketscreener.com/quote/stock/CNOOC-LIMITED-1412718/	https://finance.yahoo.com/quote/0883.HK?p=0883.HK&.tsrc=fin-srch	https://www.cnoocltd.com	Largest crude and NG-producer in China and in the world. 8% udb. Ejer også drilling lots i Nordsøen	t	\N	0.7000	2026	\N	HKD	\N	\N	\N	Oil&Gas	\N	.HK	HKG	^HSI	0883.HK
0939.HK	HKG:0939	China Construction Bank Corp	Bank	China	Fina	https://www.marketscreener.com/quote/stock/CHINA-CONSTRUCTION-BANK-C-1412722/	https://finance.yahoo.com/quote/0939.HK?p=0939.HK&.tsrc=fin-srch	https://www.ccb.com	én af top4-banker i Kina	\N	\N	0.5000	2026	\N	HKD	\N	\N	\N	Bank	\N	.HK	HKG	^HSI	0939.HK
0968.HK	HKG:0968	Xinyi Solar	Rnwb(Indu)	China	Indu	https://www.marketscreener.com/quote/stock/XINYI-SOLAR-HOLDINGS-LIMI-15196497/	https://finance.yahoo.com/quote/0968.HK?p=0968.HK&.tsrc=fin-srch	https://www.xinyisolar.com	\N	\N	\N	0.4000	2026	\N	HKD	\N	\N	\N	Rnwb(Indu)	\N	.HK	HKG	^HSI	0968.HK
0981.HK	HKG:0981	SMIC (Semicond. Manuf. Intl.)	Semi	China	Tech	https://www.marketscreener.com/quote/stock/SEMICONDUCTOR-MANUFACTURI-6170774/	https://finance.yahoo.com/quote/0981.HK?p=0981.HK&.tsrc=fin-srch	https://www.smics.com/en/	Kinas største chip-fabrikant. TSM-konkurrent. Er på US's sanktionsliste (2022).	\N	\N	0.4000	2026	\N	HKD	\N	\N	\N	Semi	\N	.HK	HKG	^HSI	0981.HK
1072.HK	HKG:1072	Dongfang Electric	Rnwb(Indu)	China	Indu	https://www.marketscreener.com/quote/stock/DONGFANG-ELECTRIC-CORPORA-6170817/	https://finance.yahoo.com/quote/1072.HK?p=1072.HK&.tsrc=fin-srch	https://www.dec-ltd.cn	Power generation equipment and general contractors of power plant projects (incl nuclear). Eksport til 110 lande.	t	\N	0.4500	2026	\N	HKD	\N	\N	\N	Rnwb(Indu)	\N	.HK	HKG	^HSI	1072.HK
1299.HK	HKG:1299	AIA Group	Insurance	China	Fina	https://www.marketscreener.com/quote/stock/AIA-GROUP-LIMITED-6782041/	https://finance.yahoo.com/quote/1299.HK?p=1299.HK	https://www.aia.com	OTC:AAGIY (og AAIGF)	\N	\N	0.5600	2026	\N	HKD	\N	\N	\N	Insurance	\N	.HK	HKG	^HSI	1299.HK
1368.HK	HKG:1368	Xtep International	Clothing	China	C-Di	https://www.marketscreener.com/quote/stock/XTEP-INTERNATIONAL-HOLDIN-6170900/	https://finance.yahoo.com/quote/1368.HK?p=1368.HK&.tsrc=fin-srch	https://www.xtep.com.hk	Sammen Li Ning og Anta en af de 3 ledende i sportstøj og -udstyr	\N	\N	0.5000	2026	\N	HKD	\N	\N	\N	Clothing	\N	.HK	HKG	^HSI	1368.HK
1398.HK	HKG:1398	Industrial and Commercial Bank of China	Bank	China	Fina	https://www.marketscreener.com/quote/stock/INDUSTRIAL-AND-COMMERCIAL-1412597/	https://finance.yahoo.com/quote/1398.HK?p=1398.HK&.tsrc=fin-srch	https://www.icbc-ltd.com	Verdens største bank. Nr 2,3 og 4 er også kinesiske.	\N	\N	0.5000	2026	\N	HKD	\N	\N	\N	Bank	\N	.HK	HKG	^HSI	1398.HK
1772.HK	HKG:1772	Ganfeng Lithium	Mining	China	Basi	https://www.marketscreener.com/quote/stock/GANFENG-LITHIUM-CO-LTD-103501544/	https://finance.yahoo.com/quote/1772.HK?p=1772.HK&.tsrc=fin-srch	https://www.ganfenglithium.com	GNENY, OTCPK:GNENF	\N	\N	0.2800	2026	\N	HKD	\N	\N	\N	Mining	\N	.HK	HKG	^HSI	1772.HK
1810.HK	HKG:1810	Xiaomi	TechToCons	China	Tech	https://www.marketscreener.com/quote/stock/XIAOMI-CORPORATION-45271958/	https://finance.yahoo.com/quote/1810.HK?p=1810.HK&.tsrc=fin-srch	https://www.mi.com	Elektronik: Smartphones 61% af 2022-salg.	\N	\N	0.5000	2026	\N	HKD	\N	\N	\N	TechToCons	\N	.HK	HKG	^HSI	1810.HK
1833.HK	HKG:1833	PA GoodDoctor (PING AN HEALTHCARE AND TECHNOLOGY)	Healthcare	China	Heal	https://www.marketscreener.com/quote/stock/PING-AN-HEALTHCARE-AND-TE-44548681/	\N	https://www.pagd.net	\N	\N	\N	0.4500	2026	\N	HKD	\N	\N	\N	Healthcare	\N	.HK	HKG	^HSI	1833.HK
1910.HK	HKG:1910	Samsonite	Clothing	China	C-Di	https://www.marketscreener.com/quote/stock/SAMSONITE-INTERNATIONAL-S-8175240/	https://finance.yahoo.com/quote/1910.HK/	https://www.samsonite.com	Tasker (Apparel & Accessories)	\N	\N	0.5000	2026	\N	HKD	\N	\N	\N	Clothing	\N	.HK	HKG	^HSI	1910.HK
1913.HK	HKG:1913	Prada	Luxury	IT	C-Di	https://www.marketscreener.com/quote/stock/PRADA-S-P-A-8235601/	https://finance.yahoo.com/quote/1913.HK?p=1913.HK&.tsrc=fin-srch	https://www.prada.com	Prada, Miu Miu and others	\N	\N	0.5500	2026	\N	HKD	\N	\N	\N	Luxury	\N	.HK	HKG	^HSI	1913.HK
1919.HK	HKG:1919	Cosco Shipping Hldgs (H-shares)	Trpt_Ship	China	Indu	https://www.marketscreener.com/quote/stock/COSCO-SHIPPING-HOLDINGS-C-1412613/	https://finance.yahoo.com/quote/1919.HK?p=1919.HK&.tsrc=fin-srch	https://www.hold.coscoshipping.com	Container-rederi. Maersk, Cosco og CMA-CGM (FR) er verdens største af disse.	\N	\N	0.5000	2026	\N	HKD	\N	\N	\N	Trpt_Ship	\N	.HK	HKG	^HSI	1919.HK
2020.HK	HKG:2020	ANTA Sports Products 	Clothing	China	C-Di	https://www.marketscreener.com/quote/stock/ANTA-SPORTS-PRODUCTS-LIMI-6170948/	https://finance.yahoo.com/quote/2020.HK?p=2020.HK	https://www.anta.com.cn	Sportstøj og accessories	\N	\N	0.6000	2026	\N	HKD	\N	\N	\N	Clothing	\N	.HK	HKG	^HSI	2020.HK
2269.HK	HKG:2269	WUXI Biologics (Cayman)	Pharma	China	Heal	https://www.marketscreener.com/quote/stock/WUXI-BIOLOGICS-CAYMAN-INC-37230806/	https://finance.yahoo.com/quote/2269.HK?p=2269.HK&.tsrc=fin-srch	https://www.wuxibiologics.com	Biologics-focused Contract Research, Development and Manufacturing. Også fabrikker i Tysklnad og Irland. 57% af salg i US.	t	\N	0.7500	2026	\N	HKD	\N	\N	\N	Pharma	\N	.HK	HKG	^HSI	2269.HK
2331.HK	HKG:2331	Li Ning Company	Clothing	China	C-Di	https://www.marketscreener.com/quote/stock/LI-NING-COMPANY-LIMITED-6170966/	https://finance.yahoo.com/quote/2331.HK?p=2331.HK&.tsrc=fin-srch	https://www.lining.com	En af vinderne i konkurrencen med Vestens tøjmærker	\N	\N	0.4000	2026	\N	HKD	\N	\N	\N	Clothing	\N	.HK	HKG	^HSI	2331.HK
2359.HK	HKG:2359	WUXI Apptec	Pharma	China	Heal	https://www.marketscreener.com/quote/stock/WUXI-APPTEC-CO-LTD-103505405/	https://finance.yahoo.com/quote/2359.HK	https://www.wuxiapptec.com.cn	R&D and manufacturing services to pharma and biotech globally. 65% af salg i US	\N	\N	0.7200	2026	\N	HKD	\N	\N	\N	Pharma	\N	.HK	HKG	^HSI	2359.HK
2513.HK	HKG:2513	Knowledge Atlas Technologi JSC (Zhipu AI, Z.ai)	TechToProfs	China	Tech	https://www.marketscreener.com/quote/stock/KNOWLEDGE-ATLAS-TECHNOLOG-201428752/	https://finance.yahoo.com/quote/2513.HK/	https://www.zhipuai.cn/	LLM-modeller.  Adgang her: https://www.zhipuai.cn/en	\N	\N	\N	\N	\N	HKD	\N	\N	\N	TechToProfs	\N	.HK	HKG	^HSI	2513.HK
2899.HK	HKG:2899	Zijin Mining Group	Gold	China	Basi	https://www.marketscreener.com/quote/stock/ZIJIN-MINING-GROUP-COMPAN-6171013/	https://finance.yahoo.com/quote/2899.HK/	https://www.zjky.cn/	Guld, kobber, lithium mm. Miner i Kina, Mongoliet og dets naboer, Afrika, Sydamerika, Australien og Serbien. Raffinerer også, helt eller delvist.	\N	\N	0.8300	2026	\N	HKD	\N	\N	\N	Gold	\N	.HK	HKG	^HSI	2899.HK
3323.HK	HKG:3323	China National Building Material Company	ConstrMaterials	China	Basi	https://www.marketscreener.com/quote/stock/CHINA-NATIONAL-BUILDING-M-6171023/	https://finance.yahoo.com/quote/3323.HK?p=3323.HK&.tsrc=fin-srch	https://www.cnbmltd.com	\N	\N	\N	0.5000	2026	\N	HKD	\N	\N	\N	ConstrMaterials	\N	.HK	HKG	^HSI	3323.HK
3690.HK	HKG:3690	Meituan Dianping Class B	Trpt_Other	China	Indu	https://www.marketscreener.com/quote/stock/MEITUAN-DIANPING-47006634/	\N	https://about.meituan.com	\N	\N	\N	0.4000	2026	\N	HKD	\N	\N	\N	Trpt_Other	\N	.HK	HKG	^HSI	3690.HK
3750.HK	HKG:3790	CATL (Contemporary Amperex Technology Co)	Batteries	China	Indu	https://www.marketscreener.com/quote/stock/CATL-CONTEMPORARY-AMPEREX-188480789/	https://finance.yahoo.com/quote/3750.HK/	https://www.catl.com/	Fast-charging auto battery as well as energy storage systems.	\N	\N	0.7800	2026	\N	HKD	\N	\N	\N	Other[Indu]	\N	.HK	HKG	^HSI	3750.HK
3988.HK	HKG:3988	Bank of China	Bank	China	Fina	https://www.marketscreener.com/quote/stock/BANK-OF-CHINA-LIMITED-1412661/	https://finance.yahoo.com/quote/3988.HK?p=3988.HK&.tsrc=fin-srch	https://www.boc.cn	én af top4-banker i Kina	\N	\N	0.4400	2026	\N	HKD	\N	\N	\N	Bank	\N	.HK	HKG	^HSI	3988.HK
4004.T	TYO:4004	Resonac Hldgs (tidl. Showa Denco)	Semi	Japan	Tech	https://www.marketscreener.com/quote/stock/RESONAC-HOLDINGS-CORPORAT-6491222/	https://finance.yahoo.com/quote/4004.T/	https://www.resonac.com/jp	Kemi-firma inden for halvleder-fremstilling. Initiativtager til det enorme 27-Member "JOINT3" Consortium to Develop Next-Generation Semiconductor Packaging	\N	\N	0.4500	2026	\N	JPY	\N	\N	\N	Semi	\N	.T	HKG	^HSI	4004.T
6146.T	TYO:6146	Disco Corp.	Semi	Japan	Tech	https://www.marketscreener.com/quote/stock/DISCO-CORPORATION-6491471/	https://finance.yahoo.com/quote/6146.T/	https://finance.yahoo.com/quote/6146.T/	Precision toolmaker dominerende på sit felt: Chip-produktion	\N	\N	0.6500	2026	\N	JPY	\N	\N	\N	Semi	\N	.T	HKG	^HSI	6146.T
6504.T	TYO:6504	Fuji Electic	Rnwb(Ener)	Japan	Ener	https://www.marketscreener.com/quote/stock/FUJI-ELECTRIC-CO-LTD-6494391/	https://finance.yahoo.com/quote/6504.T/	http://www.fujielectric.co.jp/	Elektriske komponenter med fokus på elektrificering af mange industrier. 27000 ansatte.	\N	\N	0.4500	2026	\N	JPY	\N	\N	\N	Rnwb(Ener)	\N	.T	HKG	^HSI	6504.T
6865.HK	HKG:6865	Flat Glass Group	Rnwb(Indu)	China	Indu	https://www.marketscreener.com/quote/stock/FLAT-GLASS-GROUP-CO-LTD-25023317/	https://finance.yahoo.com/quote/6865.HK?p=6865.HK&.tsrc=fin-srch	https://www.flatgroup.com.cn	\N	\N	\N	0.3500	2026	\N	HKD	\N	\N	\N	Rnwb(Indu)	\N	.HK	HKG	^HSI	6865.HK
6869.HK	HKG:6869	Yangtze Optical Fibre and Cable JSC 	ElectrComponents	China	Tech	https://www.marketscreener.com/quote/stock/YANGTZE-OPTICAL-FIBRE-AND-18750184/	https://finance.yahoo.com/quote/6869.HK/	https://www.en.yofc.com	Fiber-optic cables	\N	\N	0.3700	2026	\N	HKD	\N	\N	\N	ElectrComponents	\N	.HK	HKG	^HSI	6869.HK
6954.T	TYO:6954	Fanuc Corp	Manuf_Special	Japan	Indu	https://www.marketscreener.com/quote/stock/FANUC-CORPORATION-6492019/	https://finance.yahoo.com/quote/6954.T/	https://www.fanuc.co.jp/eindex.html	Robotter	\N	\N	0.5000	2026	\N	JPY	\N	\N	\N	Manuf_Special	\N	.T	HKG	^HSI	6954.T
8035.T	TYO:8035	Tokyo Electron	Semi	Japan	Tech	https://www.marketscreener.com/quote/stock/TOKYO-ELECTRON-LTD-6491071/	https://finance.yahoo.com/quote/8035.T?p=8035.T&.tsrc=fin-srch	https://www.tel.co.jp	Semiconductor-equipment	\N	\N	0.7000	2026	\N	JPY	\N	\N	\N	Semi	\N	.T	HKG	^HSI	8035.T
82318.HK	HKG:82318	Ping An Insurance (Group) Company Shrs H	Insurance	China	Fina	https://www.marketscreener.com/quote/stock/PING-AN-INSURANCE-GROUP-C-1412620/	https://finance.yahoo.com/quote/82318.HK/	https://www.pingan.cn	Forsikring, bank og meget andet	\N	\N	\N	\N	\N	HKD	\N	\N	\N	Insurance	\N	.HK	HKG	^HSI	82318.HK
82333.HK	HKG:82333	Great Wall Motor Srs H	Automotive	China	C-Di	https://www.marketscreener.com/quote/stock/GREAT-WALL-MOTOR-COMPANY--6170968/	\N	https://www.gwm.com.cn	\N	\N	\N	0.4000	2026	\N	HKD	\N	\N	\N	Automotive	\N	.HK	HKG	^HSI	82333.HK
9201.T	TYO:9201	Japan Airlines Co., Ltd.	Trpt_Airline	Japan	Indu	https://www.marketscreener.com/quote/stock/JAPAN-AIRLINES-CO-LTD-11551593/	https://finance.yahoo.com/quote/9201.T?p=9201.T&.tsrc=fin-srch	https://www.jal.com/index.html	Airline	\N	\N	0.6000	2026	\N	JPY	\N	\N	\N	Trpt_Airline	\N	.T	HKG	^HSI	9201.T
9880.HK	HKG:9880	Ubtech	Manuf_Special	China	Indu	https://www.marketscreener.com/quote/stock/UBTECH-ROBOTICS-CORP-LTD-163723799/	https://finance.yahoo.com/quote/9880.HK/	https://www.ubtrobot.com/en/	Fremstiller robotter af mange slags, en af de førende i humanoide	\N	\N	0.3200	2026	\N	HKD	\N	\N	\N	Manuf_Special	\N	.HK	HKG	^HSI	9880.HK
9926.HK	HKG:9926	Akeso	Pharma	China	Heal	https://www.marketscreener.com/quote/stock/AKESO-INC-111325370/	https://finance.yahoo.com/quote/9926.HK/	http://www.akesobio.com/en/	Holding company for biotech, især antistof-konjugater til kræftbehandling (a la Keytruda og Genmab-produkter)	\N	\N	0.4500	2026	\N	HKD	\N	\N	\N	Pharma	\N	.HK	HKG	^HSI	9926.HK
ABBN.SW	SWX:ABBN	ABB	Manuf_Big	CH	Indu	https://www.marketscreener.com/quote/stock/ABB-LTD-9365000/	https://finance.yahoo.com/quote/ABBN.SW/	https://www.abb.com/global/en	Electrification, motion, and automation. Global markets in all kinds of physical production companies.	\N	\N	0.5000	2026	\N	CHF	\N	\N	\N	Manuf_Big	\N	.SW	LON	^STOXX	ABBN.SW
ABBV	ABBV	AbbVie	Pharma	US	Heal	https://www.marketscreener.com/quote/stock/ABBVIE-INC-12136589/	\N	https://www.abbvie.com	Kaletra (lopinavir & ritonavir)	t	\N	0.5500	2026	\N	USD	\N	\N	\N	Pharma	\N	.US	NY	^GSPC	ABBV
ABEV	ABEV	Ambev ADR	Food	Brazil	C-St	https://www.marketscreener.com/quote/stock/AMBEV-S-A-14851392/	https://finance.yahoo.com/quote/ABEV/	http://www.ambev.com.br/	Brasiliansk ølbrygger, der sælger lokalt og latinamerika. 43000 ansatte.	\N	\N	0.6100	2026	\N	USD	\N	\N	\N	Food	\N	.US	NY	^GSPC	ABEV
ABI.BR	EBR:ABI	Anheuser-Busch Inbev	Food	Belgien	C-St	https://www.marketscreener.com/quote/stock/ANHEUSER-BUSCH-INBEV-SA-N-31571356/	https://finance.yahoo.com/quote/ABI.BR?p=ABI.BR	https://www.ab-inbev.com	\N	t	\N	0.6500	2026	\N	EUR	\N	\N	\N	Food	\N	.BR	LON	^FCHI	ABI.BR
ABN.AS	AMS:ABN	ABN Amro	Bank	NL	Fina	https://www.marketscreener.com/quote/stock/ABN-AMRO-BANK-N-V-24962165/	https://finance.yahoo.com/quote/ABN.AS?p=ABN.AS&.tsrc=fin-srch	https://abnamro.com	Bank	\N	\N	0.5000	2026	\N	EUR	\N	\N	\N	Bank	\N	.AS	LON	^AEX	ABN.AS
ABNB	ABNB	AirBNB	TechToCons	US	Tech	https://www.marketscreener.com/quote/stock/AIRBNB-INC-116310849/	https://finance.yahoo.com/quote/ABNB?p=ABNB&.tsrc=fin-srch	https://www.airbnb.com	\N	\N	\N	0.6000	2026	\N	USD	\N	\N	\N	TechToCons	\N	.US	NY	^GSPC	ABNB
ABR	ABR	Arbor Realty Trust	Mortgages	US	REIT	https://www.marketscreener.com/quote/stock/ARBOR-REALTY-TRUST-INC-11503/	\N	https://www.arbor.com	Multifamily, single-family rental (SFR) and commercial real estate markets	t	\N	0.2500	2026	\N	USD	\N	\N	\N	Mortgages	\N	.US	NY	^GSPC	ABR
ABR-PF	NYSE:ABR-F	Arbor Realty Trust 6,25% Cum. Pref Shs Ser F	Mortgages	US	REIT	https://www.marketscreener.com/quote/stock/ARBOR-REALTY-TRUST-INC-127886535/	https://finance.yahoo.com/quote/ABR-PF?p=ABR-PF&.tsrc=fin-srch	https://www.arbor.com	Overgår 30.okt 2026 til 3 month SOFR +5,44pctpoint. Den vil sikkert blive called der.	t	\N	0.2500	2026	\N	USD	\N	\N	\N	Mortgages	\N	.US	NY	^GSPC	ABR-PF
ABT	ABT	Abbott Laboratories	Pharma	US	Heal	https://www.marketscreener.com/quote/stock/ABBOTT-LABORATORIES-11506/	\N	https://www.abbott.com	COVID-19 hurtig-tests	\N	\N	0.5000	2026	\N	USD	\N	\N	\N	Pharma	\N	.US	NY	^GSPC	ABT
ACA.PA	EPA:ACA	Credit Agricole	Bank	FR	Fina	https://www.marketscreener.com/quote/stock/CREDIT-AGRICOLE-S-A-4735/	https://finance.yahoo.com/quote/ACA.PA?p=ACA.PA&.tsrc=fin-srch	https://www.credit-agricole.com	En af de største franske banker	t	\N	0.4400	2026	\N	EUR	\N	\N	\N	Bank	\N	.PA	LON	^FCHI	ACA.PA
ACGL	ACGL	Arch Capital Group	Insurance	US	Fina	https://www.marketscreener.com/quote/stock/ARCH-CAPITAL-GROUP-LTD-8233/	https://finance.yahoo.com/quote/ACGL?p=ACGL&.tsrc=fin-srch	https://www.archgroup.com	\N	\N	\N	0.3800	2026	\N	USD	\N	\N	\N	Insurance	\N	.US	NY	^GSPC	ACGL
ACIW	ACIW	ACI Worldwide	TechToProfs	US	Tech	https://www.marketscreener.com/quote/stock/ACI-WORLDWIDE-INC-11158/	https://finance.yahoo.com/quote/ACIW/	https://www.aciworldwide.com	Digital payments in US and worldwide	\N	\N	0.5600	2026	\N	USD	\N	\N	\N	TechToProfs	\N	.US	NY	^GSPC	ACIW
ACN	ACN	Accenture	Consulting(Tech)	US	Tech	https://www.marketscreener.com/quote/stock/ACCENTURE-PLC-11521/	\N	https://www.accenture.com	721.000 ansatte	\N	\N	0.5500	2026	\N	USD	\N	\N	t	Consulting(Tech)	\N	.US	NY	^GSPC	ACN
ACRE	ACRE	Ares Commercial (commercial)	Mortgages	US	REIT	https://www.marketscreener.com/quote/stock/ARES-COMMERCIAL-REAL-ESTA-10486909/	https://finance.yahoo.com/quote/ACRE?p=ACRE&.tsrc=fin-srch	https://www.arescre.com	\N	\N	\N	\N	\N	\N	USD	\N	\N	\N	Mortgages	\N	.US	NY	^GSPC	ACRE
ACS.MC	BME:ACS	Actividades de Construccion y Servicios	Construction	ES	Indu	https://www.marketscreener.com/quote/stock/ACS-ACTIVIDADES-DE-CONSTR-140640/	https://finance.yahoo.com/quote/ACS.MC?p=ACS.MC&.tsrc=fin-srch	https://www.grupoacs.com	Europas største entreprenør, globalt arbejdende, Oms 33 mia €, 128.000 ansatte (2022).Knap 100 datterselskaber.	t	\N	0.5000	2026	\N	EUR	\N	\N	\N	Construction	\N	.MC	LON	^STOXX	ACS.MC
AD.AS	AMS:AD	Ahold Delhaize N.V:	Retail	NL	C-St	https://www.marketscreener.com/quote/stock/AHOLD-DELHAIZE-N-V-29752127/	https://finance.yahoo.com/quote/AD.AS?p=AD.AS&.tsrc=fin-srch	https://www.aholddelhaize.com	Supermarked-kæde, også eCommerce. 	\N	\N	0.4000	2026	\N	EUR	\N	\N	\N	Retail	\N	.AS	LON	^AEX	AD.AS
ADAM	ADAM	Adamos (før: New York Mortgage Trust)	Mortgages	US	REIT	https://www.marketscreener.com/quote/stock/NEW-YORK-MORTGAGE-TRUST-I-3081571/	https://finance.yahoo.com/quote/NYMT?p=NYMT&.tsrc=fin-srch	https://www.nymtrust.com	Non-agency. Betalingsstandsning 24.3.20, men overlevede	\N	\N	0.3800	2026	\N	USD	\N	\N	\N	Mortgages	\N	.US	NY	^GSPC	ADAM
ADC	ADC	Agree Realty Corp	Property	US	REIT	https://www.marketscreener.com/quote/stock/AGREE-REALTY-CORPORATION-11530/	https://finance.yahoo.com/quote/ADC?p=ADC&.tsrc=fin-srch	https://www.agreerealty.com	Owns retail properties net leased to national and large regional retailers	\N	\N	0.3900	2026	\N	USD	\N	\N	\N	Property	\N	.US	NY	^GSPC	ADC
ADC-PA	ADC-A	Agree Realty Prf A	Property	US	REIT	https://www.marketscreener.com/quote/stock/AGREE-REALTY-CORPORATION-126829941/	https://finance.yahoo.com/quote/ADC-PA/	https://www.agreerealty.com	Retail properties net leased. 4,25% Cumulative Redeemable Pref Shs	t	\N	0.4500	2026	\N	USD	\N	\N	\N	Property	\N	.US	NY	^GSPC	ADC-PA
ADEN.SW	SWX:ADEN	Adecco	Consulting(Indu)	CH	Indu	https://www.marketscreener.com/quote/stock/ADECCO-GROUP-AG-9365001/	https://finance.yahoo.com/quote/ADEN.SW?p=ADEN.SW&.tsrc=fin-srch	https://www.adecco.com	Godt udbytte	\N	\N	0.6500	2026	\N	CHF	\N	\N	\N	Other[Indu]	7	.SW	LON	^STOXX	ADEN.SW
ADI	ADI	Analog Devices	Semi	US	Tech	https://www.marketscreener.com/quote/stock/ANALOG-DEVICES-INC-10345717/	https://finance.yahoo.com/quote/ADI/	https://www.analog.com	Design, manufacturing and marketing of integrated circuits	\N	\N	0.2800	2026	\N	USD	\N	\N	\N	Semi	\N	.US	NY	^GSPC	ADI
ADM	ADM	Archer-Daniels-Midland comp	Food	US	C-St	https://www.marketscreener.com/quote/stock/ARCHER-DANIELS-MIDLAND-CO-11533/	https://finance.yahoo.com/quote/ADM?p=ADM&.tsrc=fin-srch	https://www.adm.com	Food ingredients	\N	\N	0.3000	2026	\N	USD	\N	\N	\N	Food	\N	.US	NY	^GSPC	ADM
ADNT	ADNT	Adient plc	Manuf_Special	US	Indu	https://www.marketscreener.com/quote/stock/ADIENT-PLC-31763210/	https://finance.yahoo.com/quote/ADNT/	https://www.adient.com/	Automotive seating solutions include complete seating systems	\N	\N	0.5300	2026	\N	USD	\N	\N	\N	Manuf_Special	\N	.US	NY	^GSPC	ADNT
APPS	APPS	Digital Turbine	TechToProfs	US	Tech	https://www.marketscreener.com/quote/stock/DIGITAL-TURBINE-INC-20251394/	\N	https://www.digitalturbine.com	\N	t	\N	\N	\N	\N	USD	\N	\N	\N	TechToProfs	\N	.US	NY	^GSPC	APPS
ADP	ADP	Automatic Data Processing	Consulting(Tech)	US	Tech	https://www.marketscreener.com/quote/stock/AUTOMATIC-DATA-PROCESSING-11713/	https://finance.yahoo.com/quote/ADP?p=ADP&.tsrc=fin-srch	https://www.adp.com	Systemer til personale-administration	\N	\N	0.5000	2026	\N	USD	\N	\N	\N	Consulting(Tech)	\N	.US	NY	^GSPC	ADP
ADS.DE	ETR:ADS	Adidas AG	Clothing	DE	C-Di	https://www.marketscreener.com/quote/stock/ADIDAS-AG-6714534/	https://finance.yahoo.com/quote/ADS.DE?p=ADS.DE&.tsrc=fin-srch	https://www.adidas-group.com	Sportstøj og accessories	\N	\N	0.6500	2026	\N	EUR	\N	\N	\N	Clothing	\N	.DE	LON	^GDAXI	ADS.DE
ADYEN.AS	AMS:ADYEN	Adyen	TechToProfs	NL	Tech	https://www.marketscreener.com/quote/stock/ADYEN-N-V-44211922/	https://finance.yahoo.com/quote/ADYEN.AS/	https://www.adyen.com	Nextgen payment processor. Like Block(tidl.: Square) and Stripe (status 17.8.23: stadig ikke IPO)	t	\N	0.7200	2026	\N	EUR	\N	\N	\N	TechToProfs	\N	.AS	LON	^AEX	ADYEN.AS
AEM.TO	TSE:AEM	Agnico Eagle Mines	Gold	CAN	Basi	https://www.marketscreener.com/quote/stock/AGNICO-EAGLE-MINES-LIMITE-1408914/	https://finance.yahoo.com/quote/AEM.TO/	https://www.agnicoeagle.com	Fusionerer med Kirland Lake Gold i 2022	\N	\N	0.4000	2026	\N	CAD	\N	\N	\N	Gold	\N	.TO	NY	^GSPC	AEM.TO
AFG.OL	OSL:AFG	AF Gruppen	Construction	NO	Indu	https://www.marketscreener.com/quote/stock/AF-GRUPPEN-ASA-1413069/	https://finance.yahoo.com/quote/AFG.OL?p=AFG.OL	https://www.afgruppen.no	\N	\N	\N	0.3100	2026	\N	NOK	\N	\N	\N	Construction	\N	.OL	LON	^OSEBX	AFG.OL
AFL	AFL	Aflac	Insurance	US	Fina	https://www.marketscreener.com/quote/stock/AFLAC-INCORPORATED-11556/	https://finance.yahoo.com/quote/AFL?p=AFL&.tsrc=fin-srch	https://www.aflac.com	2/3 af salg i Japan	\N	\N	\N	\N	\N	USD	\N	\N	\N	Insurance	\N	.US	NY	^GSPC	AFL
AFM.V	CVE:AFM	Alphamin Resources	Mining	CAN	Basi	https://www.marketscreener.com/quote/stock/ALPHAMIN-RESOURCES-CORPOR-19156083/	https://finance.yahoo.com/quote/AFM.V/	https://www.alphaminresources.com/	Tin concentrate from Bisie tin mine in Democratic Republic of Congo.	\N	\N	0.6000	2026	\N	CAD	\N	\N	\N	Mining	\N	.V	NY	^GSPC	AFM.V
AFRM	AFRM	Affirm Holdings	Fintech	US	Fina	https://www.marketscreener.com/quote/stock/AFFIRM-HOLDINGS-INC-117540803/	https://finance.yahoo.com/quote/AFRM/	https://www.affirm.com/	Platform for point-of-sale payments for consumers (som Adyen), eCommerce solutions, and a consumer-focused app	\N	\N	0.3500	2026	\N	USD	\N	\N	\N	Fintech	\N	.US	NY	^GSPC	AFRM
AFRY.ST	STO:AFRY	AFRY (ÅF Poyry)	Consulting(Indu)	SE	Indu	https://www.marketscreener.com/quote/stock/AFRY-AB-16716931/	https://finance.yahoo.com/quote/AFRY.ST?p=AFRY.ST	https://www.afconsult.com	Ingeniørvirksomhed	t	\N	0.2100	2026	\N	SEK	\N	\N	\N	Other[Indu]	7	.ST	LON	^OMX	AFRY.ST
AGCO	AGCO	AGCO	Manuf_Big	US	Indu	https://www.marketscreener.com/quote/stock/AGCO-CORPORATION-11558/	https://finance.yahoo.com/quote/AGCO?p=AGCO&.tsrc=fin-srch	https://www.agcocorp.com	Landbrugsmaskiner a la Deere, men især Europa	\N	\N	0.8800	2026	\N	USD	\N	\N	\N	Manuf_Big	\N	.US	NY	^GSPC	AGCO
AGI	AGI	Alamos Gold	Gold	US	Basi	https://www.marketscreener.com/quote/stock/ALAMOS-GOLD-INC-40449501/	https://finance.yahoo.com/quote/AGI?p=AGI&.tsrc=fin-srch	https://www.alamosgold.com	Gold producer in Canada, Mexico, and US	\N	\N	0.4700	2026	\N	USD	\N	\N	\N	Gold	\N	.US	NY	^GSPC	AGI
AGNC	AGNC	AGNC Investment (agency)	Mortgages	US	REIT	https://www.marketscreener.com/quote/stock/AGNC-INVESTMENT-CORP-31513839/	\N	https://www.agnc.com	Agency-backed mortgages	t	\N	0.6700	2026	\N	USD	\N	\N	\N	Mortgages	\N	.US	NY	^GSPC	AGNC
AGX	AGX	Argan	Construction	US	Indu	https://www.marketscreener.com/quote/stock/ARGAN-INC-14449787/	https://finance.yahoo.com/quote/AGX	https://www.arganinc.com	Entreprenør, Power-generation anlæg. 985 ansatte	\N	\N	\N	\N	\N	USD	\N	\N	\N	Construction	\N	.US	NY	^GSPC	AGX
AHRT	AHRT	AH Realty Trust (Armada Hoffler)	Property	US	REIT	https://www.marketscreener.com/quote/stock/AH-REALTY-TRUST-INC-13170385/	https://finance.yahoo.com/quote/AHRT/	https://www.armadahoffler.com	Office, retail, multifamily properties	t	\N	0.2200	2026	\N	USD	\N	\N	\N	Property	\N	.US	NY	^GSPC	AHRT
AI	AI	C3.AI	TechToProfs	US	Tech	https://www.marketscreener.com/quote/stock/C3-AI-INC-116373775/	https://finance.yahoo.com/quote/AI?p=AI&.tsrc=fin-srch	https://www.c3.ai	Storskala-AI til virksomheder	\N	\N	0.6300	2026	\N	USD	\N	\N	\N	TechToProfs	\N	.US	NY	^GSPC	AI
AII.TO	TSE:AII	Almonty Industries	Mining	CAN	Basi	https://www.marketscreener.com/quote/stock/ALMONTY-INDUSTRIES-INC-9062503/	https://finance.yahoo.com/quote/ALM/	https://almonty.com/	Canadisk firma med tungsten-miner i Portugal, Spanien og Sydkorea. Støttes af US-regering. Alt salg bookes i Portugal. 403 ansatte.	t	\N	0.5500	2026	\N	CAD	\N	\N	\N	Mining	\N	.TO	NY	^GSPC	AII.TO
AIR.PA	EPA:AIR	Airbus (EADS)	Trpt_Airline	FR	Indu	https://www.marketscreener.com/quote/stock/AIRBUS-SE-4637/	https://finance.yahoo.com/quote/AIR.PA?p=AIR.PA&.tsrc=fin-srch	https://www.airbus.com	\N	\N	\N	0.5000	2026	\N	EUR	\N	\N	\N	Trpt_Airline	\N	.PA	LON	^FCHI	AIR.PA
AIXA.DE	ETR:AIXA	Aixtron SE	Semi	DE	Tech	https://www.marketscreener.com/quote/stock/AIXTRON-SE-3975874/	https://finance.yahoo.com/quote/AIXA.DE/	https://www.aixtron.com	provider of deposition equipment to the semiconductor industry. 1100 ansatte	\N	\N	\N	\N	\N	EUR	\N	\N	\N	Semi	\N	.DE	LON	^GDAXI	AIXA.DE
AKER.OL	OSL:AKER	Aker ASA	Oil&Gas	NO	Ener	https://www.marketscreener.com/quote/stock/AKER-ASA-1413076/	https://finance.yahoo.com/quote/AKER.OL?p=AKER.OL&.tsrc=fin-srch	https://www.akerasa.com	Investeringsselskab (og aktiv holding) for Røkke's selskaber	\N	\N	\N	\N	\N	NOK	\N	\N	\N	Oil&Gas	\N	.OL	LON	^OSEBX	AKER.OL
ALA.TO	TSE:ALA	AltaGas	Util_MixedFuel	CAN	Util	https://www.marketscreener.com/quote/stock/ALTAGAS-LTD-1408970/	https://finance.yahoo.com/quote/ALA.TO/	https://www.altagas.ca	Nat.gas storage and distribution	\N	\N	0.7500	2026	\N	CAD	\N	\N	\N	Util_MixedFuel	\N	.TO	NY	^GSPC	ALA.TO
ALAB	ALAB	Astera Labs	Semi	US	Tech	https://www.marketscreener.com/quote/stock/ASTERA-LABS-INC-167508773/	https://finance.yahoo.com/quote/ALAB/	https://www.asteralabs.com/	Designer, fremstilller og sælger semiconductors til cloud og AI infrastruktur	\N	\N	0.4500	2026	\N	USD	\N	AI-infrastruktur	\N	Semi	\N	.US	NY	^GSPC	ALAB
ALB	ALB	Albemarle	Chemical	US	Indu	https://www.marketscreener.com/quote/stock/ALBEMARLE-CORPORATION-11613/	\N	https://www.albemarle.com	\N	\N	\N	0.5000	2026	\N	USD	\N	\N	\N	Other[Indu]	7	.US	NY	^GSPC	ALB
ALC.SW	SWX:ALC	Alcon	Pharma	CH	Heal	https://www.marketscreener.com/quote/stock/ALCON-INC-56976364/	https://finance.yahoo.com/quote/ALC.SW?p=ALC.SW&.tsrc=fin-srch	https://www.alcon.com	Øjen-lægemidler. IPO 9.4.19	\N	\N	0.3500	2026	\N	CHF	\N	\N	t	Pharma	\N	.SW	LON	^STOXX	ALC.SW
ALFA.ST	CPH:ALFA	Alfa Laval	Manuf_Big	SE	Indu	https://www.marketscreener.com/quote/stock/ALFA-LAVAL-AB-6494532/	https://finance.yahoo.com/quote/ALFA.ST?p=ALFA.ST	https://www.alfalaval.com	\N	\N	\N	0.5000	2026	\N	SEK	\N	\N	\N	Manuf_Big	\N	.ST	LON	^OMX	ALFA.ST
ALGM	ALGM	Allegro MicroSystems	Semi	US	Tech	https://www.marketscreener.com/quote/stock/ALLEGRO-MICROSYSTEMS-INC-114402825/	https://finance.yahoo.com/quote/ALGM?p=ALGM&.tsrc=fin-srch	https://www.allegromicro.com/en	Semiconductors	\N	\N	0.7200	2026	\N	USD	\N	\N	\N	Semi	\N	.US	NY	^GSPC	ALGM
ALIV-SDB.ST	CPH:ALIV-SDB	Autoliv AB	Automotive	SE	C-Di	https://www.marketscreener.com/quote/stock/AUTOLIV-INC-6496154/	https://finance.yahoo.com/quote/ALIV-SDB.ST?p=ALIV-SDB.ST	https://www.autoliv.com	Samme selskab som ALV	\N	\N	0.6300	2026	\N	SEK	\N	\N	\N	Automotive	\N	.ST	LON	^OMX	ALIV-SDB.ST
ALK-B.CO	CPH:ALK-B	Alk-Abello	Pharma	DK	Heal	https://www.marketscreener.com/quote/stock/ALK-ABELL-A-S-1412833/	https://finance.yahoo.com/quote/ALK-B.CO?p=ALK-B.CO&.tsrc=fin-srch	https://www.alk.net	Allergi-medicin	\N	\N	0.3500	2026	\N	DKK	\N	\N	\N	Pharma	\N	.CO	LON	^OMXC20	ALK-B.CO
ALLY	ALLY	Ally Financial	Bank	US	Fina	https://www.marketscreener.com/quote/stock/ALLY-FINANCIAL-INC-16252989/	https://finance.yahoo.com/quote/ALLY?p=ALLY&.tsrc=fin-srch	https://www.ally.com	Alle slags lån, retail og virks: Billån, mod pantebrev og virks-finansiering	\N	\N	0.7400	2026	\N	USD	\N	\N	\N	Bank	\N	.US	NY	^GSPC	ALLY
ALNY	ALNY	Alnylam Pharmaceuticals, Inc.	Pharma	US	Heal	https://www.marketscreener.com/quote/stock/ALNYLAM-PHARMACEUTICALS-I-8322/	https://finance.yahoo.com/quotes/ALNY,AMPGZ/	https://www.alnylam.com/	RNA-baserede lægemidler	\N	\N	0.6200	2026	\N	USD	\N	\N	\N	Pharma	\N	.US	NY	^GSPC	ALNY
ALSYDB.CO	CPH:ALSYDB	AL Sydbank	Bank	DK	Fina	https://www.marketscreener.com/quote/stock/SYDBANK-A-S-1413034/	https://finance.yahoo.com/quote/ALSYDB.CO/	https://www.sydbank.dk	\N	t	\N	0.6000	2026	\N	DKK	\N	\N	\N	Bank	\N	.CO	LON	^OMXC20	ALSYDB.CO
ALV	ALV	Autoliv	Automotive	US	C-Di	https://www.marketscreener.com/quote/stock/AUTOLIV-INC-11628/	\N	https://www.autoliv.com	Airbags og sikkerhedsseler til biler	\N	\N	0.4700	2026	\N	USD	\N	\N	\N	Automotive	\N	.US	NY	^GSPC	ALV
ALV.DE	ETR:ALV	Allianz	Insurance	DE	Fina	https://www.marketscreener.com/quote/stock/ALLIANZ-SE-436843/	https://finance.yahoo.com/quote/ALV.DE?p=ALV.DE&.tsrc=fin-srch	https://www.allianz.com	Verdens største forsikringsselskab. 150.000 ansatte. 126 mio kunder i 70 lande.	t	\N	0.7500	2026	\N	EUR	\N	\N	\N	Insurance	\N	.DE	LON	^GDAXI	ALV.DE
AMAT	AMAT	Applied Materials	Semi	US	Tech	https://www.marketscreener.com/quote/stock/APPLIED-MATERIALS-INC-4850/	https://finance.yahoo.com/quote/AMAT	https://www.appliedmaterials.com	Chip-manuf. equipment	t	\N	0.7000	2026	\N	USD	\N	\N	\N	Semi	\N	.US	NY	^GSPC	AMAT
AMD	AMD	Advanced Micro Devices	Semi	US	Tech	https://www.marketscreener.com/quote/stock/ADVANCED-MICRO-DEVICES-I-19475876/	https://finance.yahoo.com/quote/AMD?p=AMD&.tsrc=fin-srch	https://www.amd.com	Design, manufacturing and marketing of semiconductors and microprocessors	t	\N	0.4000	2026	\N	USD	\N	AI_Core	\N	Semi	\N	.US	NY	^GSPC	AMD
AMGN	AMGN	Amgen	Pharma	US	Heal	https://www.marketscreener.com/quote/stock/AMGEN-INC-4847/	https://finance.yahoo.com/quote/AMGN/	https://www.amgen.com	\N	\N	\N	0.5500	2026	\N	USD	\N	\N	\N	Pharma	\N	.US	NY	^GSPC	AMGN
AMKR	AMKR	Amkor Technology	Semi	US	Tech	https://www.marketscreener.com/quote/stock/AMKOR-TECHNOLOGY-INC-8349/	https://finance.yahoo.com/quote/AMKR/	http://www.amkor.com/	Semi packaging and test. Foruden Samsung Electronics er Amkor vigtig underlev til Nvidia. 28000 ansatte	\N	\N	0.4700	2026	\N	USD	\N	\N	\N	Semi	\N	.US	NY	^GSPC	AMKR
AMR	AMR	Alpha Metallurgical Resources	Mining	US	Basi	https://www.marketscreener.com/quote/stock/ALPHA-METALLURGICAL-RESOU-42845044/	https://finance.yahoo.com/quote/AMR?p=AMR	https://www.alphametresources.com	Metallurgisk kul - den større	\N	\N	0.5000	2026	\N	USD	\N	\N	\N	Mining	\N	.US	NY	^GSPC	AMR
AMS.MC	BME:AMS	Amadeus IT Group SA	Consulting(Tech)	ES	Tech	https://www.marketscreener.com/quote/stock/AMADEUS-IT-GROUP-S-A-4027320/	https://finance.yahoo.com/quote/AMS.MC/	https://amadeus.com/en	Verdens ledende, IT reservationssystemer til rejse-, hotel-, flybranchen mm.	\N	\N	0.3000	2026	\N	EUR	\N	\N	\N	Consulting(Tech)	\N	.MC	LON	^STOXX	AMS.MC
AMT	AMT	American Tower (data centers)	Property	US	REIT	https://www.marketscreener.com/quote/stock/AMERICAN-TOWER-CORPORATIO-9789139/	\N	https://www.americantower.com	Køber nov 21 CyrusOne (CON)	\N	\N	0.7000	2026	\N	USD	\N	\N	\N	Property	\N	.US	NY	^GSPC	AMT
AMZN	AMZN	Amazon.com	TechToCons	US	Tech	https://www.marketscreener.com/quote/stock/AMAZON-COM-INC-12864605/	\N	https://www.aboutamazon.com	\N	t	\N	0.5300	2026	\N	USD	\N	Magni7	\N	TechToCons	\N	.US	NY	^GSPC	AMZN
ANDE	ANDE	The Andersons	Food	US	C-St	https://www.marketscreener.com/quote/stock/THE-ANDERSONS-INC-8374/	https://finance.yahoo.com/quote/ANDE?p=ANDE&.tsrc=fin-srch	https://www.andersonsinc.com	Agricultural products (meget bredt)	\N	\N	0.8000	2026	\N	USD	\N	\N	\N	Food	\N	.US	NY	^GSPC	ANDE
ANET	ANET	Arista Networks	TechToProfs	US	Tech	https://www.marketscreener.com/quote/stock/ARISTA-NETWORKS-INC-16617752/	\N	https://www.arista.com	Network switches (som Cisco)	\N	\N	0.4700	2026	\N	USD	\N	\N	\N	TechToProfs	\N	.US	NY	^GSPC	ANET
ANF	ANF	Abercrombie & Fitch	Clothing	US	C-Di	https://www.marketscreener.com/quote/stock/ABERCROMBIE-FITCH-CO-11649/	https://finance.yahoo.com/quote/ANF	https://www.abercrombie.com	Tøj	\N	\N	0.4100	2026	\N	USD	\N	\N	\N	Clothing	\N	.US	NY	^GSPC	ANF
ANIM.MI	BIT:ANIM	Anima Holding SpA	Investment	IT	Fina	https://www.marketscreener.com/quote/stock/ANIMA-HOLDING-SPA-16253089/	\N	https://www.animasgr.it	\N	t	\N	0.5000	2026	\N	EUR	\N	\N	\N	Investment	\N	.MI	LON	^STOXX	ANIM.MI
ANTO.L	LON:ANTO	Antofagasta	Mining	UK	Basi	https://www.marketscreener.com/quote/stock/ANTOFAGASTA-PLC-4001646/	\N	https://www.antofagasta.co.uk	Copper Ore Mining and Selling	t	\N	0.6500	2026	\N	GBX	\N	\N	\N	Mining	\N	.L	LON	^FTSE	ANTO.L
AOF.DE	ETR:AOF	ATOSS Software	TechToProfs	DE	Tech	https://www.marketscreener.com/quote/stock/ATOSS-SOFTWARE-SE-435665/	https://finance.yahoo.com/quote/AOF.DE/	https://www.atoss.com/	Software til HR-funktion. 853 ansatte (2024)	\N	\N	\N	\N	\N	EUR	\N	\N	\N	TechToProfs	\N	.DE	LON	^GDAXI	AOF.DE
AOJ-B.CO	CPH:AOJ-B	Brødrene A & O Johansen	ConstrHomes	DK	C-Di	https://www.marketscreener.com/quote/stock/BR-DRENE-A-O-JOHANSEN-A-34446998/	https://finance.yahoo.com/quote/AOJ-P.CO?p=AOJ-P.CO&.tsrc=fin-srch	https://www.ao.dk	Homebuilding	\N	\N	0.3900	2026	\N	DKK	\N	\N	\N	ConstrHomes	\N	.CO	LON	^OMXC20	AOJ-B.CO
AOS	AOS	A.O.Smith	Manuf_Special	US	Indu	https://www.marketscreener.com/quote/stock/A-O-SMITH-CORPORATION-40311155/	\N	https://www.aosmith.com	\N	\N	\N	0.6000	2026	\N	USD	\N	\N	\N	Manuf_Special	\N	.US	NY	^GSPC	AOS
APA	APA	APA Corporation	Oil&Gas	US	Ener	https://www.marketscreener.com/quote/stock/APA-CORPORATION-11664/	https://finance.yahoo.com/quote/APA?p=APA&.tsrc=fin-srch	https://www.apacorp.com	Ops in US, Egypt, and UK	\N	\N	0.3500	2026	\N	USD	\N	\N	\N	Oil&Gas	\N	.US	NY	^GSPC	APA
APD	APD	Air Products and Chemicals 	Oil&Gas	US	Ener	https://www.marketscreener.com/quote/stock/AIR-PRODUCTS-CHEMICALS-11666/	https://finance.yahoo.com/quote/APD?p=APD&.tsrc=fin-srch	https://www.airproducts.com	Prod. and equip. for various gases	\N	\N	0.7000	2026	\N	USD	\N	\N	\N	Oil&Gas	\N	.US	NY	^GSPC	APD
APH	APH	Amphenol	ElectrComponents	US	Tech	https://www.marketscreener.com/quote/stock/AMPHENOL-CORPORATION-11668/	https://finance.yahoo.com/quote/APH?p=APH&.tsrc=fin-srch	https://www.amphenol.com	Electronic components, esp to EVs	\N	\N	0.5000	2026	\N	USD	\N	\N	\N	ElectrComponents	\N	.US	NY	^GSPC	APH
APO	APO	Apollo Global Management	Investment	US	Fina	https://www.marketscreener.com/quote/stock/APOLLO-GLOBAL-MANAGEMENT-131329862/	https://finance.yahoo.com/quote/APO?p=APO&.tsrc=fin-srch	https://www.apollo.com	Global investor som BAM, KKR, BX og BRK.B	\N	\N	0.7500	2026	\N	USD	\N	\N	\N	Investment	\N	.US	NY	^GSPC	APO
APP	APP	AppLovin Corporation	TechToProfs	US	Tech	https://www.marketscreener.com/quote/stock/APPLOVIN-CORPORATION-121407289/	https://finance.yahoo.com/quote/APP	https://www.applovin.com	Sw til optimering af markedsføring, især af mobile spil	t	\N	0.3800	2026	\N	USD	\N	\N	\N	TechToProfs	\N	.US	NY	^GSPC	APP
AQN.TO	TSE:AQN	Algonquin Power & Utilities	Util_Rnwb	CAN	Util	https://www.marketscreener.com/quote/stock/ALGONQUIN-POWER-UTILITIES-1409025/	\N	https://www.algonquinpower.com	Sustainable energy and water	\N	\N	0.7500	2026	\N	CAD	\N	\N	\N	Util_Rnwb	\N	.TO	NY	^GSPC	AQN.TO
AR	AR	Antero Resources Corp	Oil&Gas	US	Ener	https://www.marketscreener.com/quote/stock/ANTERO-RESOURCES-CORPORAT-14491401/	https://finance.yahoo.com/quote/AR?p=AR&.tsrc=fin-srch	https://www.anteroresources.com	Udvinder og eksporterer gas fra øst-USA	t	\N	0.4700	2026	\N	USD	\N	\N	\N	Oil&Gas	\N	.US	NY	^GSPC	AR
ARCC	ARCC	Ares Capital	BDC	US	Fina	https://www.marketscreener.com/quote/stock/ARES-CAPITAL-CORPORATION-40449523/	https://finance.yahoo.com/quote/ARCC	https://www.arescapitalcorp.com	Både gæld og equity-invest. Ares Mngt styrer.	t	\N	0.3200	2026	\N	USD	\N	\N	\N	BDC	\N	.US	NY	^GSPC	ARCC
ARE	ARE	Alexandria Real Estates	Property	US	REIT	https://www.marketscreener.com/quote/stock/ALEXANDRIA-REAL-ESTATE-EQ-11676/	https://finance.yahoo.com/quote/ARE	https://www.are.com	Life-science campuses, single-tenant, triple-net leased, tenants world's best biotechs. Dividend grower.	\N	\N	0.4700	2026	\N	USD	\N	\N	\N	Property	\N	.US	NY	^GSPC	ARE
ARES	ARES	Ares Management	Investment	US	Fina	https://www.marketscreener.com/quote/stock/ARES-MANAGEMENT-CORPORATI-50061101/	\N	https://www.aresmgmt.com	Investment services. Styrer også ARCC	\N	\N	0.6500	2026	\N	USD	\N	\N	\N	Investment	\N	.US	NY	^GSPC	ARES
ARGX.BR	EBR:ARGX	Argenx SE	Pharma	NL	Heal	https://www.marketscreener.com/quote/stock/ARGENX-SE-16911676/	https://finance.yahoo.com/quote/ARGX.BR/	http://www.argen-x.com/	Pipeline af mediciner mod autoimmune sygdomme. Også noteret på NASDAQ.	\N	\N	0.4700	2026	\N	EUR	\N	\N	\N	Pharma	\N	.BR	LON	^FCHI	ARGX.BR
ARI	ARI	Apollo Commercial (mortgages)	Mortgages	US	REIT	https://www.marketscreener.com/quote/stock/APOLLO-COMMERCIAL-REAL-ES-5587238/	\N	https://www.apollocref.com	Senior mortg. i commercial real-estate i US og Europa	\N	\N	0.5500	2026	\N	USD	\N	\N	\N	Mortgages	\N	.US	NY	^GSPC	ARI
ARM	ARM	Arm Holdings	Semi	UK	Tech	https://www.marketscreener.com/quote/stock/ARM-HOLDINGS-PLC-159091235/	https://finance.yahoo.com/quote/ARM?p=ARM&.tsrc=fin-srch	https://www.arm.com	Chips til stort set alle mobiltelefoner. IPO 14.9.23 på Nasdaq	t	\N	0.4000	2026	\N	USD	\N	\N	\N	Semi	\N	.US	NY	^GSPC	ARM
ARRY	ARRY	Array Technologies	Rnwb(Indu)	US	Indu	https://www.marketscreener.com/quote/stock/ARRAY-TECHNOLOGIES-INC-8433/	https://finance.yahoo.com/quote/ARRY?p=ARRY&.tsrc=fin-srch	https://arraytechinc.com	Solar equipment	\N	\N	0.4700	2026	\N	USD	\N	\N	\N	Rnwb(Indu)	\N	.US	NY	^GSPC	ARRY
ASAN	ASAN	Asana	TechToProfs	US	Tech	https://www.marketscreener.com/quote/stock/ASANA-INC-113108836/	https://finance.yahoo.com/quote/ASAN?p=ASAN&.tsrc=fin-srch	https://www.asana.com	Work management for teams	\N	\N	0.2500	2026	\N	USD	\N	\N	\N	TechToProfs	\N	.US	NY	^GSPC	ASAN
ASC.L	LON:ASC	Asos	Clothing	UK	C-Di	https://www.marketscreener.com/quote/stock/ASOS-PLC-4003595/	https://finance.yahoo.com/quote/asc.l?ltr=1	https://www.asosfoundation.org	\N	\N	\N	0.4400	2026	\N	GBX	\N	\N	\N	Clothing	\N	.L	LON	^FTSE	ASC.L
ASKER.ST	STO:ASKER	Asker Healthcare	Healthcare	SE	Heal	https://www.marketscreener.com/quote/stock/ASKER-HEALTHCARE-GROUP-AB-184899196/	https://finance.yahoo.com/quote/ASKER.ST/	https://www.asker.com/	Acquired 50 medical equipment and solutions companies in Europe. Høj vækst i top og bund forventes	t	\N	0.7000	2026	\N	SEK	\N	\N	\N	Healthcare	\N	.ST	LON	^OMX	ASKER.ST
ASM.AS	AMS:ASM	ASM International NV	Semi	NL	Tech	https://www.marketscreener.com/quote/stock/ASM-INTERNATIONAL-N-V-6312/	https://finance.yahoo.com/quote/ASM.AS/	https://www.asm.com/	Udstyr til chips-fremstilling	\N	\N	0.8000	2026	\N	EUR	\N	\N	\N	Semi	\N	.AS	LON	^AEX	ASM.AS
ASML.AS	AMS:ASML	ASML (Velthoven, NL)	Semi	NL	Tech	https://www.marketscreener.com/quote/stock/ASML-HOLDING-N-V-12002973/	https://finance.yahoo.com/quote/ASML.AS?p=ASML.AS	https://www.asml.com	LIthografisk udstyr til chip-fremstilling	t	\N	0.2900	2026	\N	EUR	\N	GRANOLA	\N	Semi	\N	.AS	LON	^AEX	ASML.AS
ASRNL.AS	AMS:ASRNL	ASR Nederland	Insurance	NL	Fina	https://www.marketscreener.com/quote/stock/ASR-NEDERLAND-N-V-28377340/	https://finance.yahoo.com/quote/ASRNL.AS/	http://www.asrnederland.nl/	35% livsfors, resten skadesforsikring o.m.a. Kun i NL. Godt udbytte. 8000 ansatte.	\N	\N	0.4500	2026	\N	EUR	\N	\N	\N	Insurance	\N	.AS	LON	^AEX	ASRNL.AS
ASSA-B.ST	CPH:ASSA-B	Assa-Abloy	Manuf_Special	SE	Indu	https://www.marketscreener.com/quote/stock/ASSA-ABLOY-AB-22363198/	https://finance.yahoo.com/quote/ASSA-B.ST?p=ASSA-B.ST	https://www.assaabloy.com	\N	\N	\N	0.4500	2026	\N	SEK	\N	\N	\N	Manuf_Special	\N	.ST	LON	^OMX	ASSA-B.ST
ASX	ASX	ASE Technology Hldg	Semi	Taiwan	Tech	https://www.marketscreener.com/quote/stock/ASE-TECHNOLOGY-HOLDING-CO-43344229/	https://finance.yahoo.com/quote/ASX?p=ASX&.tsrc=fin-srch	https://www.aseglobal.com	Semiconductor services	\N	\N	0.4500	2026	\N	USD	\N	\N	\N	Semi	\N	.US	NY	^GSPC	ASX
ATCO-B.ST	CPH:ATCO-B	Atlas Copco B	Manuf_Big	SE	Indu	https://www.marketscreener.com/quote/stock/ATLAS-COPCO-AB-43306890/	https://finance.yahoo.com/quote/ATCO-B.ST?p=ATCO-B.ST	https://www.atlascopco.com	Maskiner: Kompressorer 70% af salg	\N	\N	0.5000	2026	\N	SEK	\N	\N	\N	Manuf_Big	\N	.ST	LON	^OMX	ATCO-B.ST
ATD.TO	TSE:ATD	Alimentation Couche-Tard	Retail	CAN	C-St	https://www.marketscreener.com/quote/stock/ALIMENTATION-COUCHE-TARD--143457395/	https://finance.yahoo.com/quote/ATD.TO?p=ATD.TO	https://www.couche-tard.com/	Convenience stores (som 7-eleven)	\N	\N	0.5000	2026	\N	CAD	\N	\N	\N	Retail	\N	.TO	NY	^GSPC	ATD.TO
ATHM	ATHM	Autohome	Holiday	China	C-Di	https://www.marketscreener.com/quote/stock/AUTOHOME-INC-15200591/	\N	https://ir.autohome.com.cn	\N	\N	\N	0.7000	2026	\N	USD	\N	\N	\N	Holiday	\N	.US	NY	^GSPC	ATHM
ATI	ATI	ATI Inc	Defense	US	Indu	https://www.marketscreener.com/quote/stock/ATI-INC-11627/	https://finance.yahoo.com/quote/ATI/	https://www.atimaterials.com/	Special materials and components for aircrafts	\N	\N	0.2700	2026	\N	USD	\N	\N	\N	Defense	\N	.US	NY	^GSPC	ATI
ATKR	ATKR	Atkore 	Electronics	US	Indu	https://www.marketscreener.com/quote/stock/ATKORE-INC-28377312/	https://finance.yahoo.com/quote/ATKR?p=ATKR&.tsrc=fin-srch	https://www.atkore.com	Elektriske installationer, 2*5 stjerner	\N	\N	\N	\N	\N	USD	\N	\N	\N	Electronics	\N	.US	NY	^GSPC	ATKR
ATRO	ATRO	Astronics Corp	Defense	US	Indu	https://www.marketscreener.com/quote/stock/ASTRONICS-CORPORATION-8485/	https://finance.yahoo.com/quote/ATRO/	https://www.astronics.com/	Advanced aircraft technologies	\N	\N	0.7000	2026	\N	USD	\N	\N	\N	Defense	\N	.US	NY	^GSPC	ATRO
AU	AU	Anglogold Ashanti	Gold	US	Basi	https://www.marketscreener.com/quote/stock/ANGLOGOLD-ASHANTI-PLC-11712/	https://finance.yahoo.com/quote/AU/	https://www.anglogoldashanti.com/	Gold mining company in Africa, Australia, and the Americas	\N	\N	\N	\N	\N	USD	\N	\N	\N	Gold	\N	.US	NY	^GSPC	AU
AV.L	LON:AV	Aviva plc	Insurance	UK	Fina	https://www.marketscreener.com/quote/stock/AVIVA-PLC-4000581/	\N	https://www.aviva.com	UK-baseret forsikringsselskab	t	\N	0.5800	2026	\N	GBX	\N	\N	\N	Insurance	\N	.L	LON	^FTSE	AV.L
AVAV	AVAV	AeroVironment, 	Defense	US	Indu	https://www.marketscreener.com/quote/stock/AEROVIRONMENT-INC-41751/	https://finance.yahoo.com/quote/AVAV/financials?p=AVAV	https://www.avinc.com	Uncrewed aircraft systems, loitering munition systems, uncrewed ground vehicles, and high-altitude pseudo-satellites	t	\N	0.7500	2026	\N	USD	\N	\N	\N	Defense	\N	.US	NY	^GSPC	AVAV
AVGO	AVGO	Broadcom	Semi	US	Tech	https://www.marketscreener.com/quote/stock/BROADCOM-INC-42668543/	https://finance.yahoo.com/quote/AVGO?p=AVGO&.tsrc=fin-srch	https://www.broadcom.com	Networking chips (som Marvel)	t	\N	0.5600	2026	\N	USD	\N	\N	\N	Semi	\N	.US	NY	^GSPC	AVGO
AWI	AWI	Armstrong World Industries	ConstrHomes	US	C-Di	https://www.marketscreener.com/quote/stock/ARMSTRONG-WORLD-INDUSTRIE-34370/	https://finance.yahoo.com/quote/AWI?p=AWI&.tsrc=fin-srch	https://www.armstrongceilings.com	System-løsninger til husbyggeri. US og CAN. God driftsmargin: 25%, rolig vækst og et vist udbytte (1,4%)	\N	\N	0.5300	2026	\N	USD	\N	\N	\N	ConstrHomes	\N	.US	NY	^GSPC	AWI
AXIA	AXIA	Axia Energia ADR (Centrais Elétricas Brasileiras S.A. - Eletrobrás)	Util_MixedFuel	Brazil	Util	https://www.marketscreener.com/quote/stock/CENTRAIS-ELETRICAS-BRASIL-4205439/	https://finance.yahoo.com/quote/AXIA/	https://www.eletrobras.com/	Kraftværker spundet ud af Petrobras, Brasilien	\N	\N	0.6500	2026	\N	USD	\N	\N	\N	Util_MixedFuel	\N	.US	NY	^GSPC	AXIA
AXON	AXON	Axon Enterprise, 	Defense	US	Indu	https://www.marketscreener.com/quote/stock/AXON-ENTERPRISE-INC-34532659/	https://finance.yahoo.com/quote/AXON/	https://www.axon.com/	Sikkerhedsudstyr til personligt forsvar, Tazer-guns, body-cams, overvågningsudstyr mv.  	\N	\N	0.5300	2026	\N	USD	\N	\N	\N	Defense	\N	.US	NY	^GSPC	AXON
AXP	AXP	American Express	Bank	US	Fina	https://www.marketscreener.com/quote/stock/AMERICAN-EXPRESS-COMPANY-4814/	https://finance.yahoo.com/quote/AXP/	https://www.americanexpress.com/	Charge and credit card payment products, 	\N	\N	0.7000	2026	\N	USD	\N	\N	\N	Bank	\N	.US	NY	^GSPC	AXP
AZN.L	LON:AZN	AstraZeneca	Pharma	SE	Heal	https://www.marketscreener.com/quote/stock/ASTRAZENECA-PLC-4000930/	https://finance.yahoo.com/quote/AZN.L?p=AZN.L&.tsrc=fin-srch	https://www.astrazeneca.co.uk	\N	\N	\N	0.7200	2026	\N	GBX	\N	GRANOLA	\N	Pharma	\N	.L	LON	^FTSE	AZN.L
AZN.ST	STO:AZN	AstraZeneca (Sverige)	Pharma	US	Heal	https://www.marketscreener.com/quote/stock/ASTRAZENECA-PLC-9065830/	https://finance.yahoo.com/quote/AZN.ST?p=AZN.ST&.tsrc=fin-srch	https://www.astrazeneca.co.uk	\N	t	\N	0.5800	2026	\N	SEK	\N	\N	\N	Pharma	\N	.ST	LON	^OMX	AZN.ST
AZO	AZO	AutoZone	Automotive	US	C-Di	https://www.marketscreener.com/quote/stock/AUTOZONE-INC-11746/	https://finance.yahoo.com/quote/AZO?p=AZO&.tsrc=fin-srch	https://www.autozone.com	Autodele af enhver art	\N	\N	0.7200	2026	\N	USD	\N	\N	\N	Automotive	\N	.US	NY	^GSPC	AZO
B	B	Barrick Mining Corp (Barrick Gold)	Gold	CAN	Basi	https://www.marketscreener.com/quote/stock/BARRICK-MINING-CORPORATIO-56593706/	https://finance.yahoo.com/quote/B/news/	https://www.barrick.com	Explores for gold, copper, silver, and energy materials	t	\N	0.5500	2026	\N	USD	\N	\N	\N	Gold	\N	.US	NY	^GSPC	B
BA	BA	Boeing	Trpt_Airline	US	Indu	https://www.marketscreener.com/quote/stock/BOEING-4816/	https://finance.yahoo.com/quote/BA?p=BA&.tsrc=fin-srch	https://www.boeing.com	Airline	\N	\N	0.5500	2026	\N	USD	\N	\N	\N	Trpt_Airline	\N	.US	NY	^GSPC	BA
BA.L	LON:BA	BAE Systems	Defense	UK	Indu	https://www.marketscreener.com/quote/stock/BAE-SYSTEMS-PLC-9583545/	https://finance.yahoo.com/quote/BA.L?p=BA.L&.tsrc=fin-srch	https://www.baesystems.com	95% af oms er defence (2021)	\N	\N	0.4500	2026	\N	GBX	\N	\N	\N	Defense	\N	.L	LON	^FTSE	BA.L
BABA	BABA	Alibaba	TechToCons	China	Tech	https://www.marketscreener.com/quote/stock/ALIBABA-GROUP-HOLDING-LIM-17916677/	\N	https://www.alibabagroup.com	\N	\N	\N	0.4400	2026	\N	USD	\N	\N	\N	TechToCons	\N	.US	NY	^GSPC	BABA
BAC	BAC	Bank of America	Bank	US	Fina	https://www.marketscreener.com/quote/stock/BANK-OF-AMERICA-CORPORATI-11751/	\N	https://www.bankofamerica.com	#2 US-Bank 2021	\N	\N	0.4000	2026	\N	USD	\N	\N	\N	Bank	\N	.US	NY	^GSPC	BAC
BAKKA.OL	OSL:BAKKA	P/F Bakkafrost	Food	NO	C-St	https://www.marketscreener.com/quote/stock/BAKKAFROST-6103708/	https://finance.yahoo.com/quote/BAKKA.OL?p=BAKKA.OL&.tsrc=fin-srch	https://www.bakkafrost.com	Laks	\N	\N	0.5600	2026	\N	NOK	\N	\N	\N	Food	\N	.OL	LON	^OSEBX	BAKKA.OL
BAM	BAM	Brookfield Asset Mngt	Investment	US	Fina	https://www.marketscreener.com/quote/stock/BROOKFIELD-ASSET-MANAGEME-147612562/	\N	https://bam.brookfield.com	Infrastructure fund	\N	\N	0.6200	2026	\N	USD	\N	\N	\N	Investment	\N	.US	NY	^GSPC	BAM
BARC.L	LON:BARC	Barclays	Bank	UK	Fina	https://www.marketscreener.com/quote/stock/BARCLAYS-PLC-9583556/	\N	https://www.home.barclays	\N	t	\N	0.2500	2026	\N	GBX	\N	\N	\N	Bank	\N	.L	LON	^FTSE	BARC.L
BAS.DE	ETR:BAS	BASF	Chemical	DE	Indu	https://www.marketscreener.com/quote/stock/BASF-SE-6443227/	https://finance.yahoo.com/quote/BAS.DE?p=BAS.DE&.tsrc=fin-srch	https://www.basf.com	\N	\N	\N	\N	\N	\N	EUR	\N	\N	\N	Other[Indu]	7	.DE	LON	^GDAXI	BAS.DE
BATG.L	LON:BATG	L&G Battery Value-Chain UCITS ETF (GBP)	Batteries	UK	Indu	https://www.marketscreener.com/quote/etf/L-G-BATTERY-VALUE-CH-UCIT-41709172/	\N	\N	Alternativ: CHRG.L	\N	\N	0.6500	2026	\N	GBX	\N	\N	\N	Other[Indu]	7	.L	LON	^FTSE	BATG.L
BAVA.CO	CPH:BAVA	Bavarian Nordic	Pharma	DK	Heal	https://www.marketscreener.com/quote/stock/BAVARIAN-NORDIC-A-S-1412846/	https://finance.yahoo.com/quote/BAVA.CO?p=BAVA.CO&.tsrc=fin-srch	https://www.bavarian-nordic.com	\N	\N	\N	0.4500	2026	\N	DKK	\N	\N	\N	Pharma	\N	.CO	LON	^OMXC20	BAVA.CO
BAYN.DE	ETR:BAYN	Bayer	Pharma	DE	Heal	https://www.marketscreener.com/quote/stock/BAYER-AG-436063/	https://finance.yahoo.com/quote/BAYN.DE/	https://www.bayer.com	\N	\N	\N	\N	\N	\N	EUR	\N	\N	\N	Pharma	\N	.DE	LON	^GDAXI	BAYN.DE
BBU	BBU	Brookfield Business Partners	Investment	US	Fina	https://www.marketscreener.com/quote/stock/BROOKFIELD-BUSINESS-PARTN-28742439/	https://finance.yahoo.com/quote/BBU?p=BBU	https://bbu.brookfield.com/en	\N	\N	\N	\N	\N	\N	USD	\N	\N	\N	Investment	\N	.US	NY	^GSPC	BBU
BBVA	BBVA	Banco Bilbao Vizcaya Argentaria	Bank	ES	Fina	https://www.marketscreener.com/quote/stock/BBVA-11774/	\N	https://www.bbva.com	Spansk bank, også aktiv i Mexico, Tyrkiet og Sydamerika	\N	\N	0.4500	2026	\N	USD	\N	\N	\N	Bank	\N	.US	NY	^GSPC	BBVA
BBY.L	LON:BBY	Balfour Beatty	Construction	UK	Indu	https://www.marketscreener.com/quote/stock/BALFOUR-BEATTY-PLC-4000600/	https://finance.yahoo.com/quote/BBY.L?p=BBY.L	https://www.balfourbeatty.com	\N	\N	\N	0.3700	2026	\N	GBX	\N	\N	\N	Construction	\N	.L	LON	^FTSE	BBY.L
BCE.TO	TSE:BCE	BCE	Telecom	CAN	Tele	https://www.marketscreener.com/quote/stock/BCE-INC-1409161/	https://finance.yahoo.com/quote/BCE/profile?p=BCE	https://www.bce.ca	Canada-based communications company that provides Bell broadband wireless, Internet, television (TV), media and business communications services	\N	\N	0.3800	2026	\N	CAD	\N	\N	\N	Telecom	\N	.TO	NY	^GSPC	BCE.TO
BCIC	BCIC	BCP Investement Corp	BDC	US	Fina	https://www.marketscreener.com/quote/stock/BCP-INVESTMENT-CORP-56727712/	https://finance.yahoo.com/quote/BCIC/	http://www.bcpinvestmentcorporation.com/	Portman Ridge Finance Corporation (the Fund) is a non-diversified closed-end investment company.	\N	\N	0.3700	2026	\N	USD	\N	\N	\N	BDC	\N	.US	NY	^GSPC	BCIC
BDX	BDX	Becton Dickinson	Electronics_Medical	US	Indu	https://www.marketscreener.com/quote/stock/BECTON-DICKINSON-AND-COMP-11801/	\N	https://www.bd.com	\N	\N	\N	0.5000	2026	\N	USD	\N	\N	\N	Other[Indu]	7	.US	NY	^GSPC	BDX
BE	BE	Bloom Energy Corp	Rnwb(Indu)	US	Indu	https://www.marketscreener.com/quote/stock/BLOOM-ENERGY-CORPORATION-45031987/	https://finance.yahoo.com/quote/BE?p=BE&.tsrc=fin-srch	https://www.bloomenergy.com	Fuel cells	\N	\N	0.4500	2026	\N	USD	\N	\N	\N	Rnwb(Indu)	\N	.US	NY	^GSPC	BE
BEKE	BEKE	KE Holdings	Property	China	REIT	https://www.marketscreener.com/quote/stock/KE-HOLDINGS-INC-110767058/	\N	https://bj.ke.com	Service til ejendoms-handlere	\N	\N	0.2700	2026	\N	USD	\N	\N	\N	Property	\N	.US	NY	^GSPC	BEKE
BEPC	BEPC	Brookfield Renewables Corp	Util_Rnwb	Intl	Util	https://www.marketscreener.com/quote/stock/BROOKFIELD-RENEWABLE-CORP-110155151/	https://finance.yahoo.com/quote/BEPC?p=BEPC&.tsrc=fin-srch	https://bep.brookfield.com/bepc	Kapitalfond i grøn energi	\N	\N	0.6500	2026	\N	USD	\N	\N	\N	Util_Rnwb	\N	.US	NY	^GSPC	BEPC
BESI.AS	AMS:BESI	BE Semiconductor Industries	Semi	NL	Tech	https://www.marketscreener.com/quote/stock/BE-SEMICONDUCTOR-INDUSTRI-6318/	https://finance.yahoo.com/quote/BESI.AS/balance-sheet?p=BESI.AS	https://www.besi.com	Semiconductor assembly equipment	t	\N	0.5600	2026	\N	EUR	\N	\N	\N	Semi	\N	.AS	LON	^AEX	BESI.AS
BG	BG	Bunge	Agro	US	Basi	https://www.marketscreener.com/quote/stock/BUNGE-LIMITED-11825/	https://finance.yahoo.com/quote/BG?p=BG&.tsrc=fin-srch	https://www.bunge.com	Hvedepusher i Nordamerika	\N	\N	0.6000	2026	\N	USD	\N	\N	\N	Agro	\N	.US	NY	^GSPC	BG
BHP.L	LON:BHP	BHP Group	Mining	UK	Basi	https://www.marketscreener.com/quote/stock/BHP-GROUP-LIMITED-6492795/	https://finance.yahoo.com/quote/BHP.L?p=BHP.L&.tsrc=fin-srch	https://www.bhp.com/	\N	t	\N	0.5000	2026	\N	GBX	\N	\N	\N	Mining	\N	.L	LON	^FTSE	BHP.L
BIDU	BIDU	Baidu	TechToCons	China	Tech	https://www.marketscreener.com/quote/stock/BAIDU-INC-8563/	\N	https://www.baidu.com	Kina's Google-søgemaskine og AI-frontløber	\N	\N	0.5000	2026	\N	USD	\N	AI_Core	\N	TechToCons	\N	.US	NY	^GSPC	BIDU
BIIB	BIIB	Biogen	Pharma	US	Heal	https://www.marketscreener.com/quote/stock/BIOGEN-INC-4853/	\N	https://www.biogen.com	\N	\N	\N	0.4000	2026	\N	USD	\N	\N	\N	Pharma	\N	.US	NY	^GSPC	BIIB
BILI	BILI	Bilibili (games & broadcasting)	TechToCons	China	Tech	https://www.marketscreener.com/quote/stock/BILIBILI-INC-42503507/	\N	https://www.bilibili.com	YouTube-China: 'All the videos you like' (slogan)	\N	\N	0.5000	2026	\N	USD	\N	\N	\N	TechToCons	\N	.US	NY	^GSPC	BILI
BILL	BILL	Bill.com Holdings	TechToProfs	US	Tech	https://www.marketscreener.com/quote/stock/BILL-COM-HOLDINGS-INC-82519082/	https://finance.yahoo.com/quote/BILL?p=BILL&.tsrc=fin-srch	https://www.bill.com	Automates back-office financial operations for small and midsize businesses worldwide. #2 i WCLD 17.9.21	\N	\N	0.3700	2026	\N	USD	\N	\N	\N	TechToProfs	\N	.US	NY	^GSPC	BILL
BIP	BIP	Brookfield Infrastructure	Property	US	REIT	https://www.marketscreener.com/quote/stock/BROOKFIELD-INFRASTRUCTURE-807081/	\N	https://bip.brookfield.com	\N	\N	\N	\N	\N	\N	USD	\N	\N	\N	Property	\N	.US	NY	^GSPC	BIP
BIPC	BIPC	Brookfield Infrastructure Corporation	Property	US	REIT	https://www.marketscreener.com/quote/stock/BROOKFIELD-INFRASTRUCTURE-105311078/	https://finance.yahoo.com/quote/BIPC?p=BIPC&.tsrc=fin-srch	https://bip.brookfield.com/bipc	Arbejder i UK. BIP er tilsv. LP	\N	\N	0.4000	2026	\N	USD	\N	\N	\N	Property	\N	.US	NY	^GSPC	BIPC
BIT.TO	TSE:BIR	Birchcliff Energy	Oil&Gas	CAN	Ener	https://www.marketscreener.com/quote/stock/BIRCHCLIFF-ENERGY-LTD-1409201/	https://finance.yahoo.com/quote/BIR.TO?p=BIR.TO&.tsrc=fin-srch	https://www.birchcliffenergy.com	Canadisk gas	\N	\N	0.2500	2026	\N	CAD	\N	\N	\N	Oil&Gas	\N	.TO	NY	^GSPC	BIT.TO
BJRI	BJRI	BJ's Restaurants	Restaurants	US	C-Di	https://www.marketscreener.com/quote/stock/BJ-S-RESTAURANTS-INC-8570/	\N	https://www.bjsrestaurants.com	US: 211 restauranter i 29 stater	\N	\N	0.3800	2026	\N	USD	\N	\N	\N	Restaurants	\N	.US	NY	^GSPC	BJRI
BK	BK	B of NY Mellon	Bank	US	Fina	https://www.marketscreener.com/quote/stock/BANK-OF-NEW-YORK-MELLON-C-11848/	\N	https://www.bnymellon.com	Investment banking	\N	\N	0.6800	2026	\N	USD	\N	\N	\N	Bank	\N	.US	NY	^GSPC	BK
BKNG	BKNG	Booking Hldgs	Holiday	US	C-Di	https://www.marketscreener.com/quote/stock/BOOKING-HOLDINGS-INC-41613106/	https://finance.yahoo.com/quote/BKNG?p=BKNG&.tsrc=fin-srch	https://www.bookingholdings.com	Travel reservations	\N	\N	0.6000	2026	\N	USD	\N	\N	\N	Holiday	\N	.US	NY	^GSPC	BKNG
BKR	BKR	Baker Hughes	Oil&Gas	US	Ener	https://www.marketscreener.com/quote/stock/BAKER-HUGHES-COMPANY-40311111/	https://finance.yahoo.com/quote/BKR/	https://www.bakerhughes.com/	Teknologi og tjenester til energiindustri (6,7 mia/27% i USA 2023)	\N	\N	0.4700	2026	\N	USD	\N	\N	\N	Oil&Gas	\N	.US	NY	^GSPC	BKR
BL	BL	Blackline 	TechToProfs	US	Tech	https://www.marketscreener.com/quote/stock/BLACKLINE-INC-31740369/	\N	https://www.blackline.com/	Financial accounting as SaaS	\N	\N	0.5000	2026	\N	USD	\N	\N	\N	TechToProfs	\N	.US	NY	^GSPC	BL
BLBD	BLBD	Blue Bird Innovation	Manuf_Special	US	Indu	https://www.marketscreener.com/quote/stock/BLUE-BIRD-CORPORATION-21452859/	https://finance.yahoo.com/quote/BLBD/	https://www.blue-bird.com	Heavy machinery and trucks, også green	\N	\N	\N	\N	\N	USD	\N	\N	\N	Manuf_Special	\N	.US	NY	^GSPC	BLBD
BLD	BLD	Topbuild	Construction	US	Indu	https://www.marketscreener.com/quote/stock/TOPBUILD-CORP-22762520/	https://finance.yahoo.com/quote/BLD?p=BLD&.tsrc=fin-srch	https://www.topbuild.com	Udfører isolering og sælger diverese byggeprodukter	\N	\N	\N	\N	\N	USD	\N	\N	\N	Construction	\N	.US	NY	^GSPC	BLD
BLK	BLK	Blackrock	Investment	US	Fina	https://www.marketscreener.com/quote/stock/BLACKROCK-INC-176512022/	https://finance.yahoo.com/quote/BLK/	https://www.blackrock.com	Blandt verdens største formueforvaltere	\N	\N	0.5000	2026	\N	USD	\N	\N	\N	Investment	\N	.US	NY	^GSPC	BLK
BLND	BLND	Blend Labs, 	Consulting(Tech)	US	Tech	https://www.marketscreener.com/quote/stock/BLEND-LABS-INC-124796047/	https://finance.yahoo.com/quote/BLND/	https://blend.com/	Cloudbaserede software til banker 	\N	\N	0.3100	2026	\N	USD	\N	\N	\N	Consulting(Tech)	\N	.US	NY	^GSPC	BLND
BLNK	BLNK	Blink Charging	Rnwb(Indu)	US	Indu	https://www.marketscreener.com/quote/stock/BLINK-CHARGING-CO-40834333/	\N	https://www.blinkcharging.com	electric vehicle charging equipment	\N	\N	0.2000	2026	\N	USD	\N	\N	\N	Rnwb(Indu)	\N	.US	NY	^GSPC	BLNK
BLX.TO	TSE:BLX	Boralex	Rnwb(Ener)	CAN	Ener	https://www.marketscreener.com/quote/stock/BORALEX-INC-1409215/	https://finance.yahoo.com/quote/BLX.TO/	https://www.boralex.com	Sustainable power generating in Canada, France, US, and UK	\N	\N	0.4000	2026	\N	CAD	\N	\N	\N	Rnwb(Ener)	\N	.TO	NY	^GSPC	BLX.TO
BMNR	BMNR	Bitmine Immersion Technologies	Crypto	US	Fina	https://www.marketscreener.com/quote/stock/BITMINE-IMMERSION-TECHNOL-122145243/	https://finance.yahoo.com/quote/BMNR/	https://bitminetech.io/	Oprindeligt leverandør af blockchain tech og services, men sprang i foråret ud som ejer af stor Etherum-kapital	\N	\N	0.4400	2026	\N	USD	\N	\N	\N	Crypto	\N	.US	NY	^BTC	BMNR
BMO.TO	TSE:BMO	Bank of Montreal	Bank	CAN	Fina	https://www.marketscreener.com/quote/stock/BANK-OF-MONTREAL-1409224/	\N	https://www.bmo.com	\N	\N	\N	0.6300	2026	\N	CAD	\N	\N	\N	Bank	\N	.TO	NY	^GSPC	BMO.TO
BMRN	BMRN	BioMarin Pharmaceutical	Pharma	US	Heal	https://www.marketscreener.com/quote/stock/BIOMARIN-PHARMACEUTICAL-I-8587/	https://finance.yahoo.com/quote/BMRN?p=BMRN&.tsrc=fin-srch	https://www.biomarin.com/	\N	\N	\N	0.3000	2026	\N	USD	\N	\N	\N	Pharma	\N	.US	NY	^GSPC	BMRN
BMW.DE	ETR:BMW	Bayrischen Motoren Werke	Automotive	DE	C-Di	https://www.marketscreener.com/quote/stock/BAYERISCHE-MOTOREN-WERKE-435722/	\N	https://www.bmwgroup.com	\N	\N	\N	0.6000	2026	\N	EUR	\N	\N	\N	Automotive	\N	.DE	LON	^GDAXI	BMW.DE
BMY	BMY	Bristol-Meyers Squibb	Pharma	US	Heal	https://www.marketscreener.com/quote/stock/BRISTOL-MYERS-SQUIBB-COMP-11877/	\N	https://www.bms.com	Lægemidler	t	\N	\N	\N	\N	USD	\N	\N	\N	Pharma	\N	.US	NY	^GSPC	BMY
CAR	CAR	Avis Budget	Holiday	US	C-Di	https://www.marketscreener.com/quote/stock/AVIS-BUDGET-GROUP-INC-12212/	https://finance.yahoo.com/quote/CAR?p=CAR&.tsrc=fin-srch	https://www.avisbudgetgroup.com	Biludlejning	\N	\N	0.5500	2026	\N	USD	\N	\N	\N	Holiday	\N	.US	NY	^GSPC	CAR
BN	BN	Brookfield Corporation	Investment	CAN	Fina	https://www.marketscreener.com/quote/stock/BROOKFIELD-CORPORATION-147612507/	https://finance.yahoo.com/quote/BN?p=BN&.tsrc=fin-srch	https://www.brookfield.com	Ejer og operatør af reale investeringer (energi, infrastruktur,  blandet industri og service, ejendomme mm). 200.000 ansatte.	\N	\N	0.3500	2026	\N	USD	\N	\N	\N	Investment	\N	.US	NY	^GSPC	BN
BN.PA	EPA:BN	Danone SA	Food	FR	C-St	https://www.marketscreener.com/quote/stock/DANONE-4634/	\N	https://www.danone.com	Mælkeprodukter	\N	\N	0.4400	2026	\N	EUR	\N	\N	\N	Food	\N	.PA	LON	^FCHI	BN.PA
BNP.PA	EPA:BNP	BNP Paribas	Bank	FR	Fina	https://www.marketscreener.com/quote/stock/BNP-PARIBAS-4618/	\N	https://group.bnpparibas	Frankrings største bank	t	\N	0.5000	2026	\N	EUR	\N	\N	\N	Bank	\N	.PA	LON	^FCHI	BNP.PA
BNS	BNS	Bank of Nova Scotia	Bank	CAN	Fina	https://www.marketscreener.com/quote/stock/THE-BANK-OF-NOVA-SCOTIA-1409234/	\N	https://www.scotiabank.com	\N	\N	\N	0.2100	2026	\N	USD	\N	\N	\N	Bank	\N	.US	NY	^GSPC	BNS
BNTX	BNTX	BioNTech	Pharma	DE	Heal	https://www.marketscreener.com/quote/stock/BIONTECH-SE-66771992/	https://finance.yahoo.com/quote/BNTX/	https://www.biontech.de	\N	t	\N	0.6000	2026	\N	USD	\N	\N	\N	Pharma	\N	.US	NY	^GSPC	BNTX
BOL.ST	STO:BOL	Boliden	Mining	SE	Basi	https://www.marketscreener.com/quote/stock/BOLIDEN-58808448/	https://finance.yahoo.com/quote/BOL.ST?p=BOL.ST&.tsrc=fin-srch	https://www.boliden.com	Miner med zink, kobber og bly	t	\N	0.4500	2026	\N	SEK	\N	\N	\N	Mining	\N	.ST	LON	^OMX	BOL.ST
BP.L	LON:BP	BP	Oil&Gas	UK	Ener	https://www.marketscreener.com/quote/stock/BP-PLC-9590188/	https://finance.yahoo.com/quote/BP.L?p=BP.L&.tsrc=fin-srch-v1	https://www.bptargetneutral.com	\N	\N	\N	0.6100	2026	\N	GBX	\N	\N	\N	Oil&Gas	\N	.L	LON	^FTSE	BP.L
BR	BR	Broadridge Financial Solutions	TechToProfs	US	Tech	https://www.marketscreener.com/quote/stock/BROADRIDGE-FINANCIAL-SOLU-11906/	\N	https://www.broadridge.com	\N	\N	\N	0.4400	2026	\N	USD	\N	\N	\N	TechToProfs	\N	.US	NY	^GSPC	BR
BRDCY	BRDCY	Bridgestone	Automotive	Japan	C-Di	https://www.marketscreener.com/quote/stock/BRIDGESTONE-CORPORATION-120787917/	\N	https://www.bridgestone.co.jp	\N	\N	\N	\N	\N	\N	USD	\N	\N	\N	Automotive	\N	.US	NY	^GSPC	BRDCY
BRK-B	BRK.B	Berkshire Hathaway B	Investment	US	Fina	https://www.marketscreener.com/quote/stock/BERKSHIRE-HATHAWAY-INC-11916/	\N	https://www.berkshirehathaway.com	\N	\N	\N	0.6900	2026	\N	USD	\N	\N	\N	Investment	\N	.US	NY	^GSPC	BRK-B
BSAC	BSAC	Banco Santander-Chile	Bank	Chile	Fina	https://www.marketscreener.com/quote/stock/BANCO-SANTANDER-S-A-69308/	\N	https://www.santander.com	\N	\N	\N	0.4000	2026	\N	USD	\N	\N	\N	Bank	\N	.US	NY	^GSPC	BSAC
BSL.AX	ASX:BSL	Bluescope Steel	Mining	AUS	Basi	https://www.marketscreener.com/quote/stock/BLUESCOPE-STEEL-LIMITED-6492515/	https://finance.yahoo.com/quote/BSL.AX?p=BSL.AX&.tsrc=fin-srch	https://www.bluescopesteel.com.au/	Stål-værker og stål-baserede råvarer	\N	\N	0.6000	2026	\N	AUD	\N	\N	\N	Mining	\N	.AX	HKG	^HSI	BSL.AX
BSX	BSX	Boston Scientific	Electronics_Medical	US	Indu	https://www.marketscreener.com/quote/stock/BOSTON-SCIENTIFIC-CORPORA-11935/	\N	https://www.bostonscientific.com	Udstyr til medicinsk anvendelse	\N	\N	0.3500	2026	\N	USD	\N	\N	\N	Other[Indu]	7	.US	NY	^GSPC	BSX
BT-A.L	LON:BT.A	BT Group	Telecom	UK	Tele	https://www.marketscreener.com/quote/stock/BT-GROUP-PLC-4003616/	https://finance.yahoo.com/quote/BT-A.L?p=BT-A.L&.tsrc=fin-srch	https://www.globalservices.bt.com	\N	\N	\N	0.6700	2026	\N	GBX	\N	\N	\N	Telecom	\N	.L	LON	^FTSE	BT-A.L
BTG	BTG	B2GOLD	Gold	CAN	Basi	https://www.marketscreener.com/quote/stock/B2GOLD-CORP-13369677/	https://finance.yahoo.com/quote/BTG/	http://www.b2gold.com/	3 gold mines in Nicaragua, the Philippines and Namibia	\N	\N	0.4500	2026	\N	USD	\N	\N	\N	Gold	\N	.US	NY	^GSPC	BTG
BWA	BWA	BorgWarner	Automotive	US	C-Di	https://www.marketscreener.com/quote/stock/BORGWARNER-INC-40311128/	https://finance.yahoo.com/quote/BWA?p=BWA&.tsrc=fin-srch	https://www.borgwarner.com	Autodele af enhver art	\N	\N	0.6700	2026	\N	USD	\N	\N	\N	Automotive	\N	.US	NY	^GSPC	BWA
BWLPG.OL	OSL:BWLPG	BW LPG 	Trpt_Ship (Ener)	Singapore	Ener	https://www.marketscreener.com/quote/stock/BW-LPG-LIMITED-14976268/	https://finance.yahoo.com/quote/BWLPG.OL?p=BWLPG.OL&.tsrc=fin-srch	https://www.bwlpg.com	Gas-transport pr skib	\N	\N	0.6000	2026	\N	NOK	\N	\N	\N	Trpt_Ship (Ener)	\N	.OL	LON	^OSEBX	BWLPG.OL
BWXT	BWXT	BWX Technologies	Defense	US	Indu	https://www.marketscreener.com/quote/stock/BWX-TECHNOLOGIES-INC-22837338/	https://finance.yahoo.com/quote/BWXT/	http://www.bwxt.com/	Nuclear components, specielt til militære formål	\N	\N	0.5000	2026	\N	USD	\N	\N	\N	Defense	\N	.US	NY	^GSPC	BWXT
BX	BX	Blackstone Group	Investment	US	Fina	https://www.marketscreener.com/quote/stock/BLACKSTONE-INC-60951400/	https://finance.yahoo.com/quote/BX?p=BX&.tsrc=fin-srch	https://www.blackstone.com/	Alternative asset manager. Købt QTS (data centers) i juni 2021	\N	\N	0.3100	2026	\N	USD	\N	\N	\N	Investment	\N	.US	NY	^GSPC	BX
BXMT	BXMT	Blackstone Mortgage (commercial)	Mortgages	US	REIT	https://www.marketscreener.com/quote/stock/BLACKSTONE-MORTGAGE-TRUST-13159221/	\N	https://www.blackstonemortgagetrust.com	Office(36%), multifamily(27%), hospitality(18%), 2024juli.	t	\N	0.4000	2026	\N	USD	\N	\N	\N	Mortgages	\N	.US	NY	^GSPC	BXMT
BXSL	BXSL	Blackstone Secured Lending	BDC	US	Fina	https://www.marketscreener.com/quote/stock/BLACKSTONE-SECURED-LENDIN-128798270/	https://finance.yahoo.com/quote/BXSL?p=BXSL&.tsrc=fin-srch	https://www.bxsl.com	Start 1. nov 2021.  Sikrede lån til små og mellemstore virksomheder.	t	\N	0.4500	2026	\N	USD	\N	\N	\N	BDC	\N	.US	NY	^GSPC	BXSL
BYDDY	BYDDY	BYD Company	Automotive	China	C-Di	https://www.marketscreener.com/quote/stock/BYD-COMPANY-LIMITED-5640763/	https://finance.yahoo.com/quote/BYDDY/	https://www.bydglobal.com	1211.HK	\N	\N	0.4000	2026	\N	USD	\N	\N	\N	Automotive	\N	.US	NY	^GSPC	BYDDY
BYND	BYND	Beyond Meat	Food	US	C-St	https://www.marketscreener.com/quote/stock/BEYOND-MEAT-INC-57878377/	https://finance.yahoo.com/quote/BYND/	https://www.beyondmeat.com	Plante-baseret 'kød'	\N	\N	0.5000	2026	\N	USD	\N	\N	\N	Food	\N	.US	NY	^GSPC	BYND
C	C	Citigroup	Bank	US	Fina	https://www.marketscreener.com/quote/stock/CITIGROUP-INC-4818/	https://finance.yahoo.com/quote/C/	https://www.citigroup.com	Services, markes, banking, US personal banking	\N	\N	0.6200	2026	\N	USD	\N	\N	\N	Bank	\N	.US	NY	^GSPC	C
CABK.MC	BME:CABK	CaixaBank	Bank	ES	Fina	https://www.marketscreener.com/quote/stock/CAIXABANK-S-A-357103/	https://finance.yahoo.com/quote/CABK.MC	https://www.caixabank.es	Spansk bank (90% oms i ES)	t	\N	0.4400	2026	\N	EUR	\N	\N	\N	Bank	\N	.MC	LON	^STOXX	CABK.MC
CAH	CAH	Cardinal Health	Healthcare	US	Heal	https://www.marketscreener.com/quote/stock/CARDINAL-HEALTH-INC-11969/	https://finance.yahoo.com/quote/CAH/	https://www.cardinalhealth.com	Distribution of products and health services to pharmacies, hospitals and medical practices	\N	\N	0.2500	2026	\N	USD	\N	\N	\N	Healthcare	\N	.US	NY	^GSPC	CAH
CALM	CALM	CAL-Maine Foods	Food	US	C-St	https://www.marketscreener.com/quote/stock/CAL-MAINE-FOODS-INC-8661/	https://finance.yahoo.com/quote/CALM?p=CALM&.tsrc=fin-srch	https://www.calmainefoods.com	Producent af æg	\N	\N	0.3500	2026	\N	USD	\N	\N	\N	Food	\N	.US	NY	^GSPC	CALM
CALY	CALY	Callaway Brands Corp (tidl. Topgolf)	Holiday	US	C-Di	https://www.marketscreener.com/quote/stock/CALLAWAY-GOLF-COMPANY-12444/	https://finance.yahoo.com/quote/ELY?p=ELY&.tsrc=fin-srch	https://www.topgolfcallawaybrands.com	\N	\N	\N	0.1200	2026	\N	USD	\N	\N	\N	Holiday	\N	.US	NY	^GSPC	CALY
CAT	CAT	Caterpillar	Manuf_Special	US	Indu	https://www.marketscreener.com/quote/stock/CATERPILLAR-INC-4817/	https://finance.yahoo.com/quote/CAT?p=CAT&.tsrc=fin-srch	https://www.caterpillar.com	Entreprenør-maskiner	\N	\N	\N	\N	\N	USD	\N	\N	\N	Manuf_Special	\N	.US	NY	^GSPC	CAT
CB	CB	Chubb	Insurance	US	Fina	https://www.marketscreener.com/quote/stock/CHUBB-LIMITED-3860961/	\N	https://www.chubb.com	\N	\N	\N	0.4200	2026	\N	USD	\N	\N	\N	Insurance	\N	.US	NY	^GSPC	CB
CBRAIN.CO	CPH:CBRAIN	cBRAIN	TechToProfs	DK	Tech	https://www.marketscreener.com/quote/stock/CBRAIN-A-S-1412858/	\N	https://www.cbrain.dk	\N	\N	\N	0.4200	2026	\N	DKK	\N	\N	\N	TechToProfs	\N	.CO	LON	^OMXC20	CBRAIN.CO
CBRE	CBRE	CBRE Group	Property	US	REIT	https://www.marketscreener.com/quote/stock/CBRE-GROUP-INC-9823294/	\N	https://www.cbre.com	\N	\N	\N	0.4100	2026	\N	USD	\N	\N	\N	Property	\N	.US	NY	^GSPC	CBRE
CC	CC	Chemours	Chemical	US	Indu	https://www.marketscreener.com/quote/stock/THE-CHEMOURS-COMPANY-22795876/	\N	https://www.chemours.com	\N	\N	\N	0.3300	2026	\N	USD	\N	\N	\N	Other[Indu]	7	.US	NY	^GSPC	CC
CCI	CCI	Crown Castle Intl (towers)	Property	US	REIT	https://www.marketscreener.com/quote/stock/CROWN-CASTLE-INC-19476277/	\N	https://www.crowncastle.com	Towers: AMT, CCI og SBAC	\N	\N	0.5500	2026	\N	USD	\N	\N	\N	Property	\N	.US	NY	^GSPC	CCI
CCJ	CCJ	Cameco	Rnwb(Ener)	CAN	Ener	https://www.marketscreener.com/quote/stock/CAMECO-CORPORATION-12001/	https://finance.yahoo.com/quote/CCJ/	https://www.cameco.com/	Behandling af uran, fremstilling af nuklear brændsel mm.	\N	\N	0.5500	2026	\N	USD	\N	AI-infrastruktur	\N	Rnwb(Ener)	\N	.US	NY	^GSPC	CCJ
CDE	CDE	Coeur Mining	Gold	US	Basi	https://www.marketscreener.com/quote/stock/COEUR-MINING-INC-12011/	https://finance.yahoo.com/quote/CDE/	https://www.coeur.com/	Guld (mest) og sølv. 2600 ansatte.	t	\N	0.7800	2026	\N	USD	\N	\N	\N	Gold	\N	.US	NY	^GSPC	CDE
CDNS	CDNS	Cadence Design Systems	TechToProfs	US	Tech	https://www.marketscreener.com/quote/stock/CADENCE-DESIGN-SYSTEMS-IN-8724/	https://finance.yahoo.com/quote/CDNS	https://www.cadence.com	Software for design of chips. No 1 worldwide.	\N	\N	0.5800	2026	\N	USD	\N	\N	\N	TechToProfs	\N	.US	NY	^GSPC	CDNS
CEG	CEG	Constellation Energy Corp.	Util_Rnwb	US	Util	https://www.marketscreener.com/quote/stock/CONSTELLATION-ENERGY-CORP-131860757/	https://finance.yahoo.com/quote/CEG	https://www.constellationenergy.com	CO2 neutral. 86% fra 12 nuclear sites (2012-tal), inkl. genstart af tre-mile øen til brug for Microsoft datacenter i Texas.	\N	\N	0.6000	2026	\N	USD	\N	AI-infrastruktur	\N	Util_Rnwb	\N	.US	NY	^GSPC	CEG
CF	CF	CF Industries	Agro	US	Basi	https://www.marketscreener.com/quote/stock/CF-INDUSTRIES-HOLDINGS-I-12028/	https://finance.yahoo.com/quote/CF?p=CF&.tsrc=fin-srch	https://www.cfindustries.com	Kunstgødning	\N	\N	0.5600	2026	\N	USD	\N	\N	\N	Agro	\N	.US	NY	^GSPC	CF
CFG	CFG	Citizens Financial Group, Inc.	Bank	US	Fina	https://www.marketscreener.com/quote/stock/CITIZENS-FINANCIAL-GROUP--18045268/	https://finance.yahoo.com/quote/CFG/	https://www.citizensbank.com/homepage.aspx	Leading retail-bank in US	\N	\N	0.4500	2026	\N	USD	\N	\N	\N	Bank	\N	.US	NY	^GSPC	CFG
CFR.SW	SWX:CFR	Richemont SA	Luxury	CH	C-Di	https://www.marketscreener.com/quote/stock/COMPAGNIE-FINANCIERE-RICH-14354614/	\N	https://www.richemont.com	Cartier	\N	\N	0.4000	2026	\N	CHF	\N	\N	\N	Luxury	\N	.SW	LON	^STOXX	CFR.SW
CG.TO	TSE:CG	Centerra Gold	Gold	CAN	Basi	https://www.marketscreener.com/quote/stock/CENTERRA-GOLD-INC-1409419/	https://finance.yahoo.com/quote/CG.TO/	https://www.centerragold.com/	Mining gold and copper properties in North America, Turkey, and internationally. Also molybdenum business unit, including metallurgical processing facility.	\N	\N	0.5500	2026	\N	USD	\N	\N	\N	Gold	\N	.TO	NY	^GSPC	CG.TO
CGBD	CGBD	Carlyle Secured Lending	BDC	US	Fina	https://www.marketscreener.com/quote/stock/CARLYLE-SECURED-LENDING-I-35821362/	https://finance.yahoo.com/quote/CGBD	https://carlylesecuredlending.com/	Investing in secured debt. Externally managed.	t	\N	0.5500	2026	\N	USD	\N	\N	t	BDC	\N	.US	NY	^GSPC	CGBD
CHE-UN.TO	TSX:CHE.UN	Chemtrade Logistics Income Fund	Chemical	CAN	Indu	https://www.marketscreener.com/quote/stock/CHEMTRADE-LOGISTICS-INCOM-1409441/	https://finance.yahoo.com/quote/CHE-UN.TO?p=CHE-UN.TO&.tsrc=fin-srch	https://www.chemtradelogistics.com	\N	\N	\N	0.5500	2026	\N	CAD	\N	\N	\N	Other[Indu]	7	.TO	NY	^GSPC	CHE-UN.TO
CHEMM.CO	CPH:CHEMM	Chemometec	Electronics_Medical	DK	Indu	https://www.marketscreener.com/quote/stock/CHEMOMETEC-A-S-1412859/	https://finance.yahoo.com/quote/CHEMM.CO?p=CHEMM.CO&.tsrc=fin-srch	https://www.chemometec.com	Måleudstyr til bio-industri	\N	\N	0.5300	2026	\N	DKK	\N	\N	\N	Other[Indu]	7	.CO	LON	^OMXC20	CHEMM.CO
CHKP	CHKP	Check Point Software Technologies	Cybersecurity	US	Tech	https://www.marketscreener.com/quote/stock/CHECK-POINT-SOFTWARE-TECH-4858/	https://finance.yahoo.com/quote/CHKP?p=CHKP&.tsrc=fin-srch	https://www.checkpoint.com	PANW og CHKP er FTNT-konkurrenter	\N	\N	0.4700	2026	\N	USD	\N	\N	\N	Cybersecurity	\N	.US	NY	^GSPC	CHKP
CHYM	CHYM	Chime Financial	Fintech	US	Fina	https://www.marketscreener.com/quote/stock/CHIME-FINANCIAL-INC-190252021/	https://finance.yahoo.com/quote/CHYM/	https://www.chime.com/	Mobile banking for people's spending, saving, liquidity, building credit, savings and perks, community, and security. No bank license; banking service provided by Bancorp and Stride	t	\N	0.6500	2026	\N	USD	\N	\N	\N	Fintech	\N	.US	NY	^GSPC	CHYM
CI	CI	Cigna	Healthcare	US	Heal	https://www.marketscreener.com/quote/stock/CIGNA-CORPORATION-49690049/	https://finance.yahoo.com/quote/CI/	https://www.cigna.com	Health insurance programs	\N	\N	0.3800	2026	\N	USD	\N	\N	\N	Healthcare	\N	.US	NY	^GSPC	CI
CIEN	CIEN	Ciena 	ElectrComponents	US	Tech	https://www.marketscreener.com/quote/stock/CIENA-CORPORATION-15311276/	https://finance.yahoo.com/quote/CIEN/	https://www.ciena.com/	Hardware, software, and services to network operators aiming at enhanced network capacity, service delivery, and automation.	\N	\N	0.3800	1899	\N	USD	\N	\N	\N	ElectrComponents	\N	.US	NY	^GSPC	CIEN
CIM	CIM	Chimera Investment Corp	Mortgages	US	REIT	https://www.marketscreener.com/quote/stock/CHIMERA-INVESTMENT-CORPOR-21494236/	\N	https://www.chimerareit.com	\N	\N	\N	0.3800	1899	\N	USD	\N	\N	\N	Mortgages	\N	.US	NY	^GSPC	CIM
CIM-PC	CIM-C	Chimera Investment Corp. 7.75% Series C Fixed/Float Cumulative Redeemable Preferred Stock	Mortgages	US	REIT	https://finance.yahoo.com/quote/CIM-PC?p=CIM-PC&.tsrc=fin-srch	https://finance.yahoo.com/quote/CIM-PC?p=CIM-PC&.tsrc=fin-srch	https://www.chimerareit.com	Callable 30.9.25. Pref. Anbefalet Rita M 26.10.20	t	\N	0.3100	2026	\N	USD	\N	\N	\N	Mortgages	\N	.US	NY	^GSPC	CIM-PC
CIM-PD	CIM-D	Chimera Investment Corp. 8.00% Series D Fixed/Float Cumulative Redeemable Preferred Stock	Mortgages	US	REIT	https://finance.yahoo.com/quote/CIM-PD?p=CIM-PD&.tsrc=fin-srch	https://finance.yahoo.com/quote/CIM-PD?p=CIM-PD&.tsrc=fin-srch	https://www.chimerareit.com	Callable 30.3.24. Pref. Anbefalet Rita M 26.10.20	\N	\N	0.4000	2026	\N	USD	\N	\N	\N	Mortgages	\N	.US	NY	^GSPC	CIM-PD
CINF	CINF	Cincinnati Financial Corporation	Insurance	US	Fina	https://www.marketscreener.com/quote/stock/CINCINNATI-FINANCIAL-CORP-40311119/	\N	https://www.cinfin.com	\N	\N	\N	0.7400	2026	\N	USD	\N	\N	\N	Insurance	\N	.US	NY	^GSPC	CINF
CION	CION	CION Investment Corp	Investment	US	Fina	https://www.marketscreener.com/quote/stock/CION-INVESTMENT-CORPORATI-127830127/	https://finance.yahoo.com/quote/CION?p=CION&.tsrc=fin-srch	https://www.cioninvestments.com	Ny BDC, IPO 2021.	\N	\N	\N	\N	\N	USD	\N	\N	\N	Investment	\N	.US	NY	^GSPC	CION
CL	CL	Colgate-Palmolive	Distributor	US	C-St	https://www.marketscreener.com/quote/stock/INSULET-CORPORATION-50468/	\N	https://www.insulet.com	Cleaning and hygiene products	\N	\N	0.6500	2026	\N	USD	\N	\N	t	Other[C-St]	7	.US	NY	^GSPC	CL
CLDT	CLDT	Chatham Lodging Trust	Property	US	REIT	https://www.marketscreener.com/quote/stock/CHATHAM-LODGING-TRUST-6134655/	\N	https://www.chathamlodgingtrust.com	\N	\N	\N	0.2900	2026	\N	USD	\N	\N	\N	Property	\N	.US	NY	^GSPC	CLDT
CLS	CLS	Celestica	Electronics	CAN	Indu	https://www.marketscreener.com/quote/stock/CELESTICA-INC-1409491/	https://finance.yahoo.com/quote/CLS/	https://www.celestica.com/	Manufacturing of electronics and electronics-based systems. North America, Europe, and Asia.	\N	\N	0.4200	2026	\N	USD	\N	\N	\N	Electronics	\N	.US	NY	^GSPC	CLS
CLSK	CLSK	Cleanspark	Crypto	US	Fina	https://www.marketscreener.com/quote/stock/CLEANSPARK-INC-46303597/	https://finance.yahoo.com/quote/CLSK?p=CLSK&.tsrc=fin-srch	https://www.cleanspark.com	Clean energy for bitcoin	\N	\N	0.5000	2026	\N	USD	\N	\N	\N	Crypto	\N	.US	NY	^BTC	CLSK
CLX	CLX	The Clorox Company	Retail	US	C-St	https://www.marketscreener.com/quote/stock/THE-CLOROX-COMPANY-12103/	https://finance.yahoo.com/quote/CLX/	https://www.thecloroxcompany.com/	\N	\N	\N	0.4000	2026	\N	USD	\N	\N	\N	Retail	\N	.US	NY	^GSPC	CLX
CM	CM	Canadian Imperial Bank of Commerce	Bank	CAN	Fina	https://www.marketscreener.com/quote/stock/CANADIAN-IMPERIAL-BANK-OF-1409496/	https://finance.yahoo.com/quote/CM/	https://www.cibc.com	\N	\N	\N	0.4200	2026	\N	USD	\N	\N	\N	Bank	\N	.US	NY	^GSPC	CM
CMCSA	CMCSA	Comcast Corporation	Media&Educ	US	C-Di	https://www.marketscreener.com/quote/stock/COMCAST-CORPORATION-4864/	https://finance.yahoo.com/quote/CMCSA/	https://corporate.comcast.com	Underholdningsindustri	\N	\N	0.6000	2026	\N	USD	\N	\N	\N	Media&Educ	\N	.US	NY	^GSPC	CMCSA
CME	CME	CME Group	Services(Fina)	US	Fina	https://www.marketscreener.com/quote/stock/CME-GROUP-INC-3782767/	https://finance.yahoo.com/quote/CME?p=CME	https://www.cmegroup.com	Ejer Globex - 24 hr børs	\N	\N	0.5500	2026	\N	USD	\N	\N	\N	Services(Fina)	\N	.US	NY	^GSPC	CME
CMG	CMG	Chipotle Mexican Grill	Restaurants	US	C-Di	https://www.marketscreener.com/quote/stock/CHIPOTLE-MEXICAN-GRILL-IN-12109/	https://finance.yahoo.com/quote/CMG?p=CMG&.tsrc=fin-srch	https://www.chipotle.com	\N	\N	\N	0.2600	2026	\N	USD	\N	\N	t	Restaurants	\N	.US	NY	^GSPC	CMG
CMI	CMI	Cummins	Automotive	US	C-Di	https://www.marketscreener.com/quote/stock/CUMMINS-INC-12214/	https://finance.yahoo.com/quote/CMI?p=CMI&.tsrc=fin-srch	https://www.cummins.com	Motorer	\N	\N	0.3500	2026	\N	USD	\N	\N	\N	Automotive	\N	.US	NY	^GSPC	CMI
CNC	CNC	Centene Corporation	Healthcare	US	Heal	https://www.marketscreener.com/quote/stock/CENTENE-CORPORATION-55763517/	https://finance.yahoo.com/quote/CNC?p=CNC	https://www.centene.com	Health insurance. Niche company dealing with the underinsured.	\N	\N	0.5000	2026	\N	USD	\N	\N	\N	Healthcare	\N	.US	NY	^GSPC	CNC
CNH	CNH	CNH Industrial (agro-machinery)	Manuf_Big	US	Indu	https://www.marketscreener.com/quote/stock/CNH-INDUSTRIAL-N-V-14424308/	https://finance.yahoo.com/quote/CNH/	https://www.cnh.com	No 2 efter Deere i precision agro-equipment	\N	\N	\N	\N	\N	USD	\N	\N	\N	Manuf_Big	\N	.US	NY	^GSPC	CNH
CNQ.TO	TSE:CNQ	Canadian natural resources	Oil&Gas	CAN	Ener	https://www.marketscreener.com/quote/stock/CANADIAN-NATURAL-RESOURCE-1409525/	https://finance.yahoo.com/quote/CNQ.TO?p=CNQ.TO&.tsrc=fin-srch	https://www.cnrl.com	Olie og gas-udvinding i Nordamerika, Nordsøen og Offshore Africa	\N	\N	0.3800	2026	\N	CAD	\N	\N	\N	Oil&Gas	\N	.TO	NY	^GSPC	CNQ.TO
CNYA.L	LON:CNYA	ETF	Country	China	na	https://www.blackrock.com/dk/formidler/produkter/273192/	https://finance.yahoo.com/quote/CNYA.L?p=CNYA.L&.tsrc=fin-srch	\N	Ca. 675 aktier!  Meget likvid på LST.	\N	\N	0.6500	2026	\N	USD	\N	\N	\N	Country	\N	.L	LON	^FTSE	CNYA.L
COF	COF	Capital One Financial Corp	Bank	US	Fina	https://www.marketscreener.com/quote/stock/CAPITAL-ONE-FINANCIAL-COR-12144/	https://finance.yahoo.com/quote/COF?p=COF&.tsrc=fin-srch	https://www.capitalone.com	\N	\N	\N	0.3700	2026	\N	USD	\N	\N	\N	Bank	\N	.US	NY	^GSPC	COF
COHR	COHR	Coherent (tidl. II-VI)	ElectrComponents	US	Tech	https://www.marketscreener.com/quote/stock/COHERENT-CORP-9656/	https://finance.yahoo.com/quote/COHR/	https://www.coherent.com	Optoelectronics business lines: Networking, Materials, and Lasers	\N	\N	0.4500	2026	\N	USD	\N	\N	\N	ElectrComponents	\N	.US	NY	^GSPC	COHR
COIN	COIN	Coinbase	Crypto	CAN	Fina	https://www.marketscreener.com/quote/stock/COINBASE-GLOBAL-INC-121300010/	https://finance.yahoo.com/quote/COIN/	www.coinbase.com	Platform til køb og salg af kryptovaluta	\N	\N	0.4700	2026	\N	USD	\N	\N	\N	Crypto	\N	.US	NY	^BTC	COIN
COP	COP	ConocoPhillips	Oil&Gas	US	Ener	https://www.marketscreener.com/quote/stock/CONOCOPHILLIPS-13929/	\N	https://www.conocophillips.com	\N	\N	\N	\N	\N	\N	USD	\N	\N	\N	Oil&Gas	\N	.US	NY	^GSPC	COP
COR	COR	Cencora (AmerisourceBergen)	Healthcare	US	Heal	https://www.marketscreener.com/quote/stock/CENCORA-INC-9428091/	https://finance.yahoo.com/quote/COR/	http://www.cencora.com/	44000 ansatte. Distribution af generiske og håndkøbsprodukter	\N	\N	0.4400	2026	\N	USD	\N	\N	\N	Healthcare	\N	.US	NY	^GSPC	COR
CORN	CORN	Teucrium Corn Fund	Agro	US	Basi	https://www.marketscreener.com/quote/etf/TEUCRIUM-CORN-FUND-USD-29773508/	https://finance.yahoo.com/quote/CORN?p=CORN&.tsrc=fin-srch	\N	Majs	\N	\N	0.4000	2026	\N	USD	\N	\N	\N	Agro	\N	.US	NY	^GSPC	CORN
CORZ	CORZ	Core Scientific, Inc.	Crypto	US	Fina	https://www.marketscreener.com/quote/stock/CORE-SCIENTIFIC-INC-164769189/	https://finance.yahoo.com/quote/CORZ/	https://corescientific.com/	Bitcoin-mining, software og infrastruktur til block-chain teknologi	\N	\N	0.4000	2026	\N	USD	\N	AI-infrastruktur	\N	Crypto	\N	.US	NY	^BTC	CORZ
COST	COST	Costco	Retail	US	C-St	https://www.marketscreener.com/quote/stock/COSTCO-WHOLESALE-CORPORAT-4866/	\N	https://www.costco.com	\N	\N	\N	0.3500	2026	\N	USD	\N	\N	\N	Retail	\N	.US	NY	^GSPC	COST
CPB	CPB	Campbell Soup Company	Food	US	C-St	https://www.marketscreener.com/quote/stock/CAMPBELL-SOUP-COMPANY-12154/	https://finance.yahoo.com/quote/CPB?p=CPB&.tsrc=fin-srch	https://www.campbellsoupcompany.com	Færdigmad, saucer, supper	\N	\N	0.4200	2026	\N	USD	\N	\N	\N	Food	\N	.US	NY	^GSPC	CPB
CPNG	CPNG	Coupang	Retail	Korea	C-St	https://www.marketscreener.com/quote/stock/COUPANG-INC-119962175/	https://finance.yahoo.com/quote/CPNG?p=CPNG&.tsrc=fin-srch	https://www.aboutcoupang.com	Hypervoksende, koreansk Amazon	\N	\N	0.5000	2026	\N	USD	\N	\N	\N	Retail	\N	.US	NY	^GSPC	CPNG
CPRI	CPRI	Capri Holdings 	Luxury	UK	C-Di	https://www.marketscreener.com/quote/stock/CAPRI-HOLDINGS-LIMITED-50061065/	https://finance.yahoo.com/quote/CPRI?p=CPRI&.tsrc=fin-srch	https://www.capriholdings.com	Accessories, footwear, handbags	\N	\N	0.5800	2026	\N	USD	\N	\N	\N	Luxury	\N	.US	NY	^GSPC	CPRI
CPX.TO	TSE:CPX	Capital Power	Util_MixedFuel	CAN	Util	https://www.marketscreener.com/quote/stock/CAPITAL-POWER-CORPORATION-5402048/	https://finance.yahoo.com/quote/CPX.TO?p=CPX.TO&.tsrc=fin-srch	https://www.capitalpower.com	Elproduktion, delvis gas, i CAN og dele af US	t	\N	0.4700	2026	\N	CAD	\N	\N	\N	Util_MixedFuel	\N	.TO	NY	^GSPC	CPX.TO
CQP	CQP	Cheniere Partners LP (liq nat gas)	Oil&Gas	US	Ener	https://www.marketscreener.com/quote/stock/CHENIERE-ENERGY-PARTNERS--15175/	\N	https://www.cheniere.com	Largest US-exporter af liq nat gas, mest til Asien. Gen. partner til drifts-selskabet LNG (børsnoteret, akkumulerende, modsat udb-betalende CQP).	\N	\N	0.8000	2026	\N	USD	\N	\N	\N	Oil&Gas	\N	.US	NY	^GSPC	CQP
CRCL	CRCL	Circle Internet Group	Crypto	US	Fina	https://www.marketscreener.com/quote/stock/CIRCLE-INTERNET-GROUP-INC-189646796/	https://finance.yahoo.com/quote/CRCL/	https://www.circle.com/	Platform for stablecoins og blockchain-applikationer.	\N	\N	0.6100	2026	\N	USD	\N	\N	\N	Crypto	\N	.US	NY	^BTC	CRCL
CRDO	CRDO	Credo Technology	Semi	Cayman Islands	Tech	https://www.marketscreener.com/quote/stock/CREDO-TECHNOLOGY-GROUP-HO-132401547/	https://finance.yahoo.com/quote/CRDO/	http://credosemi.com/	High-speed connectivity solutions for hyperscale data centers and AI infrastructure	t	\N	0.7000	2026	\N	USD	\N	\N	\N	Semi	\N	.US	NY	^GSPC	CRDO
CRH.L	LON:CRH	CRH Plc	ConstrMaterials	Irland	Basi	https://www.marketscreener.com/quote/stock/CRH-PLC-4000708/	https://finance.yahoo.com/quote/CRH.L?p=CRH.L	https://www.crh.com	Bygningsmaterialer.  7700 ansatte i 28 lande. 55% af salg i USA.	\N	\N	0.4400	2026	\N	GBX	\N	\N	\N	ConstrMaterials	\N	.L	LON	^FTSE	CRH.L
CRM	CRM	Salesforce.com	TechToProfs	US	Tech	https://www.marketscreener.com/quote/stock/SALESFORCE-COM-INC-12180/	https://finance.yahoo.com/quote/CRM?p=CRM&.tsrc=fin-srch	https://www.salesforce.com	CRM-system	\N	\N	0.6000	2026	\N	USD	\N	\N	\N	TechToProfs	\N	.US	NY	^GSPC	CRM
CRUS	CRUS	Cirrus Logic	Semi	US	Tech	https://www.marketscreener.com/quote/stock/CIRRUS-LOGIC-INC-8909/	\N	https://www.cirrus.com	Chips:  low-power, high-precision mixed-signal processing solutions	\N	\N	0.3700	2026	\N	USD	\N	\N	\N	Semi	\N	.US	NY	^GSPC	CRUS
CRWD	CRWD	Crowdstrike (cloud-delivered endpoint protection)	Cybersecurity	US	Tech	https://www.marketscreener.com/quote/stock/CROWDSTRIKE-HOLDINGS-INC-59783691/	https://finance.yahoo.com/quote/CRWD?p=CRWD&.tsrc=fin-srch	https://www.crowdstrike.com	Cybersecurity	\N	\N	0.4400	2026	\N	USD	\N	\N	\N	Cybersecurity	\N	.US	NY	^GSPC	CRWD
CRWV	CRWV	Coreweave	TechToProfs	US	Tech	https://www.marketscreener.com/quote/stock/COREWEAVE-INC-185380761/	https://finance.yahoo.com/quote/CRWV/	http://www.coreweave.com/	Cloud computing services. NVIDIA stor investor.	\N	\N	0.7000	2026	\N	USD	\N	\N	\N	TechToProfs	\N	.US	NY	^GSPC	CRWV
CS.PA	EPA:CS	AXA	Insurance	FR	Fina	https://www.marketscreener.com/quote/stock/AXA-4615/	https://finance.yahoo.com/quote/CS.PA/	http://www.axa.com/	Bred vifte af forsikringsydelser, 50% i Europa. 95000 ansatte	\N	\N	0.4500	2026	\N	EUR	\N	\N	\N	Insurance	\N	.PA	LON	^FCHI	CS.PA
CSCO	CSCO	Cisco	TechToProfs	US	Tech	https://www.marketscreener.com/quote/stock/CISCO-SYSTEMS-INC-4862/	\N	https://www.cisco.com	\N	\N	\N	0.3200	2026	\N	USD	\N	\N	\N	TechToProfs	\N	.US	NY	^GSPC	CSCO
CSGP	CSGP	CoStar Group	TechToProfs	US	Tech	https://www.marketscreener.com/quote/stock/COSTAR-GROUP-INC-8923/	\N	https://www.costargroup.com	Comm. real estate marketplace & services 	\N	\N	\N	\N	\N	USD	\N	\N	\N	TechToProfs	\N	.US	NY	^GSPC	CSGP
CSIQ	CSIQ	Canadian Solar	Rnwb(Indu)	CAN	Indu	https://www.marketscreener.com/quote/stock/CANADIAN-SOLAR-INC-36332/	https://finance.yahoo.com/quote/CSIQ/	https://www.canadiansolar.com	Manufactures solar PV modules, provides battery energy storage solutions and develops utility-scale parks	\N	\N	0.6500	2026	\N	USD	\N	\N	\N	Rnwb(Indu)	\N	.US	NY	^GSPC	CSIQ
CSPX.L	LON:CSPX	iShares Core S&P 500 UCITS ETF (USD, Acc)	Diverse_na	US	na	https://www.justetf.com/uk/etf-profile.html?groupField=index&index=S%2526P%2B500%25C2%25AE&assetClass=class-equity&from=search&isin=IE00B5BMR087#listing	https://finance.yahoo.com/quote/CSPX.L?p=CSPX.L&.tsrc=fin-srch	\N	UCITS af SPY (S&P500). GBX-udgave hedder CSP1.L  (større vol). Distr-udgave hedder IDUS.L (USD) henh. IUSA (GBX).	\N	\N	0.5800	2026	\N	USD	\N	\N	\N	Diverse_na	\N	.L	LON	^FTSE	CSPX.L
CSTM	CSTM	Constellium SE	Diverse_Basi	FR	Basi	https://www.marketscreener.com/quote/stock/CONSTELLIUM-SE-13267142/	https://finance.yahoo.com/quote/CSTM/	https://www.constellium.com/	Manufacture aluminum products, esp. for aerospace, packaging, automotive, and defense end-markets	\N	\N	0.4100	2026	\N	USD	\N	\N	\N	Other[Basi]	\N	.US	NY	^GSPC	CSTM
CSU.TO	TSE:CSU	Constellation software	TechToProfs	CAN	Tech	https://www.marketscreener.com/quote/stock/CONSTELLATION-SOFTWARE-IN-1409607/	https://finance.yahoo.com/quote/CSU.TO?p=CSU.TO&.tsrc=fin-srch	https://www.csisoftware.com	Seriel opkøber af sw-virksomheder på specialiserede markeder. 860 virks opkøbt i 2015-23. Stærk vækst og god profitabilitet, men mikro-udbytte	\N	\N	0.4700	2026	\N	CAD	\N	\N	\N	TechToProfs	\N	.TO	NY	^GSPC	CSU.TO
CSWC	CSWC	Capital Southwest Corp	BDC	US	Fina	https://www.marketscreener.com/quote/stock/CAPITAL-SOUTHWEST-CORPORA-8937/	https://finance.yahoo.com/quote/CSWC	https://www.capitalsouthwest.com	\N	t	\N	0.5000	2026	\N	USD	\N	\N	\N	BDC	\N	.US	NY	^GSPC	CSWC
CSX	CSX	CSX Corp (rails)	Trpt_Other	US	Indu	https://www.marketscreener.com/quote/stock/CSX-CORPORATION-25500636/	\N	https://www.csx.com	\N	\N	\N	0.5000	2026	\N	USD	\N	\N	\N	Trpt_Other	\N	.US	NY	^GSPC	CSX
CTAS	CTAS	Cintas	Manuf_Special	US	Indu	https://www.marketscreener.com/quote/stock/CINTAS-CORPORATION-4861/	\N	https://www.cintas.com	Arbejdstøj	\N	\N	0.2900	2026	\N	USD	\N	\N	\N	Manuf_Special	\N	.US	NY	^GSPC	CTAS
CTBI	CTBI	Community Trust Bancorp,  (Kentucky)	Bank	US	Fina	https://www.marketscreener.com/quote/stock/COMMUNITY-TRUST-BANCORP-I-8940/	\N	https://www.ctbi.com	\N	\N	\N	0.5300	2026	\N	USD	\N	\N	\N	Bank	\N	.US	NY	^GSPC	CTBI
CTC-A.TO	TSE:CTC.A	Canadian Tire Corp	Automotive	CAN	C-Di	https://www.marketscreener.com/quote/stock/CANADIAN-TIRE-CORPORATION-1409621/	https://finance.yahoo.com/quote/CTC-A.TO?p=CTC-A.TO&.tsrc=fin-srch	https://www.canadiantire.ca	Auto-relaterede butikker, tankstationer, kreditkort	\N	\N	0.6100	2026	\N	CAD	\N	\N	\N	Automotive	\N	.TO	NY	^GSPC	CTC-A.TO
CTRA	CTRA	Coterra Energy	Oil&Gas	US	Ener	https://www.marketscreener.com/quote/stock/COTERRA-ENERGY-INC-12146/	https://finance.yahoo.com/quote/CTRA?p=CTRA&.tsrc=fin-srch	https://www.coterra.com	Natural gas pure-play	\N	\N	0.5500	2026	\N	USD	\N	\N	\N	Oil&Gas	\N	.US	NY	^GSPC	CTRA
CTRE	CTRE	Caretrust REIT (healthcare)	Property	US	REIT	https://www.marketscreener.com/quote/stock/CARETRUST-REIT-INC-16519447/	https://finance.yahoo.com/quote/CTRE?p=CTRE&.tsrc=fin-srch	https://www.caretrustreit.com	Div-growth. Mindre selskab	\N	\N	0.5500	2026	\N	USD	\N	\N	\N	Property	\N	.US	NY	^GSPC	CTRE
CTSH	CTSH	Cognizant Technology Solutions	TechToProfs	US	Tech	https://www.marketscreener.com/quote/stock/COGNIZANT-TECHNOLOGY-SOLU-23219296/	\N	https://www.cognizant.com	\N	\N	\N	0.5500	2026	\N	USD	\N	\N	\N	TechToProfs	\N	.US	NY	^GSPC	CTSH
CVNA	CVNA	Carvana	Automotive	US	C-Di	https://www.marketscreener.com/quote/stock/CARVANA-CO-34658201/	https://finance.yahoo.com/quote/CVNA/	https://www.carvana.com/	E-handelsplatform for brugte biler	\N	\N	0.3500	2026	\N	USD	\N	\N	\N	Automotive	\N	.US	NY	^GSPC	CVNA
CVS	CVS	CVS Health	Healthcare	US	Heal	https://www.marketscreener.com/quote/stock/CVS-HEALTH-CORPORATION-12230/	https://finance.yahoo.com/quote/CVS	https://www.cvshealth.com	Drug store-kæde	\N	\N	0.4100	2026	\N	USD	\N	\N	\N	Healthcare	\N	.US	NY	^GSPC	CVS
CVX	CVX	Chevron	Oil&Gas	US	Ener	https://www.marketscreener.com/quote/stock/CHEVRON-CORPORATION-12064/	\N	https://www.chevron.com	\N	\N	\N	\N	\N	\N	USD	\N	\N	\N	Oil&Gas	\N	.US	NY	^GSPC	CVX
CWEN	CWEN	Clearway (forsyning / renewables)	Util_Rnwb	US	Util	https://www.marketscreener.com/quote/stock/CLEARWAY-ENERGY-INC-46261246/	https://finance.yahoo.com/quote/CWEN?p=CWEN&.tsrc=fin-srch	https://www.clearwayenergy.com	CWEN-A er non-voting, ellers det samme	\N	\N	0.3300	2026	\N	USD	\N	\N	\N	Util_Rnwb	\N	.US	NY	^GSPC	CWEN
CWIGAKLA.CO	CPH:CWIGAKLA	C Worldwide Globale Aktier	Diverse_na	Intl	na	https://cww.dk/afkast-og-kurser/aktuelle-kurser/	https://finance.yahoo.com/quote/CWIGAKL.CO?p=CWIGAKL.CO&.tsrc=fin-srch	\N	\N	t	\N	0.6500	2026	\N	USD	\N	\N	\N	Diverse_na	\N	.CO	LON	^OMXC20	CWIGAKLA.CO
CX	CX	Cemex	ConstrMaterials	Mexico	Basi	https://www.marketscreener.com/quote/stock/CEMEX-S-A-B-DE-C-V-12237/	https://finance.yahoo.com/quote/CX?p=CX&.tsrc=fin-srch	https://www.cemex.com	\N	\N	\N	0.3900	2026	\N	USD	\N	\N	\N	ConstrMaterials	\N	.US	NY	^GSPC	CX
CXT	CXT	Crane NXT	Manuf_Special	US	Indu	https://www.marketscreener.com/quote/stock/CRANE-NXT-12169/	https://finance.yahoo.com/quote/CXT/	https://www.cranenxt.com/	Udstyr til sikring af værdifulde aktiver. 4500 ansatte	\N	\N	0.3900	2026	\N	USD	\N	\N	\N	Manuf_Special	\N	.US	NY	^GSPC	CXT
D	D	Dominion Energy	Util_MixedFuel	US	Util	https://www.marketscreener.com/quote/stock/DOMINION-ENERGY-INC-12255/	https://finance.yahoo.com/quote/D?p=D&.tsrc=fin-srch	https://www.dominionenergy.com	Et af USA's største forsyningselskaber. HQ: Virginia. Bruger også gas.	\N	\N	0.5500	2026	\N	USD	\N	\N	\N	Util_MixedFuel	\N	.US	NY	^GSPC	D
DAC	DAC	Danaos	Trpt_Ship	Greece	Indu	https://www.marketscreener.com/quote/stock/DANAOS-CORPORATION-57872037/	https://finance.yahoo.com/quote/DAC?p=DAC&.tsrc=fin-srch	https://www.danaos.com	Containershipping	\N	\N	0.5600	2026	\N	USD	\N	\N	\N	Trpt_Ship	\N	.US	NY	^GSPC	DAC
DAL	DAL	Delta Air Lines	Trpt_Airline	US	Indu	https://www.marketscreener.com/quote/stock/DELTA-AIR-LINES-INC-49285/	https://finance.yahoo.com/quote/DAL?p=DAL&.tsrc=fin-srch	https://www.delta-air.com	Airline	\N	\N	0.4500	2026	\N	USD	\N	\N	\N	Trpt_Airline	\N	.US	NY	^GSPC	DAL
DANSKE.CO	CPH:DANSKE	Danske Bank	Bank	DK	Fina	https://www.marketscreener.com/quote/stock/DANSKE-BANK-A-S-1412871/	https://finance.yahoo.com/quote/DANSKE.CO?p=DANSKE.CO&.tsrc=fin-srch	https://www.danskebank.com	Bank	t	\N	0.4500	2026	\N	DKK	\N	\N	\N	Bank	\N	.CO	LON	^OMXC20	DANSKE.CO
DASH	DASH	DoorDash	Trpt_Other	US	Indu	https://www.marketscreener.com/quote/stock/DOORDASH-INC-116169045/	https://finance.yahoo.com/quote/DASH?p=DASH&.tsrc=fin-srch	https://www.doordash.com	Delivery (inkl. Deliveroo and Wolt)	\N	\N	\N	\N	\N	USD	\N	\N	\N	Trpt_Other	\N	.US	NY	^GSPC	DASH
DB1.DE	ETR:DB1	Deutsche Börse	Services(Fina)	DE	Fina	https://www.marketscreener.com/quote/stock/DEUTSCHE-BORSE-AG-449617/	https://finance.yahoo.com/quote/DB1.DE/	https://www.deutsche-boerse.com	Frankfurt Stock Exchange (Xetra)	\N	\N	0.5000	2026	\N	EUR	\N	\N	\N	Services(Fina)	\N	.DE	LON	^GDAXI	DB1.DE
DBA	DBA	INVESCO DB Agriculture Fund	Agro	US	Basi	https://www.marketscreener.com/quote/etf/INVESCO-DB-AGRICULTURE-FU-29425589/	https://finance.yahoo.com/quote/DBA?p=DBA&.tsrc=fin-srch	\N	Agricultural Commodities	\N	\N	0.4100	2026	\N	USD	\N	\N	\N	Agro	\N	.US	NY	^GSPC	DBA
DBK.DE	ETR:DBK	Deutsche Bank	Bank	DE	Fina	https://www.marketscreener.com/quote/stock/DEUTSCHE-BANK-AG-56358396/	https://finance.yahoo.com/quote/DBK.DE/	http://www.db.com/	Største bank i Tyskland	t	\N	0.3800	2026	\N	EUR	\N	\N	\N	Bank	\N	.DE	LON	^GDAXI	DBK.DE
DBRG	DBRG	Digital Bridge Grp  (Colony Northstar)	Property	US	REIT	https://www.marketscreener.com/quote/stock/DIGITALBRIDGE-GROUP-INC-44403574/	https://finance.yahoo.com/quote/DBRG?p=DBRG&.tsrc=fin-srch	https://www.digitalbridge.com	Digital infrastructure properties	\N	\N	0.6000	2026	\N	USD	\N	AI-infrastruktur	\N	Property	\N	.US	NY	^GSPC	DBRG
DBSDY	DBSDY	DBS Grp Hldgs (Development Bank of Singapore)	Bank	Singapore	Fina	https://www.marketscreener.com/quote/stock/DBS-GROUP-HOLDINGS-LTD-6491408/	https://finance.yahoo.com/quote/DBSDY/	https://www.dbs.com.sg	\N	\N	\N	0.5500	2026	\N	USD	\N	\N	\N	Bank	\N	.US	NY	^GSPC	DBSDY
DD	DD	Dupont de Nemours	Chemical	US	Indu	https://www.marketscreener.com/quote/stock/DUPONT-DE-NEMOURS-INC-59241429/	https://finance.yahoo.com/quote/DD/history?p=DD	https://www.dupont.com	Development of specialty materials, chemicals, and agricultural products	\N	\N	0.5500	2026	\N	USD	\N	\N	\N	Other[Indu]	7	.US	NY	^GSPC	DD
DDOG	DDOG	Datadog	TechToProfs	US	Tech	https://www.marketscreener.com/quote/stock/DATADOG-INC-65956839/	https://finance.yahoo.com/quote/DDOG?p=DDOG&.tsrc=fin-srch	https://www.datadoghq.com	Hi-growth. Monitoring af cloud-IT	\N	\N	0.2400	2026	\N	USD	\N	\N	\N	TechToProfs	\N	.US	NY	^GSPC	DDOG
DE	DE	Deere & Company	Manuf_Big	US	Indu	https://www.marketscreener.com/quote/stock/DEERE-COMPANY-12279/	https://finance.yahoo.com/quote/DE?p=DE&.tsrc=fin-srch	https://www.deere.com	Landbrugsmaskiner	t	\N	0.6800	2026	\N	USD	\N	\N	\N	Manuf_Big	\N	.US	NY	^GSPC	DE
DEA	DEA	Easterly Government Properties	Property	US	REIT	https://www.marketscreener.com/quote/stock/EASTERLY-GOVERNMENT-PROPE-20798687/	\N	https://www.easterlyreit.com	\N	\N	\N	0.4400	2026	\N	USD	\N	\N	\N	Property	\N	.US	NY	^GSPC	DEA
DELL	DELL	Dell Tecnologies 	TechToProfs	US	Tech	https://www.marketscreener.com/quote/stock/DELL-TECHNOLOGIES-INC-50061235/	https://finance.yahoo.com/quote/DELL/	https://www.dell.com/en-us	PC samt nyt stigende marked med AI-server løsninger	\N	\N	\N	\N	\N	USD	\N	\N	\N	TechToProfs	\N	.US	NY	^GSPC	DELL
DEO	DEO	Diageo	Food	US	C-St	https://www.marketscreener.com/quote/stock/DIAGEO-PLC-12282/	\N	https://www.diageo.com	\N	\N	\N	0.3500	2026	\N	USD	\N	\N	t	Food	\N	.US	NY	^GSPC	DEO
DFEN.DE	EPA:DFNS	VanEck Defense ETF USD Acc	Defense	Intl	Indu	https://www.marketscreener.com/quote/etf/VANECK-DEFENSE-UCITS-ETF--153179488/	https://finance.yahoo.com/quote/DFEN.DE/	https://www.vaneck.com/uk/en/investments/defense-etf/holdings/	Startet 31.3.2023. 28 forsvarsaktier - ikke fortyndet med cyber el.lign.	t	\N	0.6000	2026	\N	EUR	\N	\N	\N	Defense	\N	.DE	LON	^GDAXI	DFEN.DE
DG	DG	Dollar General	Retail	US	C-St	https://www.marketscreener.com/quote/stock/DOLLAR-GENERAL-CORPORATIO-5699818/	\N	https://www.dollargeneral.com	\N	t	\N	0.4500	2026	\N	USD	\N	\N	\N	Retail	\N	.US	NY	^GSPC	DG
DG.PA	EPA:DG	Vinci	Construction	FR	Indu	https://www.marketscreener.com/quote/stock/VINCI-4725/	\N	https://www.vinci.com	\N	t	\N	\N	\N	\N	EUR	\N	\N	\N	Construction	\N	.PA	LON	^FCHI	DG.PA
DGE.L	LON:DGE	Diageo	Food	UK	C-St	https://www.marketscreener.com/quote/stock/DIAGEO-PLC-4000514/	https://finance.yahoo.com/quote/DGE.L?p=DGE.L&.tsrc=fin-srch-v1	https://www.diageo.com	Alkoholiske drikke med kendte mærker	\N	\N	0.2500	2026	\N	GBX	\N	\N	t	Food	\N	.L	LON	^FTSE	DGE.L
DGTL.L	LON:DGTL	iShares Inc/CORE MSCI EMERGING (ETF)	Diverse_na	US	na	https://www.ishares.com/uk/individual/en/products/284217/ishares-digitalisation-ucits-etf-usd-acc-fund	https://finance.yahoo.com/quote/DGTL.L?p=DGTL.L&.tsrc=fin-srch	\N	\N	\N	\N	0.2800	2026	\N	GBX	\N	\N	\N	Diverse_na	\N	.L	LON	^FTSE	DGTL.L
DHER.DE	ETR:DHER	Delivery Hero	TechToCons	DE	Tech	https://www.marketscreener.com/quote/stock/DELIVERY-HERO-SE-36718506/	https://finance.yahoo.com/quote/DHER.DE?p=DHER.DE&.tsrc=fin-srch	https://www.deliveryhero.com	Udbringning, mest mad	t	\N	0.4500	2026	\N	EUR	\N	\N	\N	TechToCons	\N	.DE	LON	^GDAXI	DHER.DE
DHI	DHI	D.R. Horton	ConstrHomes	US	C-Di	https://www.marketscreener.com/quote/stock/D-R-HORTON-INC-12293/	\N	https://www.drhorton.com	Homebuilding	\N	\N	0.5500	2026	\N	USD	\N	\N	\N	ConstrHomes	\N	.US	NY	^GSPC	DHI
DHR	DHR	Danaher	Manuf_Special	US	Indu	https://www.marketscreener.com/quote/stock/DANAHER-CORPORATION-12295/	https://finance.yahoo.com/quote/DHR?p=DHR&.tsrc=fin-srch	https://www.danaher.com	\N	\N	\N	0.5000	2026	\N	USD	\N	\N	\N	Manuf_Special	\N	.US	NY	^GSPC	DHR
ILMN	ILMN	Illumina	Healthcare	US	Heal	https://www.marketscreener.com/quote/stock/ILLUMINA-INC-9659/	\N	https://www.illumina.com	DNA-sekvens-måleudstyr	t	\N	\N	\N	\N	USD	\N	\N	\N	Healthcare	\N	.US	NY	^GSPC	ILMN
DHT	DHT	DHT Holdings	Trpt_Ship (Ener)	US	Ener	https://www.marketscreener.com/quote/stock/DHT-HOLDINGS-INC-11105059/	https://finance.yahoo.com/quote/DHT/	http://www.dhtankers.com/	Group of crude oil tanker companies situated in Monaco, Norway, Singapore, and India	t	\N	0.4200	2026	\N	USD	\N	\N	\N	Trpt_Ship (Ener)	\N	.US	NY	^GSPC	DHT
DIS	DIS	Walt-Disney	TechToCons	US	Tech	https://www.marketscreener.com/quote/stock/WALT-DISNEY-COMPANY-THE-4842/	\N	https://www.thewaltdisneycompany.com	\N	\N	\N	0.7400	2026	\N	USD	\N	\N	\N	TechToCons	\N	.US	NY	^GSPC	DIS
DKNG	DKNG	Draftkings Inc.	Holiday	US	C-Di	https://www.marketscreener.com/quote/stock/DRAFTKINGS-INC-61175285/	https://finance.yahoo.com/quote/DKNG/	www.draftkings.com	Prediction markets (betting).  Private: Kalshi (Investor: Seqoia Cap er investor) og Polymarket (Investor: Intercontinental Exchange(ICE), dvs. NYSE og LSE's ejer)	\N	\N	0.4500	2026	\N	USD	\N	\N	\N	Holiday	\N	.US	NY	^GSPC	DKNG
DKS	DKS	Dick's Sporting Goods	Holiday	US	C-Di	https://www.marketscreener.com/quote/stock/DICK-S-SPORTING-GOODS-INC-12310/	https://finance.yahoo.com/quote/DKS?p=DKS&.tsrc=fin-srch	https://www.dickssportinggoods.com	Omnichannel sporting goods retailer.	\N	\N	0.4000	2026	\N	USD	\N	\N	\N	Holiday	\N	.US	NY	^GSPC	DKS
DLO	DLO	DLocal 	TechToProfs	Uruguay	Tech	https://www.marketscreener.com/quote/stock/DLOCAL-LIMITED-123219061/	https://finance.yahoo.com/quote/DLO/	https://www.dlocal.com/	Global betalingsplatform til virksomheder	\N	\N	\N	\N	\N	USD	\N	\N	\N	TechToProfs	\N	.US	NY	^GSPC	DLO
DLR	DLR	Digital Realty (data center)	Property	US	REIT	https://www.marketscreener.com/quote/stock/DIGITAL-REALTY-TRUST-INC-12320/	https://finance.yahoo.com/quote/DLR/	https://www.digitalrealty.com	Operates data centers	\N	\N	0.5000	2026	\N	USD	\N	AI-infrastruktur	\N	Property	\N	.US	NY	^GSPC	DLR
DLTR	DLTR	Dollar Tree Stores	Retail	US	C-St	https://www.marketscreener.com/quote/stock/DOLLAR-TREE-INC-4868/	\N	https://www.dollartree.com/	\N	\N	\N	0.4700	2026	\N	USD	\N	\N	\N	Retail	\N	.US	NY	^GSPC	DLTR
DNA	DNA	Gingko Bioworks Hldgs	Pharma	US	Heal	https://www.marketscreener.com/quote/stock/GINKGO-BIOWORKS-HOLDINGS--127173269/	https://finance.yahoo.com/quote/DNA	https://www.ginkgobioworks.com	Syntetisk biologi: Celle-programmering som service på mange områder	t	\N	0.5800	2026	\N	USD	\N	\N	\N	Pharma	\N	.US	NY	^GSPC	DNA
DNB.OL	OSL:DNB	DNB (Den Norske Bank)	Bank	NO	Fina	https://www.marketscreener.com/quote/stock/DNB-BANK-ASA-124363442/	https://finance.yahoo.com/quote/DNB.OL?p=DNB.OL&.tsrc=fin-srch	https://www.dnb.no	Norges absolut største bank	t	\N	0.5300	2026	\N	NOK	\N	\N	\N	Bank	\N	.OL	LON	^OSEBX	DNB.OL
DNORD.CO	CPH:DNORD	DS Norden	Trpt_Ship	DK	Indu	https://www.marketscreener.com/quote/stock/DAMPSKIBSSELSKABET-NORDEN-1412883/	https://finance.yahoo.com/quote/DNORD.CO?p=DNORD.CO&.tsrc=fin-srch	https://www.norden.com	90% af last er dry cargo	t	\N	0.3900	2026	\N	DKK	\N	\N	\N	Trpt_Ship	\N	.CO	LON	^OMXC20	DNORD.CO
DOCS	DOCS	Doximity	Healthcare	US	Heal	https://www.marketscreener.com/quote/stock/DOXIMITY-INC-124007887/	https://finance.yahoo.com/quote/DOCS/	https://www.doximity.com/	Digital platform for medical professionals in the United States	\N	\N	0.2900	2026	\N	USD	\N	\N	\N	Healthcare	\N	.US	NY	^GSPC	DOCS
DOFG.OL	OSL:DOFG	DOF Group ASA	Oil&Gas	NO	Ener	https://www.marketscreener.com/quote/stock/DOF-GROUP-ASA-155689952/	https://finance.yahoo.com/quote/DOFG.OL/	https://www.dof.com/	globalt subsea-rederi med en moderne flåde	\N	\N	0.4400	2026	\N	\N	\N	\N	\N	Oil&Gas	\N	.OL	LON	^OSEBX	DOFG.OL
DOL.TO	TSE:DOL	Dollarama	Retail	CAN	C-St	https://www.marketscreener.com/quote/stock/DOLLARAMA-INC-5640759/	https://finance.yahoo.com/quote/DOL.TO?p=DOL.TO&.tsrc=fin-srch	https://www.dollarama.com	Stor discount-retailer, oprindeligt kun Canada, men købte i 2023 Dollarcity (Columbia m.fl.). Usædvanlig gode income-margins	t	\N	0.3500	2026	\N	CAD	\N	\N	\N	Retail	\N	.TO	NY	^GSPC	DOL.TO
DOM.L	LON:DOM	Domino's Pizza Group	Restaurants	UK	C-Di	https://www.marketscreener.com/quote/stock/DOMINO-S-PIZZA-GROUP-PLC-28742410/	https://finance.yahoo.com/quote/DOM.L?p=DOM.L&.tsrc=fin-srch	https://www.dominos.co.uk	\N	t	\N	0.3500	2026	\N	GBX	\N	\N	t	Restaurants	\N	.L	LON	^FTSE	DOM.L
DOMO	DOMO	Domo  - Class B	TechToProfs	US	Tech	https://www.marketscreener.com/quote/stock/DOMO-INC-44420354/	https://finance.yahoo.com/quote/DOMO	https://www.domo.com	Operates a cloud-based modern AI and data products platform in North America, Western Europe, Australia, Japan, and India	\N	\N	0.6700	2026	\N	USD	\N	\N	\N	TechToProfs	\N	.US	NY	^GSPC	DOMO
DPZ	DPZ	Domino Pizza US	Restaurants	US	C-Di	https://www.marketscreener.com/quote/stock/DOMINO-S-PIZZA-INC-12338/	\N	https://www.dominos.com	\N	\N	\N	0.5800	2026	\N	USD	\N	\N	\N	Restaurants	\N	.US	NY	^GSPC	DPZ
DQ	DQ	Daqo Renewable Energy Corp	Rnwb(Indu)	China	Indu	https://www.marketscreener.com/quote/stock/DAQO-NEW-ENERGY-CORP-12249683/	https://finance.yahoo.com/quote/DQ/	https://www.dqsolar.com	\N	t	\N	0.7000	2026	\N	USD	\N	\N	\N	Rnwb(Indu)	\N	.US	NY	^GSPC	DQ
DRI	DRI	Darden Restaurants	Restaurants	US	C-Di	https://www.marketscreener.com/quote/stock/DARDEN-RESTAURANTS-INC-12355/	\N	https://www.darden.com	Largest market cap casual dining	\N	\N	0.4500	2026	\N	USD	\N	\N	\N	Restaurants	\N	.US	NY	^GSPC	DRI
DRO.AX	ASX:DRO	DroneShield	Defense	AUS	Indu	https://www.marketscreener.com/quote/stock/DRONESHIELD-LIMITED-27547983/	https://finance.yahoo.com/quote/DRO.AX/	http://www.droneshield.com/	Forsvar mod droner o.lign. autonome enheder	\N	\N	0.6000	2026	\N	AUD	\N	\N	\N	Defense	\N	.AX	HKG	^HSI	DRO.AX
DSG.TO	TSE:DSG	Descartes System Group	TechToProfs	CAN	Tech	https://www.marketscreener.com/quote/stock/THE-DESCARTES-SYSTEMS-GRO-1409790/	https://finance.yahoo.com/quote/DSG.TO/	http://www.descartes.com/	Sw-company aggregator like Constellation: https://www.marketscreener.com/quote/stock/THE-DESCARTES-SYSTEMS-GRO-1409790/news/The-Descartes-Systems-Group-reaches-for-the-top-48552480/	\N	\N	0.2800	2026	\N	CAD	\N	\N	\N	TechToProfs	\N	.TO	NY	^GSPC	DSG.TO
DSNKY	DSNKY	Daiichi Sankyo	Pharma	Japan	Heal	https://www.marketscreener.com/quote/stock/DAIICHI-SANKYO-CO-LTD-6498062/	https://finance.yahoo.com/quote/DSNKY/	https://www.daiichisankyo.co.jp	Antibody-drug conjugater a la GenMab. Onkologi.	\N	\N	0.4200	2026	\N	JPY	\N	\N	\N	Pharma	\N	.US	NY	^GSPC	DSNKY
DSV.CO	CPH:DSV	DSV Panalpina	Trpt_Other	DK	Indu	https://www.marketscreener.com/quote/stock/DSV-A-S-65289675/	https://finance.yahoo.com/quote/DSV.CO?p=DSV.CO&.tsrc=fin-srch	https://www.dsv.com	Spedition/transport på land	t	\N	0.4400	2026	\N	DKK	\N	\N	\N	Trpt_Other	\N	.CO	LON	^OMXC20	DSV.CO
DTE.DE	ETR:DTE	Deutsche Telekom	Telecom	DE	Tele	https://www.marketscreener.com/quote/stock/DEUTSCHE-TELEKOM-AG-444661/	https://finance.yahoo.com/quote/DTE.DE?p=DTE.DE&.tsrc=fin-srch	https://telekom.com	\N	\N	\N	0.7000	2026	\N	EUR	\N	\N	\N	Telecom	\N	.DE	LON	^GDAXI	DTE.DE
DUK	DUK	Duke Energy	Util_MixedFuel	US	Util	https://www.marketscreener.com/quote/stock/DUKE-ENERGY-CORPORATION-11076385/	https://finance.yahoo.com/quote/DUK?p=DUK&.tsrc=fin-srch	https://www.duke-energy.com	Elproduktion og distr, også salg af gas	\N	\N	0.5500	2026	\N	USD	\N	\N	\N	Util_MixedFuel	\N	.US	NY	^GSPC	DUK
DUOL	DUOL	Duolingo	TechToCons	US	Tech	https://www.marketscreener.com/quote/stock/DUOLINGO-INC-125228573/	https://finance.yahoo.com/quote/DUOL?p=DUOL&.tsrc=fin-srch	https://www.duolingo.com	App til at lære sprog	\N	\N	0.2500	2026	\N	USD	\N	\N	\N	TechToCons	\N	.US	NY	^GSPC	DUOL
NDAQ	NDAQ	Nasdaq 	Services(Fina)	US	Fina	https://www.marketscreener.com/quote/stock/NASDAQ-INC-10173/	https://finance.yahoo.com/quote/NDAQ/	https://www.nasdaq.com	\N	\N	\N	0.4500	2026	\N	USD	\N	\N	\N	Services(Fina)	\N	.US	NY	^GSPC	NDAQ
DVA	DVA	DaVita	Healthcare	US	Heal	https://www.marketscreener.com/quote/stock/DAVITA-INC-12378/	https://finance.yahoo.com/quote/DVA?p=DVA&.tsrc=fin-srch	https://www.davita.com	Dialyse-cenre i USA	\N	\N	0.6500	2026	\N	USD	\N	\N	\N	Healthcare	\N	.US	NY	^GSPC	DVA
DVN	DVN	Devon Energy Corp	Oil&Gas	US	Ener	https://www.marketscreener.com/quote/stock/DEVON-ENERGY-CORPORATION-40311142/	https://finance.yahoo.com/quote/DVN?p=DVN&.tsrc=fin-srch	https://www.devonenergy.com	Oklahoma	\N	\N	0.4700	2026	\N	USD	\N	\N	\N	Oil&Gas	\N	.US	NY	^GSPC	DVN
DY	DY	Dycom	Construction	US	Indu	https://www.marketscreener.com/quote/stock/DYCOM-INDUSTRIES-INC-12388/	https://finance.yahoo.com/quote/DY?p=DY&.tsrc=fin-srch	https://www.dycomind.com	Entrepriser vedr elektriske anlæg	\N	\N	\N	\N	\N	USD	\N	\N	\N	Construction	\N	.US	NY	^GSPC	DY
EAPI.PA	EPA:EAPI	EuroAPI	Pharma	FR	Heal	https://www.marketscreener.com/quote/stock/EUROAPI-137177484/	https://finance.yahoo.com/quote/EAPI.PA?p=EAPI.PA&.tsrc=fin-srch	https://www.euroapi.com	Udvikling og produktionsmodning af active pharmaceutical ingredients (APIs). Udskilt af Sanofi 6.5.22. 	t	\N	0.4500	2026	\N	EUR	\N	\N	\N	Pharma	\N	.PA	LON	^FCHI	EAPI.PA
EBAY	EBAY	Ebay	TechToCons	US	Tech	https://www.marketscreener.com/quote/stock/EBAY-INC-4869/	\N	https://www.ebayinc.com	\N	\N	\N	0.6500	2026	\N	USD	\N	\N	\N	TechToCons	\N	.US	NY	^GSPC	EBAY
EC	EC	Ecopetrol	Oil&Gas	Colombia	Ener	https://www.marketscreener.com/quote/stock/ECOPETROL-S-A-9059900/	https://finance.yahoo.com/quote/EC?p=EC&.tsrc=fin-srch	https://www.ecopetrol.com.co	Olieselskab i syd- og nordamerika. Iflg. Econ 15.7.23 et ganske veldrevet selskab.	\N	\N	0.3500	2026	\N	USD	\N	\N	\N	Oil&Gas	\N	.US	NY	^GSPC	EC
ECAR.L	LON:ECAR	iShares Electric Vehicles UCITS ETF (USD)	Automotive	UK	C-Di	https://finance.yahoo.com/quote/ECAR.L?p=ECAR.L&.tsrc=fin-srch	https://finance.yahoo.com/quote/ECAR.L?p=ECAR.L&.tsrc=fin-srch	\N	\N	t	\N	0.7500	2026	\N	USD	\N	\N	\N	Automotive	\N	.L	LON	^FTSE	ECAR.L
ECL	ECL	Ecolab	Chemical	US	Indu	https://www.marketscreener.com/quote/stock/ECOLAB-INC-12399/	\N	https://www.ecolab.com	\N	\N	\N	0.7500	2026	\N	USD	\N	\N	\N	Other[Indu]	7	.US	NY	^GSPC	ECL
ECO	ECO	Okeanis Eco Tankers	Trpt_Ship (Ener)	NO	Ener	https://www.marketscreener.com/quote/stock/OKEANIS-ECO-TANKERS-CORP-111314538/	https://finance.yahoo.com/quote/ECO	https://www.okeanisecotankers.com	Verdens nyeste flåde af tankskibe (græsk). Konkurrenter NAT, FRO og DHT, mest FRO, som også har ung flåde.	\N	\N	0.3800	2026	\N	USD	\N	\N	\N	Trpt_Ship (Ener)	\N	.US	NY	^GSPC	ECO
EDPR.LS	ELI:EDPR	EDP Renováveis, S.A. 	Util_Rnwb	Portugal	Util	https://www.marketscreener.com/quote/stock/EDP-RENOV-VEIS-S-A-3073163/	https://finance.yahoo.com/quote/EDPR.LS?p=EDPR.LS&.tsrc=fin-srch	https://www.edpr.com	\N	\N	\N	0.3900	2026	\N	EUR	\N	\N	\N	Util_Rnwb	\N	.LS	LON	^STOXX	EDPR.LS
EDV.L	LON:EDV	Endeavour Mining	Gold	UK	Basi	https://www.marketscreener.com/quote/stock/ENDEAVOUR-MINING-PLC-1409834/	https://finance.yahoo.com/quote/EDV.L/	https://www.endeavourmining.com/	Multi-asset gold producer in West Africa	\N	\N	0.3700	2026	\N	USD	\N	\N	\N	Gold	\N	.L	LON	^FTSE	EDV.L
EDV.TO	TSE:EDV	Endeavour Mining	Gold	LON	Basi	https://www.marketscreener.com/quote/stock/ENDEAVOUR-MINING-PLC-1409834/	https://finance.yahoo.com/quote/EDV.L/	https://www.endeavourmining.com/	Multi-asset gold producer in West Africa	\N	\N	0.6200	2026	\N	CAD	\N	\N	\N	Gold	\N	.TO	NY	^GSPC	EDV.TO
EG	EG	Everest Group	Insurance	US	Fina	https://www.marketscreener.com/quote/stock/EVEREST-GROUP-LTD-14215/	https://finance.yahoo.com/quote/EG?p=EG&.tsrc=fin-srch	https://www.everestglobal.com	Mest skadesforsikring (70%)	\N	\N	0.3900	2026	\N	USD	\N	\N	\N	Insurance	\N	.US	NY	^GSPC	EG
EGP	EGP	Eastgroup Properties	Property	US	REIT	https://www.marketscreener.com/quote/stock/EASTGROUP-PROPERTIES-INC-12428/	https://finance.yahoo.com/quote/EGP	https://www.eastgroup.net	Industrial Property (som PLD, but only Sunbelt)	\N	\N	0.4500	2026	\N	USD	\N	\N	\N	Property	\N	.US	NY	^GSPC	EGP
EH	EH	Ehang	Trpt_Other	China	Indu	https://www.marketscreener.com/quote/stock/EHANG-HOLDINGS-LIMITED-74800546/	https://finance.yahoo.com/quote/EH?p=EH&.tsrc=fin-srch	https://www.ehang.com	Autonome flyvende droner til persontransport mm	\N	\N	0.4500	2026	\N	USD	\N	\N	\N	Trpt_Other	\N	.US	NY	^GSPC	EH
EIF.TO	TSE:EIF	Exchange Income Corp	Trpt_Airline	CAN	Indu	https://www.marketscreener.com/quote/stock/EXCHANGE-INCOME-CORPORATI-1409855/	\N	https://www.exchangeincomecorp.ca	\N	\N	\N	0.5500	2026	\N	CAD	\N	\N	\N	Trpt_Airline	\N	.TO	NY	^GSPC	EIF.TO
EIX	EIX	Edison International	Util_MixedFuel	US	Util	https://www.marketscreener.com/quote/stock/EDISON-INTERNATIONAL-12435/	https://finance.yahoo.com/quote/EIX/	http://www.edison.com/	Produktion og distribution af elektricitet i Californien. 14000 ansatte	\N	\N	0.6000	2026	\N	USD	\N	\N	\N	Util_MixedFuel	\N	.US	NY	^GSPC	EIX
EL	EL	Estee Lauder	Luxury	US	C-Di	https://www.marketscreener.com/quote/stock/ESTEE-LAUDER-12437/	\N	https://www.elcompanies.com	Kosmetik	\N	\N	0.2600	2026	\N	USD	\N	\N	\N	Luxury	\N	.US	NY	^GSPC	EL
EL.PA	EPA:EL	EssilorLuxottidca SA	Luxury	FR	C-Di	https://www.marketscreener.com/quote/stock/ESSILORLUXOTTICA-4641/	https://finance.yahoo.com/quote/EL.PA?p=EL.PA&.tsrc=fin-srch	https://www.essilorluxottica.com	Mode-rigtige linser og brillestel. 182.000 ansatte. Italiens rigeste mand styrer	\N	\N	0.6500	2026	\N	EUR	\N	\N	\N	Luxury	\N	.PA	LON	^FCHI	EL.PA
ELD.TO	TSE:ELD	Eldorado Gold Corp	Gold	CAN	Basi	https://www.marketscreener.com/quote/stock/ELDORADO-GOLD-CORPORATION-50060889/	https://finance.yahoo.com/quote/EGO/	https://www.eldoradogold.com/	Miner i Tyrkiet, Canada og Grækenland	\N	\N	\N	\N	\N	CAD	\N	\N	\N	Gold	\N	.TO	NY	^GSPC	ELD.TO
ELE.MC	BME:ELE	Endesa	Oil&Gas	ES	Ener	https://www.marketscreener.com/quote/stock/ENDESA-S-A-69599/	https://finance.yahoo.com/quote/ELE.MC/	http://www.endesa.com/	En af Spaniens største energiselskaber (mest konv. energi). Højt udbytte	\N	\N	0.4500	2026	\N	EUR	\N	\N	\N	Oil&Gas	\N	.MC	LON	^STOXX	ELE.MC
ELV	ELV	Elevance (tidl Anthem)	Healthcare	US	Heal	https://www.marketscreener.com/quote/stock/ELEVANCE-HEALTH-INC-18740543/	https://finance.yahoo.com/quote/ELV/	https://www.elevancehealth.com	Health insurance	\N	\N	0.4000	2026	\N	USD	\N	\N	\N	Healthcare	\N	.US	NY	^GSPC	ELV
EME	EME	Emcor	Construction	US	Indu	https://www.marketscreener.com/quote/stock/EMCOR-GROUP-INC-12447/	https://finance.yahoo.com/quote/EME/	http://www.emcorgroup.com/	Industrial and energy infrastructure to utilities, power plants and refineries.  Recently a leading provider to AI data centers.	\N	\N	0.4000	2026	\N	USD	\N	AI-infrastruktur	\N	Construction	\N	.US	NY	^GSPC	EME
EMIM.L	LON:EMIM	iShares Core MSCI Emerging Markets IMI UCITS ETF USD (Acc)	Diverse_na	Emergent	na	https://www.blackrock.com/dk/formidler/produkter/264659/ishares-msci-emerging-markets-imi-ucits-etf	https://finance.yahoo.com/quote/EMIM.L?p=EMIM.L&.tsrc=fin-srch	\N	\N	\N	\N	0.4000	2026	\N	USD	\N	\N	\N	Diverse_na	\N	.L	LON	^FTSE	EMIM.L
ENB	ENB	Enbridge	Oil&Gas	CAN	Ener	https://www.marketscreener.com/quote/stock/ENBRIDGE-INC-1409882/	\N	https://www.enbridge.com	\N	t	\N	0.3500	2026	\N	USD	\N	\N	\N	Oil&Gas	\N	.US	NY	^GSPC	ENB
ENB-PF.TO	TSE:ENB.PF.F	Enbridge Preferred Ser F	Oil&Gas	CAN	Ener	https://www.preferredstockchannel.com/symbol/enb.prf.ca/	https://finance.yahoo.com/quote/ENB-PF.TO?p=ENB-PF.TO&.tsrc=fin-srch	https://www.enbridge.com	Reset 1.9.28 til CAN-bond + 2,51%. Ved seneste reset (1.6.23) steg udb fra 1,17 usd/år til 1,38.	t	\N	0.5500	2026	\N	CAD	\N	\N	\N	Oil&Gas	\N	.TO	NY	^GSPC	ENB-PF.TO
ENB-PFV.TO	TSE:ENB.PF.V	Enbridge Preferred Ser 5	Oil&Gas	CAN	Ener	https://www.marketscreener.com/quote/stock/ENBRIDGE-INC-42378784/	https://finance.yahoo.com/quote/ENB-PFV.TO?p=ENB-PFV.TO	https://www.enbridge.com	Resets 1.3.24 til 2,82% + 5 yr US bond	t	\N	0.5000	2026	\N	CAD	\N	\N	\N	Oil&Gas	\N	.TO	NY	^GSPC	ENB-PFV.TO
ENEL.MI	BIT:ENEL	Enel SpA	Util_MixedFuel	IT	Util	https://www.marketscreener.com/quote/stock/ENEL-S-P-A-70935/	https://finance.yahoo.com/quote/EOAN.DE/profile/	https://www.enel.it/	Italian No. 1 producer and distributor of electricity and gas	\N	\N	0.5500	2026	\N	EUR	\N	\N	\N	Util_MixedFuel	\N	.MI	LON	^STOXX	ENEL.MI
ENG.MC	BME:ENG	Enagas	Trpt_Ship (Ener)	ES	Ener	https://www.marketscreener.com/quote/stock/ENAG-S-S-A-409361/	https://finance.yahoo.com/quote/ENG.MC/	http://www.enagas.es/	Gastransport: Rørledninger og re-gasificeringsanlæg	\N	\N	0.5600	2026	\N	EUR	\N	\N	\N	Trpt_Ship (Ener)	\N	.MC	LON	^STOXX	ENG.MC
ENGI.PA	EPA:ENGI	ENGIE S.A.	Util_Rnwb	FR	Util	https://www.marketscreener.com/quote/stock/ENGIE-4995/	https://finance.yahoo.com/quote/ENGI.PA/	https://www.engie.com	Low-carbon energy and services	\N	\N	0.4400	2026	\N	EUR	\N	\N	\N	Util_Rnwb	\N	.PA	LON	^FCHI	ENGI.PA
ENI.MI	BIT:ENI	Eni	Oil&Gas	IT	Ener	https://www.marketscreener.com/quote/stock/ENI-SPA-413403/	\N	https://www.eni.com/	Mellemøstlig gas-udvinding	\N	\N	0.5300	2026	\N	EUR	\N	\N	\N	Oil&Gas	\N	.MI	LON	^STOXX	ENI.MI
ENPH	ENPH	Enphase Energy	Rnwb(Indu)	US	Indu	https://www.marketscreener.com/quote/stock/ENPHASE-ENERGY-INC-10335237/	https://finance.yahoo.com/quote/ENPH/	https://www.enphase.com	Microinverter systems for the solar photovoltaic industry.	t	\N	0.4000	2026	\N	USD	\N	\N	\N	Rnwb(Indu)	\N	.US	NY	^GSPC	ENPH
ENR.DE	ETR:ENR	Siemens Energy AG	Rnwb(Indu)	DE	Indu	https://www.marketscreener.com/quote/stock/SIEMENS-ENERGY-AG-113080700/	https://finance.yahoo.com/quote/ENR.DE/	https://www.siemens-energy.com	Consulting & service energi-anlæg	t	\N	0.3000	2026	\N	EUR	\N	\N	\N	Rnwb(Indu)	\N	.DE	LON	^GDAXI	ENR.DE
ENS	ENS	EnerSys (Batterier)	Batteries	US	Indu	https://www.marketscreener.com/quote/stock/ENERSYS-12464/	https://finance.yahoo.com/quote/ENS?p=ENS&.tsrc=fin-srch	https://www.enersys.com	Electrical Components and Equipment	\N	\N	0.5500	2026	\N	USD	\N	\N	\N	Other[Indu]	7	.US	NY	^GSPC	ENS
ENTG	ENTG	Entegris	Semi	US	Tech	https://www.marketscreener.com/quote/stock/ENTEGRIS-INC-9185/	https://finance.yahoo.com/quote/ENTG/	https://www.entegris.com	Halvleder proces udstyr og materialer	\N	\N	0.6000	2026	\N	USD	\N	\N	\N	Semi	\N	.US	NY	^GSPC	ENTG
ENX.PA	EPA:ENX	Euronext	Services(Fina)	NL	Fina	https://www.marketscreener.com/quote/stock/EURONEXT-N-V-16725768/	https://finance.yahoo.com/quote/ENX.PA/	https://www.euronext.com	Driver forskellige europæiske børser	\N	\N	0.5300	2026	\N	EUR	\N	\N	\N	Services(Fina)	\N	.PA	LON	^FCHI	ENX.PA
EOAN.DE	ETR:EOAN	E.ON SE	Util_MixedFuel	DE	Util	https://www.marketscreener.com/quote/stock/E-ON-SE-3818998/	https://finance.yahoo.com/quote/EOAN.DE/	https://www.eon.com	El-forsyning i EU, 50% af salg i DE	\N	\N	0.4000	2026	\N	EUR	\N	\N	\N	Util_MixedFuel	\N	.DE	LON	^GDAXI	EOAN.DE
EOG	EOG	EOG Resources	Oil&Gas	US	Ener	https://www.marketscreener.com/quote/stock/EOG-RESOURCES-INC-12468/	https://finance.yahoo.com/quote/EOG?p=EOG&.tsrc=fin-srch	https://www.eogresources.com	Olie, gas mm internationalt	\N	\N	0.5300	2026	\N	USD	\N	\N	\N	Oil&Gas	\N	.US	NY	^GSPC	EOG
EPD	EPD	Enterprise Products Partners L.P. (MLP)	Oil&Gas	US	Ener	https://www.marketscreener.com/quote/stock/ENTERPRISE-PRODUCTS-PARTN-12478/	https://finance.yahoo.com/quote/EPD/	https://www.enterpriseproducts.com	\N	\N	\N	0.3500	2026	\N	USD	\N	\N	\N	Oil&Gas	\N	.US	NY	^GSPC	EPD
EPR	EPR	EPR Properties (entertainment)	Property	US	REIT	https://www.marketscreener.com/quote/stock/ESSENTIAL-PROPERTIES-REAL-44315911/	\N	https://www.essentialproperties.com	Oplevelses-anlæg	\N	\N	0.3900	2026	\N	USD	\N	\N	\N	Property	\N	.US	NY	^GSPC	EPR
EPR-PE	EPR-E	EPR Properties, 9.00% Series E Cumulative Convertible Preferred Shares	Property	US	REIT	https://www.marketscreener.com/quote/stock/EPR-PROPERTIES-11908389/	https://finance.yahoo.com/quote/EPR-PE?p=EPR-PE&.tsrc=fin-srch	https://www.eprkc.com	Cannot be called (but converted to commons)	\N	\N	0.3300	2026	\N	USD	\N	\N	\N	Property	\N	.US	NY	^GSPC	EPR-PE
EPRT	EPRT	Essential Properties Realty Trust	Property	US	REIT	https://www.marketscreener.com/quote/stock/ESSENTIAL-PROPERTIES-REAL-44315911/	https://finance.yahoo.com/quote/EPRT?p=EPRT&.tsrc=fin-srch	https://www.essentialproperties.com	Triple-net leases of commercial buildings	\N	\N	0.7000	2026	\N	USD	\N	\N	\N	Property	\N	.US	NY	^GSPC	EPRT
EQIX	EQIX	Equinix	Property	US	REIT	https://www.marketscreener.com/quote/stock/EQUINIX-INC-20565916/	\N	https://www.equinix.com	Bl.a. AI-GPUs som service (SaaS). Datacentre, netværk (interconnections)	\N	\N	0.4000	2026	\N	USD	\N	AI-infrastruktur	\N	Property	\N	.US	NY	^GSPC	EQIX
EQNR	EQNR	Equinor (Statoil)	Oil&Gas	NO	Ener	https://www.marketscreener.com/quote/stock/EQUINOR-ASA-43510692/	\N	https://www.equinor.com	Refining and distribution of oil products (98.8%), sales of crude oil, productionof methanol	\N	\N	0.3000	2026	\N	USD	\N	\N	\N	Oil&Gas	\N	.US	NY	^GSPC	EQNR
EQR	EQR	Equity Residential	Property	US	REIT	https://www.marketscreener.com/quote/stock/EQUITY-RESIDENTIAL-12485/	https://finance.yahoo.com/quote/EQR?p=EQR&.tsrc=fin-srch	https://www.equityapartments.com	\N	\N	\N	0.4000	2026	\N	USD	\N	\N	\N	Property	\N	.US	NY	^GSPC	EQR
EQT	EQT	EQT Corporation	Oil&Gas	US	Ener	https://www.marketscreener.com/quote/stock/EQT-CORPORATION-12492/	https://finance.yahoo.com/quote/EQT/	https://www.eqt.com/	Producer of natural gas	\N	\N	0.6100	2026	\N	USD	\N	\N	\N	Oil&Gas	\N	.US	NY	^GSPC	EQT
EQT.ST	STO:EQT	EQT AB (private equity, buyouts)	Investment	SE	Fina	https://www.marketscreener.com/quote/stock/EQT-AB-PUBL-66480635/	https://finance.yahoo.com/quote/EQT.ST?p=EQT.ST&.tsrc=fin-srch	https://www.eqtgroup.com	\N	\N	\N	0.5000	2026	\N	SEK	\N	\N	\N	Investment	\N	.ST	LON	^OMX	EQT.ST
ERA.PA	EPA:ERA	Eramet	Mining	FR	Basi	https://www.marketscreener.com/quote/stock/ERAMET-4752/	https://finance.yahoo.com/quote/ERA.PA?p=ERA.PA&.tsrc=fin-srch	https://www.eramet.com	Titanium	t	\N	\N	\N	\N	EUR	\N	\N	\N	Mining	\N	.PA	LON	^FCHI	ERA.PA
ERIC-B.ST	STO:ERIC-B	Telefonaktiebolaget LM Ericsson Class B	ElectrComponents	SE	Tech	https://www.marketscreener.com/quote/stock/ERICSSON-6494918/	https://finance.yahoo.com/quote/ERIC-B.ST/	https://www.ericsson.com/	Mobile connectivity solutions to communications service providers	\N	\N	0.5800	2026	\N	SEK	\N	\N	\N	ElectrComponents	\N	.ST	LON	^OMX	ERIC-B.ST
ESI	ESI	Element Solutions Inc	Semi	US	Tech	https://www.marketscreener.com/quote/stock/ELEMENT-SOLUTIONS-INC-54321056/	https://finance.yahoo.com/quote/ESI/	https://www.elementsolutionsinc.com/	Kemikalier for håndtering af elektronik/chips	\N	\N	0.2500	2026	\N	USD	\N	\N	\N	Semi	\N	.US	NY	^GSPC	ESI
ESLT	ESLT	Elbit	Defense	Israel	Indu	https://www.marketscreener.com/quote/stock/ELBIT-SYSTEMS-LTD-9214/	https://finance.yahoo.com/quote/ESLT/	http://www.elbitsystems.com/	Airborne, land and naval systems and products for defense, homeland security and commercial aviation applications	\N	\N	0.6500	2026	\N	USD	\N	\N	\N	Defense	\N	.US	NY	^GSPC	ESLT
ESPO.L	LON:ESPO	VanEck Vectors Video Gaming and eSports UCITS ETF	TechToCons	Intl	Tech	https://www.vaneck.com/dk/en/etf/equity/espo/holdings	https://finance.yahoo.com/quote/ESPO.L?p=ESPO.L&.tsrc=fin-srch	\N	\N	\N	\N	0.5000	2026	\N	GBX	\N	\N	\N	TechToCons	\N	.L	LON	^FTSE	ESPO.L
ET	ET	Energy Transfer LP	Oil&Gas	US	Ener	https://www.marketscreener.com/quote/stock/ENERGY-TRANSFER-LP-40511769/	https://finance.yahoo.com/quote/ET?p=ET&.tsrc=fin-srch	https://www.energytransfer.com	Opstår 22.10.18 ved fusion af ETP og ETE	\N	\N	0.6100	2026	\N	USD	\N	\N	\N	Oil&Gas	\N	.US	NY	^GSPC	ET
ETL.PA	EPA:ETL	Eutelsat Communications SA	Telecom	FR	Tele	https://www.marketscreener.com/quote/stock/EUTELSAT-COMMUNICATIONS-5147/	https://finance.yahoo.com/quote/ETL.PA/	https://www.eutelsat.com/en/home.html	Verdens førende indenfor satelitkommunikation	\N	\N	0.7000	2026	\N	EUR	\N	\N	\N	Telecom	\N	.PA	LON	^FCHI	ETL.PA
ETOR	ETOR	eToro Group 	Investment	Israel	Fina	https://www.marketscreener.com/quote/stock/ETORO-GROUP-LTD-188129163/	https://finance.yahoo.com/quote/ETOR/	https://www.etoro.com/	Platform for handel med aktier, kryptoaktiver, råvarer, valutaer og optioner	\N	\N	0.6500	2026	\N	USD	\N	\N	\N	Investment	\N	.US	NY	^GSPC	ETOR
EVO.ST	CPH:EVO	Evolution Gaming Group	Holiday	SE	C-Di	https://www.marketscreener.com/quote/stock/EVOLUTION-AB-58808466/	https://finance.yahoo.com/quote/EVO.ST?p=EVO.ST	https://www.evolution.com	Live casinos (over nettet) & random-number games (over-nettet-spillemaskiner)	t	\N	0.3700	2026	\N	SEK	\N	\N	\N	Holiday	\N	.ST	LON	^OMX	EVO.ST
EVR	EVR	Evercore	Services(Fina)	US	Fina	https://www.marketscreener.com/quote/stock/EVERCORE-INC-30993/	https://finance.yahoo.com/quote/EVR/	http://www.evercore.com/	Independent investment banking advisory company	\N	\N	0.5000	2026	\N	USD	\N	\N	\N	Services(Fina)	\N	.US	NY	^GSPC	EVR
EXEL	EXEL	Exelixis	Pharma	US	Heal	https://www.marketscreener.com/quote/stock/EXELIXIS-INC-9235/	\N	https://www.exelixis.com	\N	\N	\N	0.2500	2026	\N	USD	\N	\N	\N	Pharma	\N	.US	NY	^GSPC	EXEL
EXX.JO	JSE:EXX	Exxaro Resources 	Oil&Gas	Sydafrika	Ener	https://www.marketscreener.com/quote/stock/EXXARO-RESOURCES-LIMITED-1413382/	https://finance.yahoo.com/quote/EXX.JO?p=EXX.JO&.tsrc=fin-srch	https://www.exxaro.com	Kul	\N	\N	0.5500	2026	\N	ZAR	\N	\N	\N	Oil&Gas	\N	.JO	Other	^DJAFK	EXX.JO
F	F	Ford Motor Company	Automotive	US	C-Di	https://www.marketscreener.com/quote/stock/FORD-MOTOR-COMPANY-12542/	\N	https://www.corporate.ford.com	\N	\N	\N	0.5300	2026	\N	USD	\N	\N	\N	Automotive	\N	.US	NY	^GSPC	F
FANG	FANG	Diamondback Energy	Oil&Gas	US	Ener	https://www.marketscreener.com/quote/stock/DIAMONDBACK-ENERGY-INC-11732858/	https://finance.yahoo.com/quote/FANG?p=FANG&.tsrc=fin-srch	https://www.diamondbackenergy.com	Oil & gas, mest udvinding. Midland, Texas	\N	\N	0.3500	2026	\N	USD	\N	\N	\N	Oil&Gas	\N	.US	NY	^GSPC	FANG
FCEL	FCEL	Fuel Cell Energy	Rnwb(Ener)	US	Ener	https://www.marketscreener.com/quote/stock/FUELCELL-ENERGY-INC-58195415/	https://finance.yahoo.com/quote/FCEL?p=FCEL&.tsrc=fin-srch	https://www.fuelcellenergy.com	\N	\N	\N	0.5300	2026	\N	USD	\N	\N	\N	Rnwb(Ener)	\N	.US	NY	^GSPC	FCEL
FCX	FCX	Freeport-McMoran (kobber mm.)	Mining	US	Basi	https://www.marketscreener.com/quote/stock/FREEPORT-MCMORAN-INC-12574/	\N	https://www.fcx.com	Copper and gold	\N	\N	0.3900	2026	\N	USD	\N	\N	\N	Mining	\N	.US	NY	^GSPC	FCX
FDUS	FDUS	Fidus Investment	Investment	US	Fina	https://www.marketscreener.com/quote/stock/FIDUS-INVESTMENT-CORPORAT-8232821/	https://finance.yahoo.com/quote/FDUS?p=FDUS&.tsrc=fin-srch	https://www.fdus.com	BDC	t	\N	0.5000	2026	\N	USD	\N	\N	\N	Investment	\N	.US	NY	^GSPC	FDUS
FDX	FDX	FedEx	Trpt_Other	US	Indu	https://www.marketscreener.com/quote/stock/FEDEX-CORPORATION-12585/	https://finance.yahoo.com/quote/FDX/	https://www.fedex.com	\N	\N	\N	0.4500	2026	\N	USD	\N	\N	\N	Trpt_Other	\N	.US	NY	^GSPC	FDX
FIG	FIG	Figma	TechToProfs	US	Tech	https://www.marketscreener.com/quote/stock/FIGMA-INC-192764947/	https://finance.yahoo.com/quote/FIG/	http://www.figma.com/	Prototyping software. Google og MSFT nøglekunder (>100.000 $ køb pr. år)	\N	\N	0.5300	2026	\N	USD	\N	\N	\N	TechToProfs	\N	.US	NY	^GSPC	FIG
FINV	FINV	Finvolution (ADR)	Fintech	China	Fina	https://www.marketscreener.com/quote/stock/FINVOLUTION-GROUP-38626837/	https://finance.yahoo.com/quote/FINV?p=FINV&.tsrc=fin-srch	https://www.finvgroup.com/e	Låneformidler consumer-credit. Konkurrenter: QFIN, LX, Lufax (LU), X financial (XYF). Også offshore operationer.	t	\N	0.3700	2026	\N	USD	\N	\N	\N	Fintech	\N	.US	NY	^GSPC	FINV
FISV	FISV	Fiserv	Fintech	US	Fina	https://www.marketscreener.com/quote/stock/FISERV-INC-4873/	https://finance.yahoo.com/quote/FISV/	https://www.fiserv.com/	Fintech a la PayPal og Block/Square	\N	\N	0.3900	2026	\N	USD	\N	\N	\N	Fintech	\N	.US	NY	^GSPC	FISV
FIVE	FIVE	Five Below	Retail	US	C-St	https://www.marketscreener.com/quote/stock/FIVE-BELOW-INC-11076428/	\N	https://www.fivebelow.com	Tøj til unge	\N	\N	0.4500	2026	\N	USD	\N	\N	\N	Retail	\N	.US	NY	^GSPC	FIVE
FIVN	FIVN	Five9, Inc.	TechToProfs	US	Tech	https://www.marketscreener.com/quote/stock/FIVE9-INC-16253042/	https://finance.yahoo.com/quote/FIVN/	https://www.five9.com/	Call-centers (cloud-baseret)	\N	\N	0.4500	2026	\N	USD	\N	\N	\N	TechToProfs	\N	.US	NY	^GSPC	FIVN
FLNG	FLNG	Flex LNG	Trpt_Ship (Ener)	Bermuda	Ener	https://www.marketscreener.com/quote/stock/FLEX-LNG-LTD-111319127/	https://finance.yahoo.com/quote/FLNG?p=FLNG&.tsrc=fin-srch	https://www.flexlng.com	LNG tankers	t	\N	0.4400	2026	\N	USD	\N	\N	\N	Trpt_Ship (Ener)	\N	.US	NY	^GSPC	FLNG
FLR	FLR	Fluor Corporation	Construction	US	Indu	https://www.marketscreener.com/quote/stock/FLUOR-CORPORATION-41148781/	https://finance.yahoo.com/quote/FLR/	https://www.fluor.com/	Byggeri, især indenfor energi og byudvikling	\N	\N	0.8000	2026	\N	USD	\N	\N	\N	Construction	\N	.US	NY	^GSPC	FLR
FLS.CO	CPH:FLS	FLSmidth	Mining	DK	Basi	https://www.marketscreener.com/quote/stock/FLSMIDTH-CO-A-S-1412901/	https://finance.yahoo.com/quote/FLS.CO?p=FLS.CO&.tsrc=fin-srch	https://www.flsmidth.com	Maskineri til mineindustri	\N	\N	0.5900	2026	\N	DKK	\N	\N	\N	Mining	\N	.CO	LON	^OMXC20	FLS.CO
FLUT	FLUT	Flutter Entertainment	Holiday	IRL	C-Di	https://www.marketscreener.com/quote/stock/FLUTTER-ENTERTAINMENT-PLC-120788844/	https://finance.yahoo.com/quote/FLUT/	http://www.flutter.com/	23000 ansatte. Gambling, specilt sports-betting. Irsk, men "operational HQ" i US, deres største marked USA (37% af oms2023). IPO (NYSE) var 29.1.20	\N	\N	0.4500	2026	\N	USD	\N	\N	\N	Holiday	\N	.US	NY	^GSPC	FLUT
FLUX	FLUX	Flux Power	Batteries	US	Indu	https://www.marketscreener.com/quote/stock/FLUX-POWER-HOLDINGS-INC-11877787/	https://www.fluxpower.com/	https://www.fluxpower.com	Batterier	\N	\N	0.5500	2026	\N	USD	\N	\N	\N	Other[Indu]	7	.US	NY	^GSPC	FLUX
FN	FN	Fabrinet	ElectrComponents	Thailand	Tech	https://www.marketscreener.com/quote/stock/FABRINET-6340607/	https://finance.yahoo.com/quote/FN/	https://www.fabrinet.com	Præcisions-produktion indenfor elektronik og elektromekanik	\N	\N	0.7900	2026	\N	USD	\N	\N	\N	ElectrComponents	\N	.US	NY	^GSPC	FN
FNV	FNV	Franco-Nevada Corp	Gold	CAN	Basi	https://www.marketscreener.com/quote/stock/FRANCO-NEVADA-CORPORATION-9276331/	https://finance.yahoo.com/quote/FNV?p=FNV&.tsrc=fin-srch	https://www.franco-nevada.com	324 miner og 82 'energi-aktiver' worldwide. 40 ansatte: Lever af royalties.	\N	\N	0.4200	2026	\N	USD	\N	\N	\N	Gold	\N	.US	NY	^GSPC	FNV
FORTUM.HE	HEL:FORTUM	Fortum (utility)	Util_Rnwb	Finland	Util	https://www.marketscreener.com/quote/stock/FORTUM-OYJ-1412461/	https://finance.yahoo.com/quote/FORTUM.HE/	https://www.fortum.com	Renewable energy, også nuclear	\N	\N	0.4700	2026	\N	EUR	\N	\N	\N	Util_Rnwb	\N	.HE	LON	^STOXX	FORTUM.HE
OLED	OLED	Universal Display Corp	Semi	US	Tech	https://www.marketscreener.com/quote/stock/UNIVERSAL-DISPLAY-CORPORA-10394/	\N	https://www.oled.com	Organic Light Emitting Diodes (OLED)	\N	\N	0.6800	2026	\N	USD	\N	\N	\N	Semi	\N	.US	NY	^GSPC	OLED
FRES.L	LON:FRES	Fresnillo plc	Mining	Mexico	Basi	https://www.marketscreener.com/quote/stock/FRESNILLO-PLC-4008409/	https://finance.yahoo.com/quote/FRES.L/	https://www.fresnilloplc.com/	Silver and gold mining. "World's leading silver producer"	\N	\N	0.5500	2026	\N	GBX	\N	\N	\N	Mining	\N	.L	LON	^FTSE	FRES.L
FRO	FRO	Frontline plc	Trpt_Ship (Ener)	US	Ener	https://www.marketscreener.com/quote/stock/FRONTLINE-PLC-26123460/	https://finance.yahoo.com/quote/FRO?p=FRO&.tsrc=fin-srch	https://www.frontlineplc.cy	Shipping olie	\N	\N	\N	\N	\N	USD	\N	\N	\N	Trpt_Ship (Ener)	\N	.US	NY	^GSPC	FRO
FRVIA.PA	EPA:FRVIA	Forvia (tidl: Faurecia)	Automotive	FR	C-Di	https://www.marketscreener.com/quote/stock/FAURECIA-SE-4647/	\N	https://www.forvia.com	Bil-komponenter	\N	\N	0.6000	2026	\N	EUR	\N	\N	\N	Automotive	\N	.PA	LON	^FCHI	FRVIA.PA
FSK	FSK	FS KKR Capital Corp	BDC	US	Fina	https://www.marketscreener.com/quote/stock/FS-KKR-CAPITAL-CORP-16290128/	https://finance.yahoo.com/quote/FSK?p=FSK&.tsrc=fin-srch	https://www.fskkradvisor.com	Secured  loans	t	\N	0.5500	2026	\N	USD	\N	\N	\N	BDC	\N	.US	NY	^GSPC	FSK
FSLR	FSLR	First Solar	Rnwb(Indu)	US	Indu	https://www.marketscreener.com/quote/stock/FIRST-SOLAR-INC-37008/	https://finance.yahoo.com/quote/FSLR?p=FSLR&.tsrc=fin-srch	https://www.firstsolar.com	Fremstilling af solpaneler 	\N	\N	0.3000	2026	\N	USD	\N	\N	\N	Rnwb(Indu)	\N	.US	NY	^GSPC	FSLR
FTEK.L	LON:FTEK	Invesco KBW NASDAQ Fintech UCITS ETF Acc	Fintech	US	Fina	https://etf.invesco.com/gb/institutional/en/product/invesco-kbw-nasdaq-fintech-ucits-etf-acc/trading-information	https://finance.yahoo.com/quote/FTEK.L?p=FTEK.L&.tsrc=fin-srch	https://www.invesco.com/dk/en/financial-products/etfs/invesco-kbw-nasdaq-fintech-ucits-etf-acc.html	Top (2025aug): Sofi, Robinhood, Lendigclub, Interactive Brokers, Wisdomtree	t	\N	0.2700	2026	\N	GBX	\N	\N	\N	Fintech	\N	.L	LON	^FTSE	FTEK.L
FTK.DE	ETR:FTK	flatexDEGIRO SE	Investment	DE	Fina	https://www.marketscreener.com/quote/stock/FLATEXDEGIRO-AG-31637144/	https://finance.yahoo.com/quote/FTK.DE/	https://www.flatexdegiro.com/	DeGiro-børsmægler. Er i 18 EU-lande	\N	\N	0.7500	2026	\N	EUR	\N	\N	\N	Investment	\N	.DE	LON	^GDAXI	FTK.DE
FTNT	FTNT	Fortinet	Cybersecurity	US	Tech	https://www.marketscreener.com/quote/stock/FORTINET-INC-60103137/	https://finance.yahoo.com/quote/FTNT?p=FTNT&.tsrc=fin-srch	https://www.fortinet.com	\N	t	\N	0.4200	2026	\N	USD	\N	\N	\N	Cybersecurity	\N	.US	NY	^GSPC	FTNT
FTS.TO	TSE:FTS	Fortis	Util_MixedFuel	CAN	Util	https://www.marketscreener.com/quote/stock/FORTIS-INC-1410069/	https://finance.yahoo.com/quote/FTS.TO?p=FTS.TO&.tsrc=fin-srch	https://www.fortisinc.com	Diversified regulated electric and gas utility	\N	\N	\N	\N	\N	CAD	\N	\N	\N	Util_MixedFuel	\N	.TO	NY	^GSPC	FTS.TO
FUBO	FUBO	fuboTV Inc.	TechToCons	US	Tech	https://www.marketscreener.com/quote/stock/FUBOTV-INC-113838408/	https://finance.yahoo.com/quote/FUBO/	http://www.fubo.tv/	TV-streaming, sport	\N	\N	0.3300	2026	\N	USD	\N	\N	\N	TechToCons	\N	.US	NY	^GSPC	FUBO
FUTU	FUTU	Futu Holdings 	Services(Fina)	China	Fina	https://www.marketscreener.com/quote/stock/FUTU-HOLDINGS-LIMITED-55590548/	https://finance.yahoo.com/quote/FUTU/profile	https://www.futuholdings.com	Stock broker, Wealth manager, bus. services like IPO, Investor relations,  employee stock plans. Clearing house in US.	\N	\N	0.3800	2026	\N	USD	\N	\N	\N	Services(Fina)	\N	.US	NY	^GSPC	FUTU
FVRR	FVRR	Fiverr Intl	TechToProfs	Israel	Tech	https://www.marketscreener.com/quote/stock/FIVERR-INTERNATIONAL-LTD-59637843/	https://finance.yahoo.com/quote/FVRR/	http://www.fiverr.com/	Israel-based global marketplace that connects freelancers and businesses for digital services (gigs)	\N	\N	0.4000	2026	\N	USD	\N	\N	\N	TechToProfs	\N	.US	NY	^GSPC	FVRR
FXC.L	LON:FXC	iShares China Large Cap UCITS ETF	Country	China	na	https://www.blackrock.com/dk/formidler/produkter/251798/	\N	\N	50 aktier. USD: IDFX (lidet omsat). US-udg: FXI.	\N	\N	0.5900	2026	\N	GBX	\N	\N	\N	Country	\N	.L	LON	^FTSE	FXC.L
G.MI	BIT:G	Assicurazioni Generali	Insurance	IT	Fina	https://www.marketscreener.com/quote/stock/GENERALI-68929/	https://finance.yahoo.com/quote/G.MI	https://www.generali.com	non-life insurance of any kind	t	\N	0.4000	2026	\N	USD	\N	\N	\N	Insurance	\N	.MI	LON	^STOXX	G.MI
GAIN	GAIN	Gladstone (BDC)	BDC	US	Fina	https://www.marketscreener.com/quote/stock/GLADSTONE-INVESTMENT-CORP-9396/	\N	https://www.gladstoneinvestment.com	\N	\N	\N	\N	\N	\N	USD	\N	\N	\N	BDC	\N	.US	NY	^GSPC	GAIN
GAP	GAP	GAP	Clothing	US	C-Di	https://www.marketscreener.com/quote/stock/THE-GAP-INC-12816/	https://finance.yahoo.com/quote/GAP/	https://www.gapinc.com	\N	\N	\N	0.6500	2026	\N	USD	\N	\N	\N	Clothing	\N	.US	NY	^GSPC	GAP
GAU.TO	TSE:GAU	Galiano Gold	Gold	CAN	Basi	https://www.marketscreener.com/quote/stock/GALIANO-GOLD-INC-1410572/	https://finance.yahoo.com/quote/GAU.TO/	http://www.galianogold.com/	Succesfuld multi-mine komplex i Ghana. 24 ansatte!	\N	\N	0.4500	2026	\N	CAD	\N	\N	\N	Gold	\N	.TO	NY	^GSPC	GAU.TO
GBDC	GBDC	Golub Capital BDC	BDC	US	Fina	https://www.marketscreener.com/quote/stock/GOLUB-CAPITAL-BDC-INC-6133321/	https://finance.yahoo.com/quote/GBDC	https://www.golubcapitalbdc.com	Mest secured loans. External mngt.	t	\N	\N	\N	\N	USD	\N	\N	\N	BDC	\N	.US	NY	^GSPC	GBDC
GBTC	GBTC	Grayscale Bitcoin Trust	Crypto	US	Fina	https://www.marketscreener.com/quote/stock/GRAYSCALE-BITCOIN-TRUST--52035226/?type_recherche=rapide&mots=gbtc	https://finance.yahoo.com/quote/GBTC?p=GBTC&.tsrc=fin-srch	https://www.grayscale.com/company/about-grayscale	Invest i Bitcoin uden at eje dem	\N	\N	0.8000	2026	\N	USD	\N	\N	\N	Crypto	\N	.US	NY	^BTC	GBTC
GCT	GCT	GigaCloud Technology	TechToProfs	China	Tech	https://www.marketscreener.com/quote/stock/GIGACLOUD-TECHNOLOGY-INC-142602776/	https://www.tradingview.com/chart/Id1KO0M6/	https://www.gigacloudtech.com	B2B e-commerce for large parcel merchandise (furniture, appliaces, fitness equipment etc). IPO 2021.	\N	\N	0.5500	2026	\N	USD	\N	\N	\N	TechToProfs	\N	.US	NY	^GSPC	GCT
GD	GD	General Dynamics	Defense	US	Indu	https://www.marketscreener.com/quote/stock/GENERAL-DYNAMICS-CORPORAT-12723/	https://finance.yahoo.com/quote/GD?p=GD&.tsrc=fin-srch	https://www.gd.com	Defence	\N	\N	0.7200	2026	\N	USD	\N	\N	\N	Defense	\N	.US	NY	^GSPC	GD
GDX.L	LON:GDX	VanEcks Vectors Goldminers UCITS ETF	Gold	Intl	Basi	https://finance.yahoo.com/quote/GDX.L?p=GDX.L&.tsrc=fin-srch	https://finance.yahoo.com/quote/GDX.L?p=GDX.L&.tsrc=fin-srch	\N	Følger Gold Miner's Index	\N	\N	0.4000	2026	\N	GBX	\N	\N	\N	Gold	\N	.L	LON	^FTSE	GDX.L
GE	GE	General Electric	Manuf_Big	US	Indu	https://www.marketscreener.com/quote/stock/GENERAL-ELECTRIC-COMPANY-4823/	https://finance.yahoo.com/quote/GE?p=GE&.tsrc=fin-srch	https://www.geaerospace.com	2023: Power, green energy and aviation (efter GEHC spin-off). Energy vil i 2024 blive skilt ud som GE Vernova.	t	\N	0.3000	2026	\N	USD	\N	\N	\N	Manuf_Big	\N	.US	NY	^GSPC	GE
GEHC	GEHC	GE Healthcare Technologies	Healthcare	US	Heal	https://www.marketscreener.com/quote/stock/GE-HEALTHCARE-TECHNOLOGIE-148175835/	https://finance.yahoo.com/quote/GEHC?p=GEHC&.tsrc=fin-srch	https://www.gehealthcare.com	Medicinsk og diagnostisk teknologi samt løsninger	\N	\N	0.7000	2026	\N	USD	\N	\N	\N	Healthcare	\N	.US	NY	^GSPC	GEHC
GELYF	GELYF	Geely Automobile Holdings	Automotive	China	C-Di	https://www.marketscreener.com/quote/stock/GEELY-AUTOMOBILE-HOLDINGS-120789027/	https://finance.yahoo.com/quote/GELYF/	https://www.geelyauto.com.hk	0175.HK	\N	\N	0.4700	2026	\N	USD	\N	\N	\N	Automotive	\N	.US	NY	^GSPC	GELYF
QRVO	QRVO	Qorvo	Semi	US	Tech	https://www.marketscreener.com/quote/stock/QORVO-INC-19476284/	\N	https://www.qorvo.com	Radio-frequency components. Indgår i iPhones	\N	\N	0.6000	2026	\N	USD	\N	\N	\N	Semi	\N	.US	NY	^GSPC	QRVO
GEN	GEN	Gen Digital (tidl. NortonLifeLock, Symantec, Avast)	Cybersecurity	US	Tech	https://www.marketscreener.com/quote/stock/GEN-DIGITAL-INC-4907/	\N	https://gendigital.com	Trusted consumer brands: Norton, Avast, LifeLock, Avira, AVG, Reputation Defender and CCleaner	\N	\N	0.7500	2026	\N	USD	\N	\N	\N	Cybersecurity	\N	.US	NY	^GSPC	GEN
GETI-B.ST	STO:GETI-B	Getinge	Electronics_Medical	SE	Indu	https://www.marketscreener.com/quote/stock/GETINGE-AB-6491355/	https://finance.yahoo.com/quote/GETI-B.ST?p=GETI-B.ST&.tsrc=fin-srch	https://www.getinge.com	\N	\N	\N	0.5000	2026	\N	SEK	\N	\N	\N	Other[Indu]	7	.ST	LON	^OMX	GETI-B.ST
GEV	GEV	GE Vernova	Rnwb(Indu)	US	Indu	https://www.marketscreener.com/quote/stock/GE-VERNOVA-LLC-167654523/	https://finance.yahoo.com/quote/GEV	https://www.gevernova.com	GE's energimaskiner: gas, nuclear, hydro, and steam technologies. IPO 2.4.24. I 2025 fokus på grid modernization, renewable generation and decarbonization technologies	\N	\N	0.6500	2026	\N	USD	\N	\N	\N	Rnwb(Indu)	\N	.US	NY	^GSPC	GEV
GEVO	GEVO	Gevo (Biobrændstof)	Rnwb(Ener)	US	Ener	https://www.marketscreener.com/quote/stock/GEVO-INC-44136865/	https://finance.yahoo.com/quote/GEVO?p=GEVO&.tsrc=fin-srch	https://www.gevo.com	\N	\N	\N	0.6100	2026	\N	USD	\N	\N	\N	Rnwb(Ener)	\N	.US	NY	^GSPC	GEVO
GFI	GFI	Gold Fields	Gold	Sydafrika	Basi	https://www.marketscreener.com/quote/stock/GOLD-FIELDS-LIMITED-12742/	https://finance.yahoo.com/quote/GFI?p=GFI&.tsrc=fin-srch	https://www.goldfields.com	Gold mines in Australia, Ghana, Peru, and South Africa	t	\N	0.3900	2026	\N	USD	\N	\N	\N	Gold	\N	.US	NY	^GSPC	GFI
GFS	GFS	GlobalFoundries	Semi	US	Tech	https://www.marketscreener.com/quote/stock/GLOBALFOUNDRIES-INC-128691269/	https://finance.yahoo.com/quote/GFS?p=GFS&.tsrc=fin-srch	https://gf.com	Manuf as service	\N	\N	0.6500	2026	\N	USD	\N	\N	\N	Semi	\N	.US	NY	^GSPC	GFS
GILD	GILD	Gilead Science	Pharma	US	Heal	https://www.marketscreener.com/quote/stock/GILEAD-SCIENCES-INC-4876/	https://finance.yahoo.com/quote/GILD?p=GILD&.tsrc=fin-srch	https://www.gilead.com	HIV, COVID mm. drug sales	\N	\N	\N	\N	\N	USD	\N	\N	\N	Pharma	\N	.US	NY	^GSPC	GILD
GL	GL	Globe Life	Insurance	US	Fina	https://www.marketscreener.com/quote/stock/GLOBE-LIFE-INC-63860366/	https://finance.yahoo.com/quote/GL?p=GL&.tsrc=fin-srch	https://www.globelifeinsurance.com	Livs- og sundhedsforsikring	\N	\N	0.5000	2026	\N	USD	\N	\N	\N	Insurance	\N	.US	NY	^GSPC	GL
GLB.L	LON:GLB	Glanbia	Food	Irland	C-St	https://www.marketscreener.com/quote/stock/GLANBIA-PLC-9676701/	https://finance.yahoo.com/quote/GLB.L/	https://www.glanbia.com	Ernæringsprodukter ud fra mælk	\N	\N	0.4500	2026	\N	EUR	\N	\N	\N	Food	\N	.L	LON	^FTSE	GLB.L
GLBE	GLBE	Global-E Online 	TechToCons	Israel	Tech	https://www.marketscreener.com/quote/stock/GLOBAL-E-ONLINE-LTD-122525446/	https://finance.yahoo.com/quote/GLBE/	https://www.global-e.com/	E-handelsplatform	\N	\N	0.4000	2026	\N	USD	\N	\N	\N	TechToCons	\N	.US	NY	^GSPC	GLBE
GLD	GLD	SPDR Gold Shares Trust	Gold	US	Basi	http://www.marketscreener.com/SPDR-GOLD-SHARES-TRUST-29425888/	https://finance.yahoo.com/quote/GLD/	\N	Investerer i guld-barrer	\N	\N	0.6500	2026	\N	USD	\N	\N	\N	Gold	\N	.US	NY	^GSPC	GLD
GLE.PA	EPA:GLE	Société Générale SA	Bank	FR	Fina	https://www.marketscreener.com/quote/stock/SOCIETE-GENERALE-4702/	https://finance.yahoo.com/quote/GLE.PA?p=GLE.PA&.tsrc=fin-srch	https://www.societegenerale.com	\N	t	\N	\N	\N	\N	EUR	\N	\N	\N	Bank	\N	.PA	LON	^FCHI	GLE.PA
GLEN.L	LON:GLEN	Glencore Plc	Mining	CH	Basi	https://www.marketscreener.com/quote/stock/GLENCORE-PLC-8017494/	https://finance.yahoo.com/quote/GLEN.L?p=GLEN.L&.tsrc=fin-srch	https://www.glencore.com	\N	\N	\N	0.4700	2026	\N	GBX	\N	\N	\N	Mining	\N	.L	LON	^FTSE	GLEN.L
GLNG	GLNG	Golar LNG 	Oil&Gas	US	Ener	https://www.marketscreener.com/quote/stock/GOLAR-LNG-LIMITED-9446/	https://finance.yahoo.com/quote/GLNG?p=GLNG&.tsrc=fin-srch	https://www.golarlng.com	Midstream, herunder shipping	\N	\N	0.5000	2026	\N	USD	\N	\N	\N	Oil&Gas	\N	.US	NY	^GSPC	GLNG
GLW	GLW	Corning Incorporated	ElectrComponents	US	Tech	https://www.marketscreener.com/quote/stock/CORNING-INCORPORATED-12788/	https://finance.yahoo.com/quote/GLW/	https://www.corning.com/	Også Gorilla-glass til iPhones	\N	\N	0.3500	2026	\N	USD	\N	\N	\N	ElectrComponents	\N	.US	NY	^GSPC	GLW
GLXY.TO	TSE:GLXY	Galaxy Digital Holdings 	Crypto	CAN	Fina	https://www.marketscreener.com/quote/stock/GALAXY-DIGITAL-HOLDINGS-L-49479424/	https://finance.yahoo.com/quote/GLXY.TO/	https://www.galaxy.com/	Teknologi, tjenester ifm. krypto	\N	\N	0.6100	2026	\N	CAD	\N	\N	\N	Crypto	\N	.TO	NY	^BTC	GLXY.TO
GM	GM	General Motors	Automotive	US	C-Di	https://www.marketscreener.com/quote/stock/GENERAL-MOTORS-COMPANY-6873535/	\N	https://www.gm.com	\N	\N	\N	0.2700	2026	\N	USD	\N	\N	\N	Automotive	\N	.US	NY	^GSPC	GM
GMAB.CO	CPH:GMAB	Genmab	Pharma	DK	Heal	https://www.marketscreener.com/quote/stock/GENMAB-A-S-63733191/	https://finance.yahoo.com/quote/GMAB?p=GMAB&.tsrc=fin-srch	https://www.genmab.com	Udv. antistof-baserede lægemidler	t	\N	0.5300	2026	\N	DKK	\N	\N	\N	Pharma	\N	.CO	LON	^OMXC20	GMAB.CO
GNC.AX	ASX:GNC	Graincorp 	Food	AUS	C-St	https://www.marketscreener.com/quote/stock/GRAINCORP-LIMITED-6492522/	https://finance.yahoo.com/quote/GNC.AX?p=GNC.AX&.tsrc=fin-srch	https://www.graincorp.com.au/	Food ingredients	\N	\N	0.8000	2026	\N	AUD	\N	\N	\N	Food	\N	.AX	HKG	^HSI	GNC.AX
GNK	GNK	Genco Shipping & Trading	Trpt_Ship	US	Indu	https://www.marketscreener.com/quote/stock/GENCO-SHIPPING-TRADING-LI-29159922/	https://finance.yahoo.com/quote/GNK?p=GNK&.tsrc=fin-srch	https://www.gencoshipping.com	Drybulk transport. Internally managed and not partnership.	\N	\N	0.2500	2026	\N	USD	\N	\N	\N	Trpt_Ship	\N	.US	NY	^GSPC	GNK
GNL	GNL	Global Net Lease	Property	US	REIT	https://www.marketscreener.com/quote/stock/GLOBAL-NET-LEASE-INC-34241924/	\N	https://www.globalnetlease.com	\N	\N	\N	0.3700	2026	\N	USD	\N	\N	\N	Property	\N	.US	NY	^GSPC	GNL
GNRC	GNRC	Generac	Rnwb(Indu)	US	Indu	https://www.marketscreener.com/quote/stock/GENERAC-HOLDINGS-INC-5948156/	https://finance.yahoo.com/quote/GNRC?p=GNRC&.tsrc=fin-srch	https://www.generac.com	Producerer backup-generatorer	t	\N	0.4700	2026	\N	USD	\N	\N	\N	Rnwb(Indu)	\N	.US	NY	^GSPC	GNRC
GOOGL	GOOGL	Alphabet	TechToCons	US	Tech	https://www.marketscreener.com/quote/stock/ALPHABET-INC-24203373/	\N	https://www.abc.xyz	\N	t	\N	0.2700	2026	\N	USD	\N	Magni7	\N	TechToCons	\N	.US	NY	^GSPC	GOOGL
GOOS.TO	TSE:GOOS	Canada Goose	Clothing	CAN	C-Di	https://www.marketscreener.com/quote/stock/CANADA-GOOSE-HOLDINGS-INC-34325405/	\N	https://www.canadagoose.com	Performance luksus-tøj	\N	\N	0.4500	2026	\N	CAD	\N	\N	\N	Clothing	\N	.TO	NY	^GSPC	GOOS.TO
GPC	GPC	Genuine Parts Company	Automotive	US	C-Di	https://www.marketscreener.com/quote/stock/GENUINE-PARTS-COMPANY-40311101/	https://finance.yahoo.com/quote/GPC?p=GPC&.tsrc=fin-srch	https://www.genpt.com	Reservedele til biler	t	\N	0.5000	2026	\N	USD	\N	\N	\N	Automotive	\N	.US	NY	^GSPC	GPC
GPCR	GPCR	Structure Therapeutics (ADR)	Pharma	China	Heal	https://www.marketscreener.com/quote/stock/STRUCTURE-THERAPEUTICS-IN-150152100/	https://finance.yahoo.com/quote/GPCR?p=GPCR&.tsrc=fin-srch	https://www.structuretx.com	Lille-molekyle-anologer til biologics og kun orale. Kontorer i US og Kina. Lead candidate er diabetes-2-lægmiddel a la semaglutid. Forskningsleder (kineser) har fortid i Novo.	\N	\N	0.2000	2026	\N	USD	\N	\N	\N	Pharma	\N	.US	NY	^GSPC	GPCR
GPMT	GPMT	Granite Point Mortgage (comm mrgt)	Mortgages	US	REIT	https://www.marketscreener.com/quote/stock/GRANITE-POINT-MORTGAGE-TR-35897722/	\N	https://www.gpmtreit.com	\N	\N	\N	0.4500	2026	\N	USD	\N	\N	\N	Mortgages	\N	.US	NY	^GSPC	GPMT
GPN	GPN	Global Payments	TechToProfs	US	Tech	https://www.marketscreener.com/quote/stock/GLOBAL-PAYMENTS-INC-12814/	https://finance.yahoo.com/quote/GPN/	https://www.globalpayments.com	Betaling globalt, især til mindre virks. I US også til "under-banked" (fattige)	\N	\N	0.5800	2026	\N	USD	\N	\N	\N	TechToProfs	\N	.US	NY	^GSPC	GPN
GRAB	GRAB	Grab	TechToCons	Singapore	Tech	https://www.marketscreener.com/quote/stock/GRAB-HOLDINGS-LIMITED-130201011/	https://finance.yahoo.com/quote/GRAB?p=GRAB&.tsrc=fin-srch	https://www.grab.com	UBER-like og budtjeneste i Sydøstasien	\N	\N	0.5000	2026	\N	USD	\N	\N	\N	TechToCons	\N	.US	NY	^GSPC	GRAB
GRBK	GRBK	Green Brick Partners	ConstrHomes	US	C-Di	https://www.marketscreener.com/quote/stock/GREEN-BRICK-PARTNERS-INC-18397156/	https://finance.yahoo.com/quote/GRBK?p=GRBK&.tsrc=fin-srch	https://www.greenbrickpartners.com	Husbygger Texas, Georgia, Florida. Partner 2022 med AGNC.	t	\N	0.3300	2026	\N	USD	\N	\N	\N	ConstrHomes	\N	.US	NY	^GSPC	GRBK
GRF.MC	BME:GRF	Grifols	Healthcare	ES	Heal	https://www.marketscreener.com/quote/stock/GRIFOLS-S-A-25530828/	https://finance.yahoo.com/quote/GRF.MC?p=GRF.MC&.tsrc=fin-srch	https://www.grifols.com	Therapeutic products and medical devices	\N	\N	0.3500	2026	\N	EUR	\N	\N	\N	Healthcare	\N	.MC	LON	^STOXX	GRF.MC
GRMN	GRMN	Garmin	TechToCons	US	Tech	https://www.marketscreener.com/quote/stock/GARMIN-LTD-4933/	https://finance.yahoo.com/quote/GRMN?p=GRMN&.tsrc=fin-srch	https://www.garmin.com	Wireless devices, GPS, Fitness, Cycling	\N	\N	0.5500	2026	\N	USD	\N	\N	\N	TechToCons	\N	.US	NY	^GSPC	GRMN
GS	GS	Goldman-Sachs	Bank	US	Fina	https://www.marketscreener.com/quote/stock/THE-GOLDMAN-SACHS-GROUP-12831/	https://finance.yahoo.com/quote/GS?p=GS&.tsrc=fin-srch	https://www.goldmansachs.com	Financial services: Investment, asset mngt	\N	\N	0.6300	2026	\N	USD	\N	\N	\N	Bank	\N	.US	NY	^GSPC	GS
GSBD	GSBD	Goldman Sachs BDC	BDC	US	Fina	https://www.marketscreener.com/quote/stock/GOLDMAN-SACHS-BDC-INC-21269364/	https://finance.yahoo.com/quote/GSBD?p=GSBD&.tsrc=fin-srch	https://www.goldmansachsbdc.com	Højt udbytte a la ARCC	\N	\N	0.5900	2026	\N	USD	\N	\N	\N	BDC	\N	.US	NY	^GSPC	GSBD
GSF.OL	OSL:GSF	Grieg Seafood	Food	NO	C-St	https://www.marketscreener.com/quote/stock/GRIEG-SEAFOOD-ASA-1413163/	https://finance.yahoo.com/quote/GSF.OL?p=GSF.OL	https://www.griegseafood.no	Laks	\N	\N	0.3300	2026	\N	NOK	\N	\N	\N	Food	\N	.OL	LON	^OSEBX	GSF.OL
GSK.L	LON:GSK	GlaxoSmithKline	Pharma	UK	Heal	https://www.marketscreener.com/quote/stock/GSK-PLC-9590199/	\N	https://www.gsk.com	\N	t	\N	0.6500	2026	\N	GBX	\N	GRANOLA	\N	Pharma	\N	.L	LON	^FTSE	GSK.L
GSL	GSL	Global Ship Lease	Trpt_Ship	US	Indu	https://www.marketscreener.com/quote/stock/GLOBAL-SHIP-LEASE-INC-56294592/	https://finance.yahoo.com/quote/GSL?p=GSL&.tsrc=fin-srch	https://www.globalshiplease.com	Containerships for charter	\N	\N	0.4000	2026	\N	USD	\N	\N	\N	Trpt_Ship	\N	.US	NY	^GSPC	GSL
GSL-PB	GSL-B	Global Ship Lease, 8.75% Cum Redeemable Perpetual Prefs Ser B	Trpt_Ship	UK	Indu	https://www.marketscreener.com/quote/stock/GLOBAL-SHIP-LEASE-INC-17567345/	https://finance.yahoo.com/quote/GSL-PB?p=GSL-PB&.tsrc=fin-srch	https://www.globalshiplease.com	Callable på ethvert tidspunkt	\N	\N	0.4000	2026	\N	USD	\N	\N	\N	Trpt_Ship	\N	.US	NY	^GSPC	GSL-PB
GTLS	GTLS	Chart Industries	Manuf_Special	US	Indu	https://www.marketscreener.com/quote/stock/CHART-INDUSTRIES-INC-30727/	https://finance.yahoo.com/quote/GTLS?p=GTLS&.tsrc=fin-srch	https://www.chartindustries.com	LNG, CO2 fangst, Kryogenisk lagring, Varmevekslere	\N	\N	0.4400	2026	\N	USD	\N	\N	\N	Manuf_Special	\N	.US	NY	^GSPC	GTLS
GTY	GTY	Getty Realty Corp	Property	US	REIT	https://www.marketscreener.com/quote/stock/GETTY-REALTY-CORP-12847/	https://finance.yahoo.com/quote/GTY/	http://www.gettyrealty.com/	Convenience properties, automobile retail, and car wash.  1174 props in total. 	\N	\N	0.7000	2026	\N	NOK	\N	\N	\N	Property	\N	.US	NY	^GSPC	GTY
HAFNI.OL	OSL:HAFNI	Hafnia	Trpt_Ship (Ener)	NO	Ener	https://www.marketscreener.com/quote/stock/HAFNIA-LIMITED-76066789/	https://finance.yahoo.com/quote/HAFNI.OL?p=HAFNI.OL&.tsrc=fin-srch	https://www.hafniabw.com	Ships: Clean tankers, dvs. til raffinerede produkter	\N	\N	0.5000	2026	\N	NOK	\N	\N	\N	Trpt_Ship (Ener)	\N	.OL	LON	^OSEBX	HAFNI.OL
HAG.DE	ETR:HAG	Hensoldt	Defense	DE	Indu	https://www.marketscreener.com/quote/stock/HENSOLDT-AG-112902521/	https://finance.yahoo.com/quote/HAG.DE?p=HAG.DE&.tsrc=fin-srch	https://www.hensoldt.net	Optisk-elektroniske produkter til militære formål	t	\N	0.6700	2026	\N	EUR	\N	\N	\N	Defense	\N	.DE	LON	^GDAXI	HAG.DE
HAL	HAL	Halliburton	Oil&Gas	US	Ener	https://www.marketscreener.com/quote/stock/HALLIBURTON-COMPANY-12871/	https://finance.yahoo.com/quote/HAL/	https://www.halliburton.com/	Produkter og tjenester til energiindustri (10,1 mia/43% i USA, 2023)	\N	\N	0.5300	2026	\N	USD	\N	\N	\N	Oil&Gas	\N	.US	NY	^GSPC	HAL
HALO	HALO	Halozyme Therapeutics	Pharma	US	Heal	https://www.marketscreener.com/quote/stock/HALOZYME-THERAPEUTICS-INC-50245/	https://finance.yahoo.com/quote/HALO/	https://www.halozyme.com	140 ansatte. Lægemidler baseret på hyaluronidase (hyaluronsyre(HA)-nedbrydende) HA i tumorer. Også brug af hysluronidase til drug delivery; licenser til mange af de store pharmafirmaer	\N	\N	0.4700	2026	\N	USD	\N	\N	\N	Pharma	\N	.US	NY	^GSPC	HALO
HAS	HAS	Hasbro	Holiday	US	C-Di	https://www.marketscreener.com/quote/stock/HASBRO-INC-12874/	https://finance.yahoo.com/quote/HAS?p=HAS&.tsrc=fin-srch	https://shop.hasbro.com/en-us	Legetøj	\N	\N	0.5000	2026	\N	USD	\N	\N	\N	Holiday	\N	.US	NY	^GSPC	HAS
HASI	HASI	Hannon Armstrong Sustainable Infrastructure Capital	Property	US	REIT	https://www.marketscreener.com/quote/stock/HANNON-ARMSTRONG-SUSTAINA-13006790/	https://finance.yahoo.com/quote/HASI?p=HASI&.tsrc=fin-srch	https://www.hasi.com	Sustainable energy	\N	\N	0.4000	2026	\N	USD	\N	\N	\N	Property	\N	.US	NY	^GSPC	HASI
HAUTO.OL	OSL:HAUTO	Hoegh Autoliners	Trpt_Ship	NO	Indu	https://www.marketscreener.com/quote/stock/HOEGH-AUTOLINERS-ASA-129888455/	https://finance.yahoo.com/quote/HAUTO.OL?p=HAUTO.OL&.tsrc=fin-srch	https://www.hoeghautoliners.com	Transport af biler	t	\N	\N	\N	\N	NOK	\N	\N	\N	Trpt_Ship	\N	.OL	LON	^OSEBX	HAUTO.OL
HCA	HCA	HCA Holdings (Hospital Corp  America)	Property	US	REIT	https://www.marketscreener.com/quote/stock/HCA-HEALTHCARE-INC-7534808/	\N	https://www.hcahealthcare.com	Health care facilities	\N	\N	\N	\N	\N	USD	\N	\N	\N	Property	\N	.US	NY	^GSPC	HCA
HCC	HCC	Warrior Met Coal	Mining	US	Basi	https://www.marketscreener.com/quote/stock/WARRIOR-MET-COAL-INC-34571734/	https://finance.yahoo.com/quote/HCC?p=HCC	https://www.warriormetcoal.com	Metallurgisk kul - den mindre	\N	\N	0.5000	2026	\N	USD	\N	\N	\N	Mining	\N	.US	NY	^GSPC	HCC
HCSG	HCSG	Healthcare Services Group	Healthcare	US	Heal	https://www.marketscreener.com/quote/stock/HEALTHCARE-SERVICES-GROUP-9526/	\N	https://www.hcsgcorp.com	Mngt and operations like housekeeping, facility mngt and dietary service to healthcare facilities	\N	\N	\N	\N	\N	USD	\N	\N	\N	Healthcare	\N	.US	NY	^GSPC	HCSG
HD	HD	Home Depot	ConstrHomes	US	C-Di	https://www.marketscreener.com/quote/stock/THE-HOME-DEPOT-INC-4826/	https://finance.yahoo.com/quote/HD?p=HD&.tsrc=fin-srch	https://www.homedepot.com	Homebuilding	\N	\N	0.3200	2026	\N	USD	\N	\N	\N	ConstrHomes	\N	.US	NY	^GSPC	HD
HDB	HDB	HDFC	Bank	India	Fina	https://www.marketscreener.com/quote/stock/HDFC-BANK-LIMITED-12893/	\N	https://www.hdfcbank.com	\N	t	\N	0.5900	2026	\N	USD	\N	\N	\N	Bank	\N	.US	NY	^GSPC	HDB
QS	QS	QuantumScape	Batteries	US	Indu	https://www.marketscreener.com/quote/stock/QUANTUMSCAPE-CORPORATION-110986220/	\N	https://www.quantumscape.com	Udvikling af solid-state-batterier	\N	\N	\N	\N	\N	USD	\N	\N	\N	Other[Indu]	7	.US	NY	^GSPC	QS
HEAL.L	LON:HEAL	iShares Healthcare Innovation UCITS ETF (USD)	Healthcare	US	Heal	https://www.ishares.com/uk/individual/en/products/284217/ishares-digitalisation-ucits-etf-usd-acc-fund	https://finance.yahoo.com/quote/HEAL.L?p=HEAL.L&.tsrc=fin-srch	\N	\N	\N	\N	0.4000	2026	\N	USD	\N	\N	\N	Healthcare	\N	.L	LON	^FTSE	HEAL.L
HEI.DE	ETR:HEI	HeidelbergCement	ConstrMaterials	DE	Basi	https://www.marketscreener.com/quote/stock/HEIDELBERGCEMENT-AG-436181/	https://finance.yahoo.com/quote/HEI.DE?p=HEI.DE&.tsrc=fin-srch	https://www.heidelbergcement.com	\N	\N	\N	0.4700	2026	\N	EUR	\N	\N	\N	ConstrMaterials	\N	.DE	LON	^GDAXI	HEI.DE
HEIO.AS	AMS:HEIO	Heineken Holding	Food	NL	C-St	https://www.marketscreener.com/quote/stock/HEINEKEN-HOLDING-N-V-6407/	https://finance.yahoo.com/quote/HEIO.AS/	https://www.heinekenholding.com/	Eneste aktivitet er Heineken-bryggeriet	\N	\N	\N	\N	\N	EUR	\N	\N	\N	Food	\N	.AS	LON	^AEX	HEIO.AS
HEXA-B.ST	STO:HEXA-B	Hexagon	Electronics	SE	Indu	https://www.marketscreener.com/quote/stock/HEXAGON-AB-6491358/	https://finance.yahoo.com/quote/HEXA-B.ST?p=HEXA-B.ST&.tsrc=fin-srch	https://www.hexagon.se	\N	\N	\N	0.4400	2026	\N	SEK	\N	\N	\N	Electronics	\N	.ST	LON	^OMX	HEXA-B.ST
HHPD.L	LON:HHPD	Foxconn / Hon Hai Precision Industries	ElectrComponents	Taiwan	Tech	https://www.marketscreener.com/quote/stock/HON-HAI-PRECISION-INDUSTR-47041151/	https://finance.yahoo.com/quote/HHPDL.XC/	https://www.honhai.com.tw	iPhone-montage og meget andet	t	\N	0.4000	2026	\N	USD	\N	\N	\N	ElectrComponents	\N	.L	LON	^FTSE	HHPD.L
HII	HII	Huntington Ingalls Industries	Defense	US	Indu	https://www.marketscreener.com/quote/stock/HUNTINGTON-INGALLS-INDUST-7642101/	https://finance.yahoo.com/quote/HII/	https://www.hii.com	Defence, specielt flådefartøjer	\N	\N	0.4000	2026	\N	USD	\N	\N	\N	Defense	\N	.US	NY	^GSPC	HII
HIMS	HIMS	Hims & Hers Health	Healthcare	US	Heal	https://www.marketscreener.com/quote/stock/HIMS-HERS-HEALTH-INC-65220697/	https://finance.yahoo.com/quote/HIMS/	https://www.hims.com/	Telehealth consultation og pharmacy. F.eks. til fattige områder uden disse services. Driller de store farma-firmaer (som Novo) med "hjemmelavede" kopier af de mærkevarer (unapproved "compunded" drugs)	\N	\N	0.5300	2026	\N	USD	\N	\N	\N	Healthcare	\N	.US	NY	^GSPC	HIMS
HIVE	HIVE	HIVE Digital Technologies	Crypto	US	Fina	https://www.marketscreener.com/quote/stock/HIVE-DIGITAL-TECHNOLOGIES-120794608/	https://finance.yahoo.com/quote/HIVE/	http://www.hivedigitaltechnologies.com/	Producerer 10 bitcoins/dag (27.10.25) og regner med at nå op på 25 pr dag. Styrer (grønne) datacentre i CAN; SE og Island. 24 ansatte. Oms. TTM okt-2025: 128 mio USD, res 50 mio USD. NB: Res mest pga salg af udstyr.	\N	\N	0.4100	2026	\N	USD	\N	\N	\N	Crypto	\N	.US	NY	^BTC	HIVE
HL	HL	Hecla Mining	Mining	US	Basi	https://www.marketscreener.com/quote/stock/HECLA-MINING-COMPANY-12936/	https://finance.yahoo.com/quote/HL/	https://www.hecla.com/	Mines in US, Canada, Japan, Korea, and China for silver, gold, lead, zinc,  and carbon material containing silver and gold	\N	\N	0.4500	2026	\N	USD	\N	\N	\N	Mining	\N	.US	NY	^GSPC	HL
HLAG.DE	ETR:HLAG	Hapag-Lloyd	Trpt_Ship	DE	Indu	https://www.marketscreener.com/quote/stock/HAPAG-LLOYD-AG-24857717/	https://finance.yahoo.com/quote/HLAG.DE?p=HLAG.DE&.tsrc=fin-srch	https://www.hapag-lloyd.com	Liner services between all continents. Større end Mærsk (i market cap)	t	\N	0.5000	2026	\N	EUR	\N	\N	t	Trpt_Ship	\N	.DE	LON	^GDAXI	HLAG.DE
HLN.L	LON:HLN	Haleon	Pharma	UK	Heal	https://www.marketscreener.com/quote/stock/HALEON-PLC-139248469/	https://finance.yahoo.com/quote/HLN.L?p=HLN.L&.tsrc=fin-srch	https://www.haleon.com	Divested 18.7.22 fra GSK.L	t	\N	0.1100	2026	\N	GBX	\N	\N	\N	Pharma	\N	.L	LON	^FTSE	HLN.L
HLT	HLT	Hilton	Holiday	US	C-Di	https://www.marketscreener.com/quote/stock/HILTON-WORLDWIDE-HOLDINGS-40311470/	https://finance.yahoo.com/quote/HLT/profile?p=HLT	https://www.hilton.com	Hotel	\N	\N	0.3000	2026	\N	USD	\N	\N	\N	Holiday	\N	.US	NY	^GSPC	HLT
HLX	HLX	Helix Energy Solutions	Rnwb(Ener)	US	Ener	https://www.marketscreener.com/quote/stock/HELIX-ENERGY-SOLUTIONS-GR-30200/	https://finance.yahoo.com/quote/HLX?p=HLX&.tsrc=fin-srch	https://www.helixesg.com	Offshore energy services, både vedr sort og grøn energi	\N	\N	0.4500	2026	\N	USD	\N	\N	\N	Rnwb(Ener)	\N	.US	NY	^GSPC	HLX
HM-B.ST	CPH:HM-B	Hennes & Mauritz	Clothing	SE	C-Di	https://www.marketscreener.com/quote/stock/HENNES-MAURITZ-AB-6491104/	https://finance.yahoo.com/quote/HM-B.ST?p=HM-B.ST	https://www.hmgroup.com	\N	t	\N	0.6700	2026	\N	SEK	\N	\N	\N	Clothing	\N	.ST	LON	^OMX	HM-B.ST
HO.PA	EPA:HO	Thales	Defense	FR	Indu	https://www.marketscreener.com/quote/stock/THALES-4715/	https://finance.yahoo.com/quote/HO.PA/financials?p=HO.PA	https://www.thalesgroup.com	Missiler og våbensystemer	\N	\N	0.6000	2026	\N	EUR	\N	\N	\N	Defense	\N	.PA	LON	^FCHI	HO.PA
HOG	HOG	Harley Davidson	Automotive	US	C-Di	https://www.marketscreener.com/quote/stock/HARLEY-DAVIDSON-INC-12894/	https://finance.yahoo.com/quote/HOG?p=HOG&.tsrc=fin-srch	https://www.harley-davidson.com	Motorcykler	\N	\N	0.3200	2026	\N	USD	\N	\N	\N	Automotive	\N	.US	NY	^GSPC	HOG
HOLN.SW	SWX:HOLN	Holcim	ConstrMaterials	CH	Basi	https://www.marketscreener.com/quote/stock/HOLCIM-LTD-2956274/	https://finance.yahoo.com/quote/HOLN.SW?p=HOLN.SW&.tsrc=fin-srch	https://www.holcim.com	Cement	\N	\N	\N	\N	\N	CHF	\N	\N	\N	ConstrMaterials	\N	.SW	LON	^STOXX	HOLN.SW
HON	HON	Honeywell	Manuf_Big	US	Indu	https://www.marketscreener.com/quote/stock/HONEYWELL-INTERNATIONAL-I-4827/	https://finance.yahoo.com/quote/HON?p=HON&.tsrc=fin-srch	https://www.honeywell.com	Industrielt udstyr. 99000 ansatte (2022)	\N	\N	0.4400	2026	\N	USD	\N	\N	\N	Manuf_Big	\N	.US	NY	^GSPC	HON
HOOD	HOOD	Robinhood Markets	Services(Fina)	US	Fina	https://www.marketscreener.com/quote/stock/ROBINHOOD-MARKETS-INC-125228571/	https://finance.yahoo.com/quote/HOOD?p=HOOD&.tsrc=fin-srch	https://www.robinhood.com	Online børsmægler med innovative services, f.eks. tokenized stocks og crypto	t	\N	\N	\N	\N	USD	\N	\N	\N	Services(Fina)	\N	.US	NY	^GSPC	HOOD
HOT.DE	ETR:HOT	Hochtief	Construction	DE	Indu	https://www.marketscreener.com/quote/stock/HOCHTIEF-AG-436197/	\N	https://hochtief.de	\N	t	\N	0.4500	2026	\N	EUR	\N	\N	\N	Construction	\N	.DE	LON	^GDAXI	HOT.DE
HPE	HPE	Hewlett Packard Enterprise Company	TechToProfs	US	Tech	https://www.marketscreener.com/quote/stock/HEWLETT-PACKARD-ENTERPRIS-24843838/	https://finance.yahoo.com/quote/HPE/	https://www.hpe.com	Softwareløsninger til virksomheder	\N	\N	0.4700	2026	\N	USD	\N	\N	\N	TechToProfs	\N	.US	NY	^GSPC	HPE
HR	HR	Healthcare Realty	Property	US	REIT	https://www.marketscreener.com/quote/stock/HEALTHCARE-REALTY-TRUST-I-12974/	https://finance.yahoo.com/quote/HR?p=HR&.tsrc=fin-srch	https://www.healthcarerealty.com	Efter fusion 2022 med HTA er det den største ejer i US af høj-kvalitets Medical Office Buildings	\N	\N	0.5600	2026	\N	USD	\N	\N	\N	Property	\N	.US	NY	^GSPC	HR
HSBA.L	LON:HSBA	HSBC Holdings	Bank	China	Fina	https://www.marketscreener.com/quote/stock/HSBC-HOLDINGS-PLC-16896790/	https://finance.yahoo.com/quote/HSBA.L?p=HSBA.L&.tsrc=fin-srch-v1	https://www.hsbc.com	\N	\N	\N	0.4700	2026	\N	GBX	\N	\N	\N	Bank	\N	.L	LON	^FTSE	HSBA.L
HST	HST	Host Hotels & Resorts	Property	US	REIT	https://www.marketscreener.com/quote/stock/HOST-HOTELS-RESORTS-INC-12950/	https://finance.yahoo.com/quote/HST/	https://www.hosthotels.com	Largest lodging REIT and owning luxury and upper-upscale hotels	\N	\N	0.3200	2026	\N	USD	\N	\N	\N	Property	\N	.US	NY	^GSPC	HST
STAG	STAG	STAG Industrial	Property	US	REIT	https://www.marketscreener.com/quote/stock/STAG-INDUSTRIAL-INC-7785320/	\N	https://www.stagindustrial.com	Industrial property	\N	\N	0.7100	2026	\N	USD	\N	\N	\N	Property	\N	.US	NY	^GSPC	STAG
HSY	HSY	The Hershey Company	Food	US	C-St	https://www.marketscreener.com/quote/stock/THE-HERSHEY-COMPANY-12988/	https://finance.yahoo.com/quote/HSY?p=HSY&.tsrc=fin-srch	https://www.thehersheycompany.com	Snacks, beverage, chocolate	\N	\N	0.3000	2026	\N	USD	\N	\N	\N	Food	\N	.US	NY	^GSPC	HSY
HTGC	HTGC	Hercules Capital	BDC	US	Fina	https://www.marketscreener.com/quote/stock/HERCULES-CAPITAL-INC-10515005/	https://finance.yahoo.com/quote/HTGC?p=HTGC&.tsrc=fin-srch	https://www.htgc.com	Technology and growth focused, Internally managed	\N	\N	0.3300	2026	\N	USD	\N	\N	\N	BDC	\N	.US	NY	^GSPC	HTGC
HTHIY	HTHIY	Hitachi (OTC)	Manuf_Big	Japan	Indu	https://www.marketscreener.com/quote/stock/HITACHI-LTD-120787088/	https://finance.yahoo.com/quote/HTHIY/	https://www.hitachi.co.jp/	Industrial equipment inden for mange brancher, stor energy-equipment division (a la GE Vernova og Siemens Energy). 1 ADR=2stk 6501.TO-aktier	\N	\N	0.4000	2026	\N	USD	\N	\N	\N	Manuf_Big	\N	.US	NY	^GSPC	HTHIY
HUBB	HUBB	Hubbell 	Manuf_Special	US	Indu	https://www.marketscreener.com/quote/stock/HUBBELL-INCORPORATED-25531608/	\N	https://www.hubbell.com	Elektricitets-udstyr og service til forsyningsselskaber	\N	\N	0.8000	2026	\N	USD	\N	\N	\N	Manuf_Special	\N	.US	NY	^GSPC	HUBB
HUM	HUM	Humana	Healthcare	US	Heal	https://www.marketscreener.com/quote/stock/HUMANA-INC-13000/	https://finance.yahoo.com/quote/HUM?p=HUM&.tsrc=fin-srch	https://www.humana.com	Vigtigste konkurrent til United Health	\N	\N	0.8300	2026	\N	USD	\N	\N	\N	Healthcare	\N	.US	NY	^GSPC	HUM
HUSCO.CO	CPH:HUSCO	HusCompagniet	ConstrHomes	DK	C-Di	https://www.marketscreener.com/quote/stock/HUSCOMPAGNIET-A-S-115395176/	https://finance.yahoo.com/quote/HUSCO.CO?p=HUSCO.CO&.tsrc=fin-srch	https://www.huscompagniet.dk	Single-family detached houses	\N	\N	\N	\N	\N	DKK	\N	\N	t	ConstrHomes	\N	.CO	LON	^OMXC20	HUSCO.CO
HUT	HUT	Hut 8 Corp	Crypto	US	Fina	https://www.marketscreener.com/quote/stock/HUT-8-CORP-120796942/	https://finance.yahoo.com/quote/HUT/	https://hut8.com/	Vertically integrated operator of energy infrastructure and Bitcoin miners in North America. Stor kontrakt med Google data center.  222 ansatte.	\N	\N	0.7000	2026	\N	USD	\N	\N	\N	Crypto	\N	.US	NY	^BTC	HUT
HUYA	HUYA	Huya	TechToCons	China	Tech	https://www.marketscreener.com/quote/stock/HUYA-INC-45039991/	\N	https://www.huya.com	\N	\N	\N	\N	\N	\N	USD	\N	\N	\N	TechToCons	\N	.US	NY	^GSPC	HUYA
HWM	HWM	Howmet Aerospace Inc.	Manuf_Special	US	Indu	https://www.marketscreener.com/quote/stock/HOWMET-AEROSPACE-INC-104922916/	https://finance.yahoo.com/quote/HWM/	https://www.howmet.com/about-us/	Advanced engineered solutions for the aerospace and transportation industries	\N	\N	0.3700	2026	\N	USD	\N	\N	\N	Manuf_Special	\N	.US	NY	^GSPC	HWM
HY9H.F	FRA:HY9H	SK Hynix	Semi	Sydkorea	Tech	https://www.marketscreener.com/quote/stock/SK-HYNIX-INC-117226155/	https://finance.yahoo.com/quote/HY9H.F/	https://www.skhynix.com/	Global offering of semiconductor products: DRAM, NAND storage products and many others	\N	\N	0.5800	2026	\N	EUR	\N	\N	\N	Semi	\N	.F	Other	Other	HY9H.F
HYLB	HYLB	Xtrackers USD High Yield Corporate Bond UCITS ETF	Bond	US	na	https://finance.yahoo.com/quote/HYLB?p=HYLB&.tsrc=fin-srch	https://finance.yahoo.com/quote/HYLB?p=HYLB&.tsrc=fin-srch	\N	XUHY	\N	\N	0.5000	2026	\N	USD	\N	\N	\N	Other[na]	7	.US	NY	^GSPC	HYLB
IAG.L	LON:IAG	IAG: Intl consolidated airlines group	Trpt_Airline	UK	Indu	https://www.marketscreener.com/quote/stock/INTERNATIONAL-CONSOLIDATE-7233512/	https://finance.yahoo.com/quote/IAG.L?p=IAG.L&.tsrc=fin-srch	https://www.iairgroup.com	Moderselsk for British Airways, Iberia og Vueling	\N	\N	\N	\N	\N	GBX	\N	\N	\N	Trpt_Airline	\N	.L	LON	^FTSE	IAG.L
IBCX.L	LON:IBCX	iShares € Corp Bond Large Cap UCITS ETF EUR (Dist)	Bond	Europe	na	https://finance.yahoo.com/quote/IBCX.L?p=IBCX.L&.tsrc=fin-srch	https://finance.yahoo.com/quote/IBCX.L?p=IBCX.L&.tsrc=fin-srch	\N	=IBCX.AS (AMS:IBCX)	\N	\N	\N	\N	\N	GBX	\N	\N	\N	Other[na]	7	.L	LON	^FTSE	IBCX.L
IBE.MC	BME:IBE	Iberdrola	Util_Rnwb	ES	Util	https://www.marketscreener.com/quote/stock/IBERDROLA-355153/	https://finance.yahoo.com/quote/IBE.MC?p=IBE.MC&.tsrc=fin-srch	https://www.iberdrola.com	Solar og wind farms	\N	\N	0.4700	2026	\N	EUR	\N	\N	\N	Util_Rnwb	\N	.MC	LON	^STOXX	IBE.MC
IBKR	IBKR	Interactive Brokers Grp (IBKR)	Services(Fina)	US	Fina	https://www.marketscreener.com/quote/stock/INTERACTIVE-BROKERS-GROUP-50014/	https://finance.yahoo.com/quote/IBKR?p=IBKR&.tsrc=fin-srch	https://www.interactivebrokers.com	Automated global electronic broker, 33 land, 36 valutaer	t	\N	0.4200	2026	\N	USD	\N	\N	\N	Services(Fina)	\N	.US	NY	^GSPC	IBKR
IBM	IBM	Intl Business Machines	TechToProfs	US	Tech	https://www.marketscreener.com/quote/stock/IBM-4828/	\N	https://www.ibm.com	\N	\N	\N	0.3500	2026	\N	USD	\N	\N	\N	TechToProfs	\N	.US	NY	^GSPC	IBM
IBN	IBN	ICICI Bank	Bank	India	Fina	https://www.marketscreener.com/quote/stock/ICICI-BANK-LIMITED-13028/	\N	https://www.icicibank.com	\N	\N	\N	0.7400	2026	\N	USD	\N	\N	\N	Bank	\N	.US	NY	^GSPC	IBN
IBTA.L	LON:IBTA	iShares $ Treasury Bond 1-3yr UCITS ETF USD (ACC)	Bond	UK	na	https://www.marketscreener.com/quote/etf/ISHARES-TREASURY-BOND-1-34602500/	https://finance.yahoo.com/quote/IBTA.L/	\N	Andre: 0-1 år IB01, 3-7 år CBU7	\N	\N	0.5500	2026	\N	USD	\N	\N	\N	Other[na]	7	.L	LON	^FTSE	IBTA.L
ICE	ICE	Intercontinental Exchange	Services(Fina)	US	Fina	https://www.marketscreener.com/quote/stock/INTERCONTINENTAL-EXCHANGE-14931198/	https://finance.yahoo.com/quote/ICE/	https://www.ice.com	Owns several major exchanges, including NYSE and LSE. Investor behind Polymarket.	\N	\N	\N	\N	\N	USD	\N	\N	\N	Services(Fina)	\N	.US	NY	^GSPC	ICE
ICHR	ICHR	Ichor Holding	Semi	US	Tech	https://www.marketscreener.com/quote/stock/ICHOR-HOLDINGS-LTD-37892952/	\N	https://www.ichorsystems.com	Udstyr til semi-fremstilling, specielt dosering af gasser og væsker	\N	\N	\N	\N	\N	USD	\N	\N	t	Semi	\N	.US	NY	^GSPC	ICHR
ICLR	ICLR	ICON plc	Healthcare	Irland	Heal	https://www.marketscreener.com/quote/stock/ICON-PUBLIC-LIMITED-COMPA-12685103/	\N	https://www.iconplc.com	Healthcare intelligence and clinical research. Købte PRAH i Q3-2021	\N	\N	0.4500	2026	\N	USD	\N	\N	\N	Healthcare	\N	.US	NY	^GSPC	ICLR
IDR.MC	BME:IDR	Indra sistemas	Defense	ES	Indu	https://www.marketscreener.com/quote/stock/INDRA-SISTEMAS-S-A-413470/	https://finance.yahoo.com/quote/IDR.MC/	https://www.indragroup.com/en	Aktiv indenfor informationsteknologi og forsvarssystemer.	\N	\N	0.5500	2026	\N	CAD	\N	\N	\N	Defense	\N	.MC	LON	^STOXX	IDR.MC
IDXX	IDXX	IDEXX Laboratories	Healthcare	US	Heal	https://www.marketscreener.com/quote/stock/IDEXX-LABORATORIES-INC-9641/	\N	https://www.idexx.com	Veterinary services	\N	\N	0.6500	2026	\N	USD	\N	\N	\N	Healthcare	\N	.US	NY	^GSPC	IDXX
IFX.DE	ETR:IFX	Infenion Technologies	Semi	DE	Tech	https://www.marketscreener.com/quote/stock/INFINEON-TECHNOLOGIES-AG-436299/	https://finance.yahoo.com/quote/IFX.DE?p=IFX.DE&.tsrc=fin-srch	https://www.infineon.com	Leder i auto-chips. Udvikler i Phone netværks-komponenter. Infenion og STMicro electronics er eneste EU-chipmakers.	\N	\N	\N	\N	\N	EUR	\N	\N	\N	Semi	\N	.DE	LON	^GDAXI	IFX.DE
IKOR.L	LON:IKOR	iShares KOREA UCITS ETF USD (DIST)	Country	Sydkorea	na	https://www.moneyam.com/shareprice/IKOR	https://finance.yahoo.com/quote/IKOR.L?p=IKOR.L&.tsrc=fin-srch-v1	\N	Omk.pct: 0,74%. 100 aktier.  	\N	\N	0.5300	2026	\N	USD	\N	\N	\N	Country	\N	.L	LON	^FTSE	IKOR.L
IKSA.L	LON:IKSA	iShares MSCI Saudi Arabia Capped UCITS ETF USD (Acc)	Country	Saudi	na	https://www.ishares.com/uk/individual/en/products/279996/ishares-msci-saudi-arabia-capped-imi-ucits-etf	https://finance.yahoo.com/quote/IKSA.L?p=IKSA.L&.tsrc=fin-srch	\N	IKSD.L er distr (mindre omsat end IKSA.L)	\N	\N	0.5600	2026	\N	USD	\N	\N	\N	Country	\N	.L	LON	^FTSE	IKSA.L
IMO.JO	JSE:IMP	Impala Platinum Holdings Limited	Mining	Sydafrika	Basi	https://www.marketscreener.com/quote/stock/IMPALA-PLATINUM-HOLDINGS--1413371/	https://finance.yahoo.com/quote/IMP.JO/	https://www.implats.co.za/	PGM‑miner (palladium 38.6%, platinum 28%, rhodium 26.8%, gold 3%, iridium 2.2%, ruthenium 1.3% and silver 0.1%)	\N	\N	0.7200	2026	\N	ZAR	\N	\N	\N	Mining	\N	.JO	Other	^DJAFK	IMO.JO
INCY	INCY	Incyte Corp	Pharma	US	Heal	https://www.marketscreener.com/quote/stock/INCYTE-CORPORATION-9675/	https://finance.yahoo.com/quote/INCY/	http://www.incyte.com/	Cancer og inflammatoriske sygdomme. 2600 ansatte	\N	\N	0.4000	1899	\N	USD	\N	\N	\N	Pharma	\N	.US	NY	^GSPC	INCY
INDU-A.ST	STO:INDU-A	Industrivärden	Investment	SE	Fina	https://www.marketscreener.com/quote/stock/AB-INDUSTRIVARDEN-6491872/	https://finance.yahoo.com/quote/INDU-A.ST?p=INDU-A.ST&.tsrc=fin-srch	https://www.industrivarden.se	Investeringsselskab	\N	\N	0.3500	2026	\N	SEK	\N	\N	\N	Investment	\N	.ST	LON	^OMX	INDU-A.ST
INFY	INFY	Infosys	TechToProfs	India	Tech	https://www.marketscreener.com/quote/stock/INFOSYS-LIMITED-56049208/	\N	https://www.infosys.com	\N	\N	\N	0.6500	2026	\N	USD	\N	\N	\N	TechToProfs	\N	.US	NY	^GSPC	INFY
INGA.AS	AMS:INGA	ING Groep	Bank	NL	Fina	https://www.marketscreener.com/quote/stock/ING-GROEP-N-V-56358303/	https://finance.yahoo.com/quote/INGA.AS?p=INGA.AS&.tsrc=fin-srch	https://www.ing.com	\N	\N	\N	0.4400	2026	\N	EUR	\N	\N	\N	Bank	\N	.AS	LON	^AEX	INGA.AS
INRG.L	LON:INRG	iShares Global Clean Energy UCITS ETF	Rnwb(Ener)	UK	Ener	https://www.ishares.com/uk/individual/en/products/251911/ishares-global-clean-energy-ucits-etf#/	https://finance.yahoo.com/quote/INRG.L?p=INRG.L&.tsrc=fin-srch	\N	\N	t	\N	0.4700	2026	\N	GBX	\N	\N	\N	Rnwb(Ener)	\N	.L	LON	^FTSE	INRG.L
INSW	INSW	International Seaways	Trpt_Ship (Ener)	US	Ener	https://www.marketscreener.com/quote/stock/INTERNATIONAL-SEAWAYS-IN-32104272/	https://finance.yahoo.com/quote/INSW?p=INSW&.tsrc=fin-srch	https://www.intlseas.com	Olie-tankskibe	\N	\N	\N	\N	\N	USD	\N	\N	\N	Trpt_Ship (Ener)	\N	.US	NY	^GSPC	INSW
INTC	INTC	Intel	Semi	US	Tech	https://www.marketscreener.com/quote/stock/INTEL-CORPORATION-4829/	\N	https://www.intel.com	Chips	\N	\N	0.3700	2026	\N	USD	\N	\N	\N	Semi	\N	.US	NY	^GSPC	INTC
INTRUM.ST	STO:INTRUM	Intrum	Bank	SE	Fina	https://www.marketscreener.com/quote/stock/INTRUM-AB-PUBL-41094252/	https://finance.yahoo.com/quote/INTRUM.ST?p=INTRUM.ST&.tsrc=fin-srch	https://www.intrum.com	Vertikale financielle services, såsom kreditvurdering, inkasso, betalinger mm.	\N	\N	0.4400	2026	\N	SEK	\N	\N	\N	Bank	\N	.ST	LON	^OMX	INTRUM.ST
INTU	INTU	Intuit 	TechToProfs	US	Tech	https://www.marketscreener.com/quote/stock/INTUIT-INC-23277275/	https://finance.yahoo.com/quote/INTU?p=INTU&.tsrc=fin-srch	https://www.intuit.com	Softwareprodukter og service	\N	\N	\N	\N	\N	USD	\N	\N	\N	TechToProfs	\N	.US	NY	^GSPC	INTU
IONQ	IONQ	IonQ	TechToProfs	US	Tech	https://www.marketscreener.com/quote/stock/IONQ-INC-117182090/	https://finance.yahoo.com/quote/IONQ/	https://ionq.com/	Sælger kvanteberegninger til kommercielt og forskningsmæssig brug, som udføres af virksomhedens kvantecomputer, IonQ Forte	\N	\N	0.5000	2026	\N	USD	\N	\N	\N	TechToProfs	\N	.US	NY	^GSPC	IONQ
IPGP	IPGP	IPG Photonics	ElectrComponents	US	Tech	https://www.marketscreener.com/quote/stock/IPG-PHOTONICS-CORPORATION-40311217/	https://finance.yahoo.com/quote/IPGP/	https://www.ipgphotonics.com	Fiber lasers, diode lasers, and systems for materials processing, medical, and other applications	\N	\N	0.6500	2026	\N	USD	\N	\N	\N	ElectrComponents	\N	.US	NY	^GSPC	IPGP
IPI	IPI	Inteprid Potash	Agro	US	Basi	https://www.marketscreener.com/quote/stock/INTREPID-POTASH-INC-2989371/	https://finance.yahoo.com/quote/IPI?p=IPI&.tsrc=fin-srch	https://www.intrepidpotash.com	Potaske til landbruget. Under turnaround?	\N	\N	0.6700	2026	\N	USD	\N	\N	\N	Agro	\N	.US	NY	^GSPC	IPI
IREN	IREN	IREN 	Crypto	AUS	Fina	https://www.marketscreener.com/quote/stock/IREN-LIMITED-129472358/	https://finance.yahoo.com/quote/IREN/	https://iren.com/	Ejer og driver datacentre forsynet af vedvarende energi. Miner også bitcoin	\N	\N	\N	\N	\N	USD	\N	AI-infrastruktur	\N	Crypto	\N	.US	NY	^BTC	IREN
IRM	IRM	Iron Mountain	Property	US	REIT	https://www.marketscreener.com/quote/stock/IRON-MOUNTAIN-INCORPORATE-20499310/	\N	https://www.ironmountain.com	\N	\N	\N	0.6500	2026	\N	USD	\N	\N	\N	Property	\N	.US	NY	^GSPC	IRM
ISAC.L	LON:ISAC	iShares MSCI ACWI UCITS ETF (USD, Acc)	Diverse_na	Intl	na	https://www.justetf.com/uk/etf-profile.html?assetClass=class-equity&groupField=index&index=MSCI%2BAll%2BCountry%2BWorld%2B%2528ACWI%2529&from=search&isin=IE00B6R52259#listing	https://finance.yahoo.com/quote/ISAC.L?p=ISAC.L&.tsrc=fin-srch	\N	All-world inkl. emergent (stor vægt US). GBX-udgave: SSAC.L (lille vol)	\N	\N	0.6900	2026	\N	USD	\N	\N	\N	Diverse_na	\N	.L	LON	^FTSE	ISAC.L
ISP.MI	BIT:ISP	Intesa Sanpaolo	Bank	IT	Fina	https://www.marketscreener.com/quote/stock/INTESA-SANPAOLO-S-P-A-68944/	https://finance.yahoo.com/quote/ISP.MI?p=ISP.MI&.tsrc=fin-srch	https://www.group.intesasanpaolo.com	Torino-basret bank. En af EUs største.	t	\N	\N	\N	\N	EUR	\N	\N	\N	Bank	\N	.MI	LON	^STOXX	ISP.MI
ISRG	ISRG	Intuitive Surgical	Electronics_Medical	US	Indu	https://www.marketscreener.com/quote/stock/INTUITIVE-SURGICAL-INC-9740/	https://finance.yahoo.com/quote/IBTA.L/	https://www.intuitive.com	Surgical robots	\N	\N	0.6000	2026	\N	USD	\N	\N	\N	Other[Indu]	7	.US	NY	^GSPC	ISRG
ISSC	ISSC	Innovative Aerosystems	Defense	US	Indu	https://www.marketscreener.com/quote/stock/INNOVATIVE-AEROSYSTEMS-IN-9742/	https://finance.yahoo.com/quote/ISSC/	https://www.iascorp.com/	Cockpit electronics for commercial and governmental clients	\N	\N	\N	\N	\N	USD	\N	\N	\N	Defense	\N	.US	NY	^GSPC	ISSC
ITKY.L	LON:ITKY	iShares II PLC iShares MSCI TURKEY UCITS ETF, GBp (DIST)	Country	Tyrkiet	na	https://www.google.com/search?tbm=fin&ei=ErPpWt-gIc_QkwWM9KfoBg&stick=H4sIAAAAAAAAAONgecRozi3w8sc9YSm9SWtOXmPU4OIKzsgvd80rySypFJLiYoOyBKT4uHj00_UNC82M0gqN4zN4AGSZphU8AAAA&q=LON%3A+ITKY&oq=itky&gs_l=finance-immersive.1.1.81l3.1938.3363.0.11697.6.6.0.0.0.0.140.503.0j4.4.0....0...1c.1.64.finance-immersive..2.4.502.0...0.HjUImWENbz0#scso=uid_H7PpWur7CMjTsAf17JfwBg_5:0	\N	\N	Tyrkiet, UCITS	\N	\N	0.3100	2026	\N	GBX	\N	\N	\N	Country	\N	.L	LON	^FTSE	ITKY.L
ITRI	ITRI	Itron	TechToProfs	US	Tech	https://www.marketscreener.com/quote/stock/ITRON-INC-9753/	https://finance.yahoo.com/quote/ITRI/	http://www.itron.com/	Partnerskab med Nvidia om at få deres tech ud i edge computing (bruger-systemer)	\N	\N	0.6500	2026	\N	USD	\N	\N	\N	TechToProfs	\N	.US	NY	^GSPC	ITRI
ITUB	ITUB	Itau Unibanco (Brazil)	Bank	Brazil	Fina	https://www.marketscreener.com/quote/stock/ITA-UNIBANCO-HOLDING-S-A-6492984/	\N	https://www.itau.com.br	\N	\N	\N	0.3300	2026	\N	USD	\N	\N	\N	Bank	\N	.US	NY	^GSPC	ITUB
ITWN.L	LON:ITWN	iShares TAIWAN UCITS ETF USD (DIST)	Country	Taiwan	na	https://www.ishares.com/uk/individual/en/products/251878/ishares-msci-taiwan-ucits-etf	https://finance.yahoo.com/quote/ITWN.L?p=ITWN.L	\N	\N	\N	\N	0.4200	2026	\N	USD	\N	\N	\N	Country	\N	.L	LON	^FTSE	ITWN.L
ITX.MC	BME:ITX	Inditex	Clothing	ES	C-Di	https://www.marketscreener.com/quote/stock/INDITEX-16943135/	\N	https://www.inditex.com/en	Design og salg af modetøj	t	\N	0.3200	2026	\N	EUR	\N	\N	\N	Clothing	\N	.MC	LON	^STOXX	ITX.MC
IVG.MI	BIT:IVG	Iveco Group N.V.	Manuf_Special	IT	Indu	https://www.marketscreener.com/quote/stock/IVECO-GROUP-N-V-131301260/	https://finance.yahoo.com/quote/IVG.MI/	http://www.ivecogroup.com/	Lastbiler. En lille biz: Defense vehicles	\N	\N	0.3700	2026	\N	EUR	\N	\N	\N	Manuf_Special	\N	.MI	LON	^STOXX	IVG.MI
IVR	IVR	Invesco Mortgage Capital	Mortgages	US	REIT	https://www.marketscreener.com/quote/stock/INVESCO-MORTGAGE-CAPITAL-5401914/	https://finance.yahoo.com/quote/IVR?p=IVR&.tsrc=fin-srch	https://www.invescomortgagecapital.com	Pantebreve (agency)	\N	\N	0.3500	2026	\N	USD	\N	\N	\N	Mortgages	\N	.US	NY	^GSPC	IVR
IVSO.ST	STO:IVSO	Invisio AB	Defense	SE	Indu	https://www.marketscreener.com/quote/stock/INVISIO-AB-6498891/	https://finance.yahoo.com/quote/IVSO.ST/	https://invisio.com/	Kommunikations- og høreværnsystemer indenfor forsvars- og sikkerhedssektoren	\N	\N	0.4700	2026	\N	SEK	\N	\N	\N	Defense	\N	.ST	LON	^OMX	IVSO.ST
IZEA	IZEA	Izea Worldwide	TechToCons	US	Tech	https://www.marketscreener.com/quote/stock/IZEA-WORLDWIDE-INC-45456112/	https://finance.yahoo.com/quote/IZEA?p=IZEA&.tsrc=fin-srch	https://www.izea.com	\N	\N	\N	0.3500	2026	\N	USD	\N	\N	\N	TechToCons	\N	.US	NY	^GSPC	IZEA
J	J	Jacobs Engineering Grp	Consulting(Indu)	US	Indu	https://www.marketscreener.com/quote/stock/JACOBS-SOLUTIONS-INC-13160/	https://finance.yahoo.com/quote/J?p=J&.tsrc=fin-srch	https://www.jacobs.com	Ingeniørvirksomhed	\N	\N	0.5800	2026	\N	USD	\N	\N	\N	Other[Indu]	7	.US	NY	^GSPC	J
JBI	JBI	Janus International	ConstrHomes	US	C-Di	https://www.marketscreener.com/quote/stock/JANUS-INTERNATIONAL-GROUP-88384954/	https://finance.yahoo.com/quote/JBI?p=JBI&.tsrc=fin-srch	https://www.janusintl.com	Self-storage and access control solutions	\N	\N	0.3800	2026	\N	USD	\N	\N	\N	ConstrHomes	\N	.US	NY	^GSPC	JBI
JBL	JBL	Jabil	ElectrComponents	US	Tech	https://www.marketscreener.com/quote/stock/JABIL-INC-13153/	https://finance.yahoo.com/quote/JBL/	https://www.jabil.com	Electronics: Manufacturing services and solutions worldwide	\N	\N	0.5000	2026	\N	USD	\N	\N	\N	ElectrComponents	\N	.US	NY	^GSPC	JBL
JD	JD	JD.com	TechToCons	China	Tech	https://www.marketscreener.com/quote/stock/JD-COM-INC-16538052/	\N	https://www.jd.com	No. 2 Chinese consumer Internet sales platform	\N	\N	0.5700	2026	\N	USD	\N	\N	\N	TechToCons	\N	.US	NY	^GSPC	JD
JEF	JEF	Jefferies Financial Group	Investment	US	Fina	https://www.marketscreener.com/quote/stock/JEFFERIES-FINANCIAL-GROUP-43482239/	https://finance.yahoo.com/quote/JEF/	http://www.jefferies.com/	Global, full-service investment banking and capital markets company	\N	\N	0.6200	2026	\N	USD	\N	\N	\N	Investment	\N	.US	NY	^GSPC	JEF
JKS	JKS	JinkoSolar	Rnwb(Indu)	China	Indu	https://www.marketscreener.com/quote/stock/JINKOSOLAR-HOLDING-CO-L-5949045/	\N	https://www.jinkosolar.com	\N	t	\N	0.4400	2026	\N	USD	\N	\N	\N	Rnwb(Indu)	\N	.US	NY	^GSPC	JKS
JNJ	JNJ	Johnson & Johnson	Pharma	US	Heal	https://www.marketscreener.com/quote/stock/JOHNSON-JOHNSON-4832/	https://finance.yahoo.com/quote/JNJ?p=JNJ&.tsrc=fin-srch	https://www.jnj.com	\N	t	\N	0.2800	2026	\N	USD	\N	\N	\N	Pharma	\N	.US	NY	^GSPC	JNJ
JPM	JPM	JPMorgan Chase	Bank	US	Fina	https://www.marketscreener.com/quote/stock/JPMORGAN-CHASE-CO-37468997/	\N	https://www.jpmorganchase.com	USA's største bank. The great dealmaker (with Goldman Sachs)	\N	\N	0.4000	2026	\N	USD	\N	\N	\N	Bank	\N	.US	NY	^GSPC	JPM
JXN	JXN	Jackson Financial	Investment	US	Fina	https://www.marketscreener.com/quote/stock/JACKSON-FINANCIAL-INC-126371094/	https://finance.yahoo.com/quote/JXN?p=JXN&.tsrc=fin-srch	https://www.jackson.com	Salg af lån til private. Spin-off fra Prudential 2020.  Alternativ: CSKR.L (Acc) og større børsomsætning	\N	\N	0.3200	2026	\N	USD	\N	\N	\N	Investment	\N	.US	NY	^GSPC	JXN
KB	KB	KB Financial Group	Bank	Korea	Fina	https://www.marketscreener.com/quote/stock/KB-FINANCIAL-GROUP-INC-4753228/	https://finance.yahoo.com/quote/KB?p=KB&.tsrc=fin-srch	https://www.kbfg.com	Banking and other financial services	\N	\N	0.4400	2026	\N	USD	\N	\N	\N	Bank	\N	.US	NY	^GSPC	KB
KBC.BR	EBR:KBC	KBC Groupe	Bank	Belgien	Fina	https://www.marketscreener.com/quote/stock/KBC-GROUPE-NV-5967/	https://finance.yahoo.com/quote/KBC.BR?p=KBC.BR&.tsrc=fin-srch	https://www.kbc.com	Belgiens 2.største bank. Aktiv i Østeuropa. Moderselskab KBC Ancora	\N	\N	0.5600	2026	\N	EUR	\N	\N	\N	Bank	\N	.BR	LON	^FCHI	KBC.BR
KBDC	KBDC	Kayne Anderson BDC	BDC	US	Fina	https://www.marketscreener.com/quote/stock/KAYNE-ANDERSON-BDC-INC-170351858/	https://finance.yahoo.com/quote/KBDC/	https://kaynebdc.com/	First lien senior secured, unitranche, and split-lien loans to middle-market companies. Externally managed.	t	\N	\N	\N	\N	USD	\N	\N	\N	BDC	\N	.US	NY	^GSPC	KBDC
KBH	KBH	KB Home	ConstrHomes	US	C-Di	https://www.marketscreener.com/quote/stock/KB-HOME-13230/	\N	https://www.kbhome.com	Homebuilding	\N	\N	0.3900	2026	\N	USD	\N	\N	\N	ConstrHomes	\N	.US	NY	^GSPC	KBH
KER.PA	EPA:KER	Kering	Luxury	FR	C-Di	https://www.marketscreener.com/quote/stock/KERING-4683/	https://finance.yahoo.com/quote/KER.PA?p=KER.PA&.tsrc=fin-srch	https://www.kering.com	Gucci, Yves-Saint Laurent, Bottega Venetta m.fl.	\N	\N	0.7000	2026	\N	EUR	\N	\N	\N	Luxury	\N	.PA	LON	^FCHI	KER.PA
KESKOB.HE	HEL:KESKOB	Kesko Oyj	Distributor	Finland	C-St	https://www.marketscreener.com/quote/stock/KESKO-OYJ-1412478/	https://finance.yahoo.com/quote/KESKOB.HE/	https://www.kesko.fi/	Grossist, har opkøbt Davidsen tømmerhandel	\N	\N	0.4700	2026	\N	EUR	\N	\N	\N	Other[C-St]	\N	.HE	LON	^STOXX	KESKOB.HE
KEY	KEY	KeyCorp	Bank	US	Fina	https://www.marketscreener.com/quote/stock/KEYCORP-40311107/	https://finance.yahoo.com/quote/KEY	https://www.key.com	Bank og finansielle services	\N	\N	0.3500	2026	\N	USD	\N	\N	\N	Bank	\N	.US	NY	^GSPC	KEY
KEYS	KEYS	Keysight Technologies	ElectrComponents	US	Tech	https://www.marketscreener.com/quote/stock/KEYSIGHT-TECHNOLOGIES-INC-18426374/	\N	https://www.keysight.com	Electronic design and test solutions	\N	\N	0.5300	2026	\N	USD	\N	\N	\N	ElectrComponents	\N	.US	NY	^GSPC	KEYS
KGC	KGC	Kinross Gold Corp	Gold	CAN	Basi	https://www.marketscreener.com/quote/stock/KESTREL-GOLD-INC-16279089/	https://finance.yahoo.com/quote/KGC/	https://www.kinross.com/	Miner i US, Brasilien, Chile, Canada og Mauritanien	\N	\N	0.5000	2026	\N	USD	\N	\N	\N	Gold	\N	.US	NY	^GSPC	KGC
KIM	KIM	Kimco Realty Corp (Shopping centers)	Property	US	REIT	https://www.marketscreener.com/quote/stock/KIMCO-REALTY-CORPORATION-13261/	https://finance.yahoo.com/quote/KIM?p=KIM&.tsrc=fin-srch	https://www.kimcorealty.com	\N	\N	\N	0.6000	2026	\N	USD	\N	\N	\N	Property	\N	.US	NY	^GSPC	KIM
KLAC	KLAC	KLA Corp (KLA-Tencor)	Semi	US	Tech	https://www.marketscreener.com/quote/stock/KLA-CORPORATION-40328827/	https://finance.yahoo.com/quote/KLAC	https://www.kla.com	Control and improvement procedures for semiconductor production processes	\N	\N	0.6500	2026	\N	USD	\N	\N	\N	Semi	\N	.US	NY	^GSPC	KLAC
KLAR	KLAR	Klarna Group	Fintech	UK	Fina	https://www.marketscreener.com/quote/stock/KLARNA-GROUP-PLC-194892731/	https://finance.yahoo.com/quote/KLAR/	https://www.klarna.com/	Udgangspunkt små korte forbrugerlån, men ønsker at være global eCommerce-bankforbindelse	t	\N	0.4500	2026	\N	USD	\N	\N	\N	Fintech	\N	.US	NY	^GSPC	KLAR
KMI	KMI	Kinder-Morgan	Oil&Gas	US	Ener	https://www.marketscreener.com/quote/stock/KINDER-MORGAN-INC-7331799/	https://finance.yahoo.com/quote/KMI/	http://www.kindermorgan.com/	Pipelines and storing gas and oil-related stuff. Transporterer 40% af US natural gas	\N	\N	0.3500	2026	\N	USD	\N	\N	\N	Oil&Gas	\N	.US	NY	^GSPC	KMI
KMR.L	LON:KMR	Kenmare Resources	Mining	Irland	Basi	https://www.marketscreener.com/quote/stock/KENMARE-RESOURCES-PLC-30340902/	https://finance.yahoo.com/quote/KMR.L?p=KMR.L&.tsrc=fin-srch	https://www.kenmareresources.com	Har én mine, en titan-hvidt-mine i Mozambique. 50% af salg går til Kina.	\N	\N	0.2200	2026	\N	GBX	\N	\N	\N	Mining	\N	.L	LON	^FTSE	KMR.L
KO	KO	Coca-Cola	Food	US	C-St	https://www.marketscreener.com/quote/stock/THE-COCA-COLA-COMPANY-4819/	https://finance.yahoo.com/quote/KO?p=KO&.tsrc=fin-srch	https://www.coca-colacompany.com	Coca-Cola, Diet Coke, Fanta, Schweppes, Sprite, Minute Maid og mange flere	\N	\N	0.7200	2026	\N	USD	\N	\N	\N	Food	\N	.US	NY	^GSPC	KO
KOF	KOF	Coca-Cola FEMSA	Food	Mexico	C-St	https://www.marketscreener.com/quote/stock/COCA-COLA-FEMSA-S-A-B-D-13284/	https://finance.yahoo.com/quote/KOF?p=KOF&.tsrc=fin-srch	https://www.coca-colafemsa.com	Mexico-baseret tapperi for CC	\N	\N	0.4000	2026	\N	USD	\N	\N	\N	Food	\N	.US	NY	^GSPC	KOF
KOG.OL	OSL:KOG	Kongsberg Gruppen	Defense	NO	Indu	https://www.marketscreener.com/quote/stock/KONGSBERG-GRUPPEN-ASA-1413189/	https://finance.yahoo.com/quote/KOG.OL/	https://www.kongsberg.com/	Forsvar	\N	\N	0.5500	2026	\N	NOK	\N	\N	\N	Defense	\N	.OL	LON	^OSEBX	KOG.OL
KPN.AS	AMS:KPN	KPN (Koninklijke KPN)	Telecom	NL	Tele	https://www.marketscreener.com/quote/stock/ROYAL-KPN-N-V-6287/	https://finance.yahoo.com/quote/KPN.AS?p=KPN.AS&.tsrc=fin-srch	https://www.kpn.com	\N	\N	\N	0.5000	2026	\N	EUR	\N	\N	\N	Telecom	\N	.AS	LON	^AEX	KPN.AS
KR	KR	Kroger	Food	US	C-St	https://www.marketscreener.com/quote/stock/KROGER-13293/	https://www.thekrogerco.com/	https://www.thekrogerco.com	Food retailer and drugstores	\N	\N	\N	\N	\N	USD	\N	\N	\N	Food	\N	.US	NY	^GSPC	KR
KRC	KRC	Kilroy Realty Corp	Property	US	REIT	https://www.marketscreener.com/quote/stock/KILROY-REALTY-CORPORATION-13297/	https://finance.yahoo.com/quote/KRC?p=KRC&.tsrc=fin-srch	https://www.kilroyrealty.com	Owns, remodels and manages real estate, office, life sc and submarkets	\N	\N	0.5500	2026	\N	USD	\N	\N	\N	Property	\N	.US	NY	^GSPC	KRC
KRMN	KRMN	Karman Hldgs	Defense	US	Indu	https://www.marketscreener.com/quote/stock/KARMAN-HOLDINGS-INC-182801079/	https://finance.yahoo.com/quote/KRMN/	https://karman-sd.com/	Mission-critical solutions for US missile and space ptrograms	\N	\N	0.5000	2026	\N	USD	\N	\N	\N	Defense	\N	.US	NY	^GSPC	KRMN
KTB	KTB	Kontoor Brands	Clothing	US	C-Di	https://www.marketscreener.com/quote/stock/KONTOOR-BRANDS-INC-58863867/	https://finance.yahoo.com/quote/KTB?p=KTB&.tsrc=fin-srch	https://www.kontoorbrands.com	Lifestyle clothing	\N	\N	\N	\N	\N	USD	\N	\N	\N	Clothing	\N	.US	NY	^GSPC	KTB
KTOS	KTOS	Kratos Defense & Security Solutions	Defense	US	Indu	https://www.marketscreener.com/quote/stock/KRATOS-DEFENSE-SECURITY-S-11374/	https://finance.yahoo.com/quote/KTOS/	https://www.kratosdefense.com/	Drones, rocket systems and space hardware	\N	\N	0.6300	2026	\N	USD	\N	\N	\N	Defense	\N	.US	NY	^GSPC	KTOS
KVUE	KVUE	Kenvue	Pharma	US	Heal	https://www.marketscreener.com/quote/stock/KENVUE-INC-154055852/	https://finance.yahoo.com/quote/KVUE?p=KVUE&.tsrc=fin-srch	https://www.kenvue.com	OTC-delen af J&J. Udskilt 1.5.23	t	\N	0.5300	2026	\N	USD	\N	\N	\N	Pharma	\N	.US	NY	^GSPC	KVUE
KWEB.L	LON:KWEB	Kraneshares Csi China Internet UCITS ETF (USD,Acc)	TechToCons	China	Tech	https://kraneshares.eu/kwebln/#	https://finance.yahoo.com/quote/KWEB.L?p=KWEB.L&.tsrc=fin-srch	\N	\N	t	\N	0.5500	2026	\N	USD	\N	\N	\N	TechToCons	\N	.L	LON	^FTSE	KWEB.L
KYCCF	KYCCF	Kyence (Japan)	Manuf_Special	Japan	Indu	https://www.marketscreener.com/quote/stock/KEYENCE-CORPORATION-6492212/	https://finance.yahoo.com/quote/KYCCF?p=KYCCF&.tsrc=fin-srch	https://www.keyence.co.jp	Automations-udstyr til industrier	\N	\N	0.5800	2026	\N	USD	\N	\N	\N	Manuf_Special	\N	.US	NY	^GSPC	KYCCF
LADR	LADR	Ladder Capital (commercial)	Mortgages	US	REIT	https://www.marketscreener.com/quote/stock/LADDER-CAPITAL-CORP-15724814/	\N	https://www.laddercapital.com	\N	t	\N	0.2800	2026	\N	USD	\N	\N	\N	Mortgages	\N	.US	NY	^GSPC	LADR
LAZ	LAZ	Lazard Plc	Investment	US	Fina	https://www.marketscreener.com/quote/stock/LAZARD-13358/	\N	https://www.lazard.com	Finaciel rådgv og formueforvaltning. Internationalt.	\N	\N	0.3200	2026	\N	USD	\N	\N	\N	Investment	\N	.US	NY	^GSPC	LAZ
LC	LC	Lendingclub	Fintech	US	Fina	https://www.marketscreener.com/quote/stock/LENDINGCLUB-CORPORATION-61871302/	https://finance.yahoo.com/quote/LC/	https://www.lendingclub.com/	Bank offering like deposits, consumer loans like unsecured personal loans and secured auto refinance loans, patient and education loans; and small business loans: It operates a lending marketplace platform	\N	\N	0.6000	2026	\N	USD	\N	\N	\N	Fintech	\N	.US	NY	^GSPC	LC
LCII	LCII	LCI Industries	Holiday	US	C-Di	https://www.marketscreener.com/quote/stock/LCI-INDUSTRIES-32683197/	\N	https://www.corporate.lippert.com	\N	\N	\N	0.4400	2026	\N	USD	\N	\N	\N	Holiday	\N	.US	NY	^GSPC	LCII
LDO.MI	LDO	Leonardo	Defense	IT	Indu	https://www.marketscreener.com/quote/stock/LEONARDO-S-P-A-162001/	https://finance.yahoo.com/quote/LDO.MI/	http://www.finmeccanica.it/	Aerospace and defence systems	\N	\N	0.3500	2026	\N	EUR	\N	\N	\N	Defense	\N	.MI	LON	^STOXX	LDO.MI
LDOS	LDOS	Leidos Holdings	Defense	US	Indu	https://www.marketscreener.com/quote/stock/LEIDOS-HOLDINGS-INC-14308164/	https://finance.yahoo.com/quote/LDOS?p=LDOS&.tsrc=fin-srch	https://www.leidos.com	IT firma med vækst grundet Ukraine	\N	\N	0.5500	2026	\N	USD	\N	\N	\N	Defense	\N	.US	NY	^GSPC	LDOS
LEN	LEN	Lennar Corporation	ConstrHomes	US	C-Di	https://www.marketscreener.com/quote/stock/LENNAR-CORPORATION-13379/	https://finance.yahoo.com/quote/LEN?p=LEN&.tsrc=fin-srch	https://www.lennar.com	Homebuilding	\N	\N	0.3500	2026	\N	USD	\N	\N	\N	ConstrHomes	\N	.US	NY	^GSPC	LEN
LEU	LEU	Centrus Energy Corp.	Rnwb(Ener)	US	Ener	https://www.marketscreener.com/quote/stock/CENTRUS-ENERGY-CORP-21225363/	https://finance.yahoo.com/quote/LEU/	http://www.centrusenergy.com/	Uran-producent. Eneste producent i US af 20%-beriget uran (nødv til reaktorer). 322 ansatte.	\N	\N	0.4500	2026	\N	USD	\N	AI-infrastruktur	\N	Rnwb(Ener)	\N	.US	NY	^GSPC	LEU
LEVI	LEVI	Levi Strauss & Co	Clothing	US	C-Di	https://www.marketscreener.com/quote/stock/LEVI-STRAUSS-CO-56112430/	https://finance.yahoo.com/quote/LEVI/	https://www.levistrauss.com/	Beklædning af alle mulige slags	\N	\N	0.4200	2026	\N	USD	\N	\N	\N	Clothing	\N	.US	NY	^GSPC	LEVI
LH	LH	Laboratory Corp of America Hldg (Labcorp)	Healthcare	US	Heal	https://www.marketscreener.com/quote/stock/LABORATORY-CORPORATION-OF-13392/	https://finance.yahoo.com/quote/LH?p=LH&.tsrc=fin-srch	https://www.labcorp.com	Klinisk lab	\N	\N	0.6000	2026	\N	USD	\N	\N	\N	Healthcare	\N	.US	NY	^GSPC	LH
LHA.DE	ETR:LHA	Lufthansa	Trpt_Airline	DE	Indu	https://www.marketscreener.com/quote/stock/LUFTHANSA-436827/	https://finance.yahoo.com/quote/LHA.DE/	https://lufthansagroup.com	Airline	\N	\N	0.7400	2026	\N	EUR	\N	\N	\N	Trpt_Airline	\N	.DE	LON	^GDAXI	LHA.DE
LHX	LHX	L3Harris Technologies	Defense	US	Indu	https://www.marketscreener.com/quote/stock/L3HARRIS-TECHNOLOGIES-IN-60951433/	https://finance.yahoo.com/quote/LHX?p=LHX	https://www.l3harris.com	Kommunikationsudstyr til defence	\N	\N	0.4400	2026	\N	USD	\N	\N	\N	Defense	\N	.US	NY	^GSPC	LHX
LI	LI	Li Auto (Li Xiang)	Automotive	China	C-Di	https://www.marketscreener.com/quote/stock/LI-AUTO-INC-110325260/	https://finance.yahoo.com/quote/LI/	https://www.lixiang.com	EV-biler 2015.HKG.	\N	\N	0.6200	2026	\N	USD	\N	\N	\N	Automotive	\N	.US	NY	^GSPC	LI
LI.PA	EPA:LI	Klépierre (malls)	Property	FR	REIT	https://www.marketscreener.com/quote/stock/KLEPIERRE-4665/	\N	https://www.klepierre.com	\N	\N	\N	0.7500	2026	\N	EUR	\N	\N	\N	Property	\N	.PA	LON	^FCHI	LI.PA
LII	LII	Lennox International 	Construction	US	Indu	https://www.marketscreener.com/quote/stock/LENNOX-INTERNATIONAL-INC-13398/	https://finance.yahoo.com/quote/LII/	https://www.lennox.com	Udfører ventilations- og kølesystemer	\N	\N	0.4500	2026	\N	USD	\N	\N	\N	Construction	\N	.US	NY	^GSPC	LII
LIN	LIN	Linde Plc	Diverse_Basi	UK	Basi	https://www.marketscreener.com/quote/stock/LINDE-PLC-46923083/	https://finance.yahoo.com/quote/LIN?p=LIN&.tsrc=fin-srch	https://www.linde.com	Indstrielle gasser. Går stort i brint.	\N	\N	0.2500	2026	\N	USD	\N	\N	\N	Other[Basi]	7	.US	NY	^GSPC	LIN
LITE	LITE	Lumentum Holdings 	ElectrComponents	US	Tech	https://www.marketscreener.com/quote/stock/LUMENTUM-HOLDINGS-INC-23132759/	https://finance.yahoo.com/quote/LITE/	https://www.lumentum.com/	Designer og producerer optiske og fotoniske produkter til netværk, datacentre og industri	\N	\N	0.5500	2026	\N	USD	\N	AI-infrastruktur	\N	ElectrComponents	\N	.US	NY	^GSPC	LITE
LKQ	LKQ	LKQ Corp	Automotive	US	C-Di	https://www.marketscreener.com/quote/stock/LKQ-CORPORATION-40328841/	https://finance.yahoo.com/quote/LKQ?p=LKQ&.tsrc=fin-srch	https://lkqcorp.com/	Autoreservedele, nye og brugte	\N	\N	0.5000	2026	\N	USD	\N	\N	\N	Automotive	\N	.US	NY	^GSPC	LKQ
LLOY.L	LON:LLOY	Lloyds Banking Group	Bank	UK	Fina	https://www.marketscreener.com/quote/stock/LLOYDS-BANKING-GROUP-PLC-4000786/	https://finance.yahoo.com/quote/LLOY.L?p=LLOY.L&.tsrc=fin-srch	https://www.lloydsbankinggroup.com	\N	\N	\N	0.5900	2026	\N	GBX	\N	\N	\N	Bank	\N	.L	LON	^FTSE	LLOY.L
LLY	LLY	Eli Lilly	Pharma	US	Heal	https://www.marketscreener.com/quote/stock/ELI-LILLY-AND-COMPANY-13401/	https://finance.yahoo.com/quote/LLY?p=LLY&.tsrc=fin-srch	https://www.lilly.com	\N	t	\N	0.3300	2026	\N	USD	\N	\N	\N	Pharma	\N	.US	NY	^GSPC	LLY
LMT	LMT	Lockheed Martin	Defense	US	Indu	https://www.marketscreener.com/quote/stock/LOCKHEED-MARTIN-CORPORATI-13406/	\N	https://www.lockheedmartin.com	Among world's largest defense contractors. Patriot missiler og F35 jets	\N	\N	\N	\N	\N	USD	\N	\N	\N	Defense	\N	.US	NY	^GSPC	LMT
LNC	LNC	Lincoln National	Insurance	US	Fina	https://www.marketscreener.com/quote/stock/LINCOLN-NATIONAL-CORPORAT-13407/	https://finance.yahoo.com/quote/LNC?p=LNC&.tsrc=fin-srch	https://www.lincolnfinancial.com	One of top life insurance groups in US. Bundsolid, 8% udb	\N	\N	0.6000	2026	\N	USD	\N	\N	\N	Insurance	\N	.US	NY	^GSPC	LNC
LNG	LNG	Cheniere Energy	Oil&Gas	US	Ener	https://www.marketscreener.com/quote/stock/CHENIERE-ENERGY-INC-40449478/	https://finance.yahoo.com/quote/LNG?p=LNG&.tsrc=fin-srch	https://www.cheniere.com	Terminals og transport, Houston	\N	\N	0.7500	2026	\N	USD	\N	\N	\N	Oil&Gas	\N	.US	NY	^GSPC	LNG
LONN.SW	SWX:LONN	Lonza	Pharma	CH	Heal	https://www.marketscreener.com/quote/stock/LONZA-GROUP-AG-2956013/	https://finance.yahoo.com/quote/LONN.SW?p=LONN.SW&.tsrc=fin-srch	https://www.lonza.com	Contract manufacturer (medicine)	\N	\N	0.4500	2026	\N	CHF	\N	\N	\N	Pharma	\N	.SW	LON	^STOXX	LONN.SW
LOPE	LOPE	Grand Canyon Education	Media&Educ	US	C-Di	https://www.marketscreener.com/quote/stock/GRAND-CANYON-EDUCATION-IN-4772549/	https://finance.yahoo.com/quote/LOPE?p=LOPE&.tsrc=fin-srch	https://www.gce.com	Education services, graduate degree programs	\N	\N	0.5000	2026	\N	USD	\N	\N	\N	Media&Educ	\N	.US	NY	^GSPC	LOPE
LOW	LOW	Lowe's	ConstrHomes	US	C-Di	https://www.marketscreener.com/quote/stock/LOWE-S-COMPANIES-INC-13416/	https://finance.yahoo.com/quote/LOW/	https://www.lowes.com	Homebuilding	\N	\N	0.5000	2026	\N	USD	\N	\N	\N	ConstrHomes	\N	.US	NY	^GSPC	LOW
LQDE.L	LON:LQDE	iShares $ Corp Bond UCITS ETF USD (Dist)	Bond	Irland	na	https://www.justetf.com/en/etf-profile.html?query=IE00BZ036H21&groupField=index&from=search&isin=IE00BZ036H21	https://finance.yahoo.com/quote/LQDE.L?p=LQDE.L&.tsrc=fin-srch&guccounter=2	\N	\N	t	\N	0.4700	2026	\N	USD	\N	\N	\N	Other[na]	7	.L	LON	^FTSE	LQDE.L
LR.PA	EPA:LR	Legrand	Construction	FR	Indu	https://www.marketscreener.com/quote/stock/LEGRAND-16719/	\N	https://www.legrandgroup.com	Global specialist in electrical and digital building infrastructure	\N	\N	0.4000	2026	\N	EUR	\N	\N	\N	Construction	\N	.PA	LON	^FCHI	LR.PA
LRCX	LRCX	Lam Research	Semi	US	Tech	https://www.marketscreener.com/quote/stock/LAM-RESEARCH-CORPORATION-4877/	\N	https://www.lamresearch.com	Wafer processing equipment	\N	\N	0.4100	2026	\N	USD	\N	\N	\N	Semi	\N	.US	NY	^GSPC	LRCX
LSEG.L	LON:LSEG	London Stock Exchange	Services(Fina)	UK	Fina	https://www.marketscreener.com/quote/stock/LONDON-STOCK-EXCHANGE-GRO-4005918/	https://finance.yahoo.com/quote/LSEG.L/	https://www.lseg.com	\N	\N	\N	0.3500	2026	\N	GBX	\N	\N	\N	Services(Fina)	\N	.L	LON	^FTSE	LSEG.L
LTC	LTC	LTC Properties	Property	US	REIT	https://www.marketscreener.com/quote/stock/LTC-PROPERTIES-INC-13429/	https://finance.yahoo.com/quote/LTC/	https://www.ltcreit.com	50% senior housing properties, 50% skilled nursing props	\N	\N	0.5000	2026	\N	USD	\N	\N	\N	Property	\N	.US	NY	^GSPC	LTC
LULU	LULU	Lululemon Athletica	Clothing	US	C-Di	https://www.marketscreener.com/quote/stock/LULULEMON-ATHLETICA-INC-40449575/	https://finance.yahoo.com/quote/LULU?p=LULU&.tsrc=fin-srch	https://shop.lululemon.com/	Sportstøj og -tilbehør	\N	\N	0.4700	2026	\N	USD	\N	\N	\N	Clothing	\N	.US	NY	^GSPC	LULU
LUNR	LUNR	Intuitive Machines	Manuf_Special	US	Indu	https://www.marketscreener.com/quote/stock/INTUITIVE-MACHINES-INC-150801143/	https://finance.yahoo.com/quote/LUNR/	https://www.intuitivemachines.com/	Produkter og services til rumforskning, satelitter og månearbejder	\N	\N	0.3700	2026	\N	USD	\N	\N	\N	Manuf_Special	\N	.US	NY	^GSPC	LUNR
LUV	LUV	Southwest Airlines	Trpt_Airline	US	Indu	https://www.marketscreener.com/quote/stock/SOUTHWEST-AIRLINES-CO-13439/	https://www.marketscreener.com/quote/stock/SOUTHWEST-AIRLINES-CO-13439/	https://www.southwest.com	Airline	\N	\N	0.7000	2026	\N	USD	\N	\N	\N	Trpt_Airline	\N	.US	NY	^GSPC	LUV
LX	LX	LexinFintech (ADR)	Fintech	China	Fina	https://www.marketscreener.com/quote/stock/LEXINFINTECH-HOLDINGS-LTD-39085195/	https://finance.yahoo.com/quote/LX/	https://www.lexin.com	Consumer credit for folk ml 18 og 36	\N	\N	0.3300	2026	\N	USD	\N	\N	\N	Fintech	\N	.US	NY	^GSPC	LX
LXU	LXU	LSB Industries	Agro	US	Basi	https://www.marketscreener.com/quote/stock/LSB-INDUSTRIES-INC-4191936/	https://finance.yahoo.com/quote/LXU?p=LXU&.tsrc=fin-srch	https://www.lsbindustries.com	Fremstiller og sælger kemikalier til landbrug	\N	\N	0.3000	2026	\N	USD	\N	\N	\N	Agro	\N	.US	NY	^GSPC	LXU
LYC.AX	ASX:LYC	Lynas Rare Earth	Mining	AUS	Basi	https://www.marketscreener.com/quote/stock/LYNAS-RARE-EARTHS-LIMITED-6492543/	https://finance.yahoo.com/quote/LYC.AX/	https://lynasrareearths.com/	Mines in  Australia and Malaysia. Light rare earths: lanthanum, cerium, praseodymium, and neodymium. Heavy rare earth: samarium, europium, gadolinium, terbium, and dysprosium	\N	\N	0.4700	2026	\N	AUD	\N	\N	\N	Mining	\N	.AX	HKG	^HSI	LYC.AX
LYFT	LYFT	Lyft	Trpt_Other	US	Indu	https://www.marketscreener.com/quote/stock/LYFT-INC-56481539/	https://finance.yahoo.com/quote/LYFT?p=LYFT&.tsrc=fin-srch	https://www.lyft.com	Delivery and shared ride	\N	\N	0.3800	2026	\N	USD	\N	\N	\N	Trpt_Other	\N	.US	NY	^GSPC	LYFT
M	M	Macy's	Retail	US	C-St	https://www.marketscreener.com/quote/stock/MACY-S-INC-12578/	https://finance.yahoo.com/quote/M?p=M&.tsrc=fin-srch	https://www.macysinc.com	Stormagasiner	\N	\N	0.5000	2026	\N	USD	\N	\N	\N	Retail	\N	.US	NY	^GSPC	M
MA	MA	Mastercard	TechToCons	US	Tech	https://www.marketscreener.com/quote/stock/MASTERCARD-INC-17163/	https://finance.yahoo.com/quote/MA?p=MA&.tsrc=fin-srch	https://www.mastercard.com	\N	\N	\N	0.4000	2026	\N	USD	\N	\N	\N	TechToCons	\N	.US	NY	^GSPC	MA
MAC	MAC	Macerich (malls)	Property	US	REIT	https://www.marketscreener.com/quote/stock/THE-MACERICH-COMPANY-13455/	\N	https://www.macerich.com	\N	\N	\N	0.4500	2026	\N	USD	\N	\N	\N	Property	\N	.US	NY	^GSPC	MAC
THO	THO	Thor Industries (RVs)	Holiday	US	C-Di	https://www.marketscreener.com/quote/stock/THOR-INDUSTRIES-INC-14591/	\N	https://www.thorindustries.com	\N	\N	\N	0.6100	2026	\N	USD	\N	\N	\N	Holiday	\N	.US	NY	^GSPC	THO
MAERSK-B.CO	CPH:MAERSK-B	Maersk	Trpt_Ship	DK	Indu	https://www.marketscreener.com/quote/stock/A-P-MOLLER-MAERSK-A-S-1412885/	https://finance.yahoo.com/quote/MAERSK-B.CO?p=MAERSK-B.CO&.tsrc=fin-srch	https://www.maersk.com	US.børskode: AMKBF.	\N	\N	0.6500	2026	\N	DKK	\N	\N	\N	Trpt_Ship	\N	.CO	LON	^OMXC20	MAERSK-B.CO
MAIN	MAIN	Main Street Capital	BDC	US	Fina	https://www.marketscreener.com/quote/stock/MAIN-STREET-CAPITAL-CORPO-9934/	https://finance.yahoo.com/quote/MAIN?p=MAIN&.tsrc=fin-srch	https://www.mainstcapital.com	Internally managed	\N	\N	0.7000	2026	\N	USD	\N	\N	\N	BDC	\N	.US	NY	^GSPC	MAIN
MANTA.HE	HEL:MANTA	Mandatum	Investment	Finland	Fina	https://www.marketscreener.com/quote/stock/MANDATUM-OYJ-159963056/	https://finance.yahoo.com/quote/MANTA.HE?p=MANTA.HE&.tsrc=fin-srch	https://www.mandatum.fi	Spinoff of Sampo. Financial services and life insurance. Stort udb (>8%)	t	\N	0.3500	2026	\N	EUR	\N	\N	\N	Investment	\N	.HE	LON	^STOXX	MANTA.HE
MAR	MAR	Marriott Intl	Holiday	US	C-Di	https://www.marketscreener.com/quote/stock/MARRIOTT-INTERNATIONAL-I-14633490/	https://finance.yahoo.com/quote/MAR?p=MAR&.tsrc=fin-srch	https://www.marriott.com	Hoteller	\N	\N	0.5000	2026	\N	USD	\N	\N	\N	Holiday	\N	.US	NY	^GSPC	MAR
MC.PA	EPA:MC	LVMH Moët Hennesy Vuitton	Luxury	FR	C-Di	https://www.marketscreener.com/quote/stock/LVMH-4669/	https://finance.yahoo.com/quote/MC.PA?p=MC.PA&.tsrc=fin-srch	https://www.lvmh.com	\N	\N	\N	0.6000	2026	\N	EUR	\N	GRANOLA	\N	Luxury	\N	.PA	LON	^FCHI	MC.PA
MCD	MCD	McDonald's	Restaurants	US	C-Di	https://www.marketscreener.com/quote/stock/MCDONALD-S-CORPORATION-4833/	https://finance.yahoo.com/quote/MCD/	https://corporate.mcdonalds.com	Fast-food kæde	t	\N	0.7500	2026	\N	USD	\N	\N	\N	Restaurants	\N	.US	NY	^GSPC	MCD
MCHP	MCHP	Microchip	Semi	US	Tech	https://www.marketscreener.com/quote/stock/MICROCHIP-TECHNOLOGY-INC-4887/	https://finance.yahoo.com/quote/MCHP?p=MCHP&.tsrc=fin-srch	https://www.microchip.com	Design og produktion af chips	\N	\N	0.3300	2026	\N	USD	\N	\N	\N	Semi	\N	.US	NY	^GSPC	MCHP
MDB	NASDAQ:MDB	MongoDB	TechToProfs	US	Tech	https://www.marketscreener.com/quote/stock/MONGODB-INC-45064741/	https://finance.yahoo.com/quote/MDB?p=MDB&.tsrc=fin-srch	https://www.mongodb.com	Big enterprise-targeted non-relational multi-cloud database for AI-workloads	\N	\N	0.6100	2026	\N	USD	\N	\N	\N	TechToProfs	\N	.US	NY	^GSPC	MDB
MDLZ	MDLZ	Mondelez	Food	US	C-St	https://www.marketscreener.com/quote/stock/MONDELEZ-INTERNATIONAL-I-11499018/	https://finance.google.com/finance?q=NASDAQ%3AMELI&ei=slBjWsD5Fs2fswHNlqfIAQ	https://www.mondelezinternational.com	Packaged food	\N	\N	0.4200	2026	\N	USD	\N	\N	\N	Food	\N	.US	NY	^GSPC	MDLZ
MDT	MDT	Medtronic	Electronics_Medical	US	Indu	https://www.marketscreener.com/quote/stock/MEDTRONIC-PLC-20661655/	https://finance.yahoo.com/quote/MDT?p=MDT&.tsrc=fin-srch	https://www.medtronic.com	\N	\N	\N	0.3100	2026	\N	USD	\N	\N	\N	Other[Indu]	7	.US	NY	^GSPC	MDT
MELI	MELI	MercadoLibre	Retail	US	C-St	https://www.marketscreener.com/quote/stock/MERCADOLIBRE-INC-58469/	\N	https://www.mercadolibre.com	On-line marketplace inkl. fintech i Latin-Amerika	\N	\N	0.5300	2026	\N	USD	\N	\N	\N	Retail	\N	.US	NY	^GSPC	MELI
META	META	Meta Platforms (Facebook)	TechToCons	US	Tech	https://www.marketscreener.com/quote/stock/META-PLATFORMS-INC-10547141/	https://finance.yahoo.com/quote/META?p=META	https://meta.com	\N	t	\N	0.4200	2026	\N	USD	\N	Magni7	\N	TechToCons	\N	.US	NY	^GSPC	META
MFIC	MFIC	Midcap Fin Inv Corp (Apollo Invest)	BDC	US	Fina	https://www.marketscreener.com/quote/stock/MIDCAP-FINANCIAL-INVESTME-47564186/	\N	https://www.midcapfinancialic.com/#home	Debt investment. Externally managed.	t	\N	0.4500	2026	\N	USD	\N	\N	\N	BDC	\N	.US	NY	^GSPC	MFIC
MGA	MGA	Magna Intl	Automotive	CAN	C-Di	https://www.marketscreener.com/quote/stock/MAGNA-INTERNATIONAL-INC-13510/	\N	https://www.magna.com	Product capabilities which include body, chassis, exterior, seating, powertrain, active driver assistance, electronics, mechatronics, mirrors, lighting, and roof systems	\N	\N	0.6500	2026	\N	USD	\N	\N	\N	Automotive	\N	.US	NY	^GSPC	MGA
MGM	MGM	MGM Resorts Intl	Holiday	US	C-Di	https://www.marketscreener.com/quote/stock/MGM-RESORTS-INTERNATIONAL-13513/	https://finance.yahoo.com/quote/MGM?p=MGM&.tsrc=fin-srch	https://www.mgmresorts.com	Casinoer i Las Vegas og Macau	\N	\N	0.5600	2026	\N	USD	\N	\N	\N	Holiday	\N	.US	NY	^GSPC	MGM
MKL	MKL	Markel Corporation	Investment	US	Fina	https://www.marketscreener.com/quote/stock/MARKEL-GROUP-INC-13560/	\N	https://www.markel.com	\N	\N	\N	0.6300	2026	\N	USD	\N	\N	\N	Investment	\N	.US	NY	^GSPC	MKL
MLM	MLM	Martin Marietta Materials	ConstrMaterials	US	Basi	https://www.marketscreener.com/quote/stock/MARTIN-MARIETTA-MATERIALS-13564/	\N	https://www.martinmarietta.com	\N	\N	\N	0.5500	2026	\N	USD	\N	\N	\N	ConstrMaterials	\N	.US	NY	^GSPC	MLM
MMM	MMM	3M	Manuf_Big	US	Indu	https://www.marketscreener.com/quote/stock/3M-COMPANY-4836/	\N	https://www.3m.com	\N	\N	\N	0.4000	2026	\N	USD	\N	\N	\N	Manuf_Big	\N	.US	NY	^GSPC	MMM
MNDY	MNDY	monday.com	TechToProfs	Israel	Tech	https://www.marketscreener.com/quote/stock/MONDAY-COM-LTD-123529037/	https://finance.yahoo.com/quote/MNDY/	https://monday.com/	Udvikler softwareapplikationer, cloudbaserede ledelsessystemer	\N	\N	0.5000	2026	\N	USD	\N	\N	\N	TechToProfs	\N	.US	NY	^GSPC	MNDY
MNST	MNST	Monster Beverage Corporation	Food	US	C-St	https://www.marketscreener.com/quote/stock/MONSTER-BEVERAGE-CORPORAT-22497283/	https://finance.yahoo.com/quote/MNST?p=MNST&.tsrc=fin-srch	https://www.monsterbevcorp.com	Energidrik á la Red Bull	\N	\N	0.4500	2026	\N	USD	\N	\N	\N	Food	\N	.US	NY	^GSPC	MNST
MO	MO	Altria Group	Food	US	C-St	https://www.marketscreener.com/quote/stock/ALTRIA-GROUP-INC-4837/	\N	https://www.altria.com	\N	\N	\N	0.6800	2026	\N	USD	\N	\N	\N	Food	\N	.US	NY	^GSPC	MO
MOD	MOD	Modine	Electronics	US	Indu	https://www.marketscreener.com/quote/stock/MODINE-MANUFACTURING-COMP-13585/	https://finance.yahoo.com/quote/MNDY/	https://www.modine.com/	HVAC-udstyr, bla. væskekøling til datacentre	\N	\N	0.2500	2026	\N	USD	\N	AI-infrastruktur	\N	Electronics	\N	.US	NY	^GSPC	MOD
MONC.MI	BIT:MONC	Moncler	Luxury	IT	C-Di	https://www.marketscreener.com/quote/stock/MONCLER-S-P-A-15098901/	https://finance.yahoo.com/quote/MONC.MI?p=MONC.MI&.tsrc=fin-srch	https://www.moncler.com/	Under transformation til luksusmærke, specielt inden for vintertøj	t	\N	0.7000	2026	\N	EUR	\N	\N	\N	Luxury	\N	.MI	LON	^STOXX	MONC.MI
MOS	MOS	Mosaic Company	Agro	US	Basi	https://www.marketscreener.com/quote/stock/THE-MOSAIC-COMPANY-11900095/	https://finance.yahoo.com/quote/MOS?p=MOS&.tsrc=fin-srch	https://www.mosaicco.com	Potaske og gødning	\N	\N	0.4200	2026	\N	USD	\N	\N	\N	Agro	\N	.US	NY	^GSPC	MOS
MOWI.OL	OSL:MOWI	Mowi	Food	NO	C-St	https://www.marketscreener.com/quote/stock/MOWI-ASA-52035183/	https://finance.yahoo.com/quote/MOWI.OL?p=MOWI.OL&.tsrc=fin-srch	https://www.mowi.com	Laks	t	\N	0.5000	2026	\N	NOK	\N	\N	\N	Food	\N	.OL	LON	^OSEBX	MOWI.OL
MP	MP	MP Materials	Mining	US	Basi	https://www.marketscreener.com/quote/stock/MP-MATERIALS-CORP-108730348/	https://finance.yahoo.com/quote/MP/	http://www.mpmaterials.com/	Rare earths, førende US firma, støttet af regeringen	t	\N	0.5300	2026	\N	USD	\N	\N	\N	Mining	\N	.US	NY	^GSPC	MP
MPC	MPC	Marathon Petroleum	Oil&Gas	CH	Ener	https://www.marketscreener.com/quote/stock/MARATHON-PETROLEUM-CORPOR-8251813/	https://finance.yahoo.com/quote/MPC/	https://www.marathonpetroleum.com/	Refiner.  18500 ansatte.	\N	\N	0.6700	2026	\N	USD	\N	\N	\N	Oil&Gas	\N	.US	NY	^GSPC	MPC
MPLX	MPLX	MPLX LP	Oil&Gas	US	Ener	https://www.marketscreener.com/quote/stock/MPLX-LP-11799319/	\N	https://www.mplx.com	\N	\N	\N	0.7000	2026	\N	USD	\N	\N	\N	Oil&Gas	\N	.US	NY	^GSPC	MPLX
MPT	MPT	Medical Properties (hospitaler)	Property	US	REIT	https://www.marketscreener.com/quote/stock/MEDICAL-PROPERTIES-TRUST-13603/	https://finance.yahoo.com/quote/MPT/	https://www.medicalpropertiestrust.com	Verdens største hospitals-ejer	t	\N	0.4400	2026	\N	USD	\N	\N	\N	Property	\N	.US	NY	^GSPC	MPT
MPWR	MPWR	Monolithic Power Systems	Semi	US	Tech	https://www.marketscreener.com/quote/stock/MONOLITHIC-POWER-SYSTEMS--10076/	https://finance.yahoo.com/quote/MPWR	https://www.monolithicpower.com	High-performance semiconductors	\N	\N	0.3500	2026	\N	USD	\N	\N	\N	Semi	\N	.US	NY	^GSPC	MPWR
MRCY	MRCY	Mercury Systems	Defense	US	Indu	https://www.marketscreener.com/quote/stock/MERCURY-SYSTEMS-INC-10079/	https://finance.yahoo.com/quote/MRCY?p=MRCY&.tsrc=fin-srch	https://www.mrcy.com	Missilforsvarssystemer bl.a.	\N	\N	0.7000	2026	\N	USD	\N	\N	\N	Defense	\N	.US	NY	^GSPC	MRCY
MRK	MRK	Merck And Company	Pharma	US	Heal	https://www.marketscreener.com/quote/stock/MERCK-CO-INC-13611/	\N	https://www.merck.com	Lægemidler	t	\N	0.3300	2026	\N	USD	\N	\N	\N	Pharma	\N	.US	NY	^GSPC	MRK
MRNA	MRNA	Moderna	Pharma	US	Heal	https://www.marketscreener.com/quote/stock/MODERNA-INC-47437573/	https://finance.yahoo.com/quote/MRNA?p=MRNA&.tsrc=fin-srch	https://www.modernatx.com	\N	t	\N	\N	\N	\N	USD	\N	\N	t	Pharma	\N	.US	NY	^GSPC	MRNA
MRP	MRP	Millrose Properties	Property	US	REIT	https://www.marketscreener.com/quote/stock/MILLROSE-PROPERTIES-INC-182127517/	https://finance.yahoo.com/quote/MRP/	https://millroseproperties.com/	Kapital til ejendomsudviklere (home builders and land developers)	\N	\N	0.5300	2026	\N	USD	\N	\N	\N	Property	\N	.US	NY	^GSPC	MRP
MRVL	MRVL	Marvell Technology Group	Semi	US	Tech	https://www.marketscreener.com/quote/stock/MARVELL-TECHNOLOGY-GROUP--4934/	https://finance.yahoo.com/quote/MRVL?p=MRVL&.tsrc=fin-srch	https://www.marvell.com	Integrated communications and storage circuits. Største marked Kina.	\N	\N	0.4700	2026	\N	USD	\N	AI-infrastruktur	\N	Semi	\N	.US	NY	^GSPC	MRVL
MS	MS	Morgan Stanley	Bank	US	Fina	https://www.marketscreener.com/quote/stock/MORGAN-STANLEY-13654/	https://finance.yahoo.com/quote/MS?p=MS&.tsrc=fin-srch	https://www.morganstanley.com	Ikke største US-bank, men størst i verdenmht wealth-management (2023)	\N	\N	0.5000	2026	\N	USD	\N	\N	\N	Bank	\N	.US	NY	^GSPC	MS
MSDL	MSDL	Morgan Stanley Direct Lending Fund	BDC	US	Fina	https://www.marketscreener.com/quote/stock/MORGAN-STANLEY-DIRECT-LEN-164769193/	https://finance.yahoo.com/quote/MSDL/	http://www.msdl.com	Investerer i mid-market-firmaers obligationer og låner ud til kapitalfonde, der opkøber virksomheder	t	\N	0.4500	2026	\N	USD	\N	\N	\N	BDC	\N	.US	NY	^GSPC	MSDL
MSFT	NASDAQ:MSFT	Microsoft	TechToProfs	US	Tech	https://www.marketscreener.com/quote/stock/MICROSOFT-CORPORATION-4835/	https://finance.yahoo.com/quote/MSFT?p=MSFT&.tsrc=fin-srch	https://www.microsoft.com	\N	t	\N	0.7500	2026	\N	USD	\N	Magni7	\N	TechToProfs	\N	.US	NY	^GSPC	MSFT
MSTR	MSTR	Strategy (MicroStrategy )	Crypto	US	Fina	https://www.marketscreener.com/quote/stock/MICROSTRATEGY-INCORPORATE-10105/	https://finance.yahoo.com/quote/MSTR/	https://www.microstrategy.com/	Investering i bitcoins og rådgiver mht. virksomhedsudvikling	\N	\N	\N	\N	\N	USD	\N	\N	\N	Crypto	\N	.US	NY	^BTC	MSTR
MTB-PH	MTB-H	M&T Bank Fix-to-Float non-cumulative perpetual pref, Ser A	Bank	US	Fina	https://www.marketscreener.com/quote/stock/M-T-BANK-CORPORATION-136057904/	https://finance.yahoo.com/quote/MTB-PH?p=MTB-PH&.tsrc=fin-srch	https://www.mtb.com	Pr 15.12.26 LIBOR +4,02% ( SOFT +0,26%)	t	\N	0.2200	2026	\N	USD	\N	\N	\N	Bank	\N	.US	NY	^GSPC	MTB-PH
MTCH	MTCH	Match (Tinder)	TechToCons	US	Tech	https://www.marketscreener.com/quote/stock/MATCH-GROUP-INC-24949016/	\N	https://mtch.com	\N	\N	\N	0.4700	2026	\N	USD	\N	\N	\N	TechToCons	\N	.US	NY	^GSPC	MTCH
MTHH.CO	CPH:MTHH	MT Højgaard Hldg	Construction	DK	Indu	https://www.marketscreener.com/quote/stock/MT-HOJGAARD-HOLDING-A-S-56976405/	https://finance.yahoo.com/quote/MTHH.CO?p=MTHH.CO&.tsrc=fin-srch	https://www.mthh.eu	\N	t	\N	\N	\N	\N	DKK	\N	\N	\N	Construction	\N	.CO	LON	^OMXC20	MTHH.CO
MTRS.ST	STO:MTRS	Munters Group AB	Manuf_Special	SE	Indu	https://www.marketscreener.com/quote/stock/MUNTERS-GROUP-AB-34973373/	https://finance.yahoo.com/quote/MTRS.ST/	https://www.munters.com/da-dk/	Klimastyring indenfor mange forskellige industrier	\N	\N	0.3300	2026	\N	SEK	\N	\N	\N	Manuf_Special	\N	.ST	LON	^OMX	MTRS.ST
MTX.DE	ETR:MTX	MTU Aero Engines	Defense	DE	Indu	https://www.marketscreener.com/quote/stock/MTU-AERO-ENGINES-AG-470192/	https://finance.yahoo.com/quote/MTX.DE/	https://www.marketscreener.com/quote/stock/MTU-AERO-ENGINES-AG-470192/company/	Parts and service for aircraft engines, civil and military	\N	\N	0.2500	2026	\N	EUR	\N	\N	\N	Defense	\N	.DE	LON	^GDAXI	MTX.DE
MU	MU	Micron Technology	Semi	US	Tech	https://www.marketscreener.com/quote/stock/MICRON-TECHNOLOGY-INC-13639/	\N	https://www.micron.com	Design, manufacturing and marketing of memory semiconductors	\N	\N	0.3300	2026	\N	USD	\N	\N	\N	Semi	\N	.US	NY	^GSPC	MU
MUFG	MUFG	Mitsubishi UFJ Financial Group	Bank	Japan	Fina	https://www.marketscreener.com/quote/stock/MITSUBISHI-UFJ-FINANCIAL-13629/	https://finance.yahoo.com/quote/MUFG?p=MUFG&.tsrc=fin-srch	https://www.mufg.jp	Verdens 5. største bank (2020)	\N	\N	0.4400	2026	\N	USD	\N	\N	\N	Bank	\N	.US	NY	^GSPC	MUFG
MAA	MAA	Mid-America Apartment Communities	Property	US	REIT	https://www.marketscreener.com/quote/stock/MID-AMERICA-APARTMENT-COM-13452/	https://finance.yahoo.com/quote/MAA?p=MAA&.tsrc=fin-srch	https://www.maac.com/	\N	\N	\N	\N	\N	\N	USD	\N	\N	\N	Property	\N	.US	NY	^GSPC	MAA
NAT	NAT	Nordic American Tankers 	Trpt_Ship (Ener)	US	Ener	https://www.marketscreener.com/quote/stock/NORDIC-AMERICAN-TANKERS-L-13682/	https://finance.yahoo.com/quote/NAT?p=NAT&.tsrc=fin-srch	https://www.nat.bm	Olietankskibe gennem Suezkanalen	\N	\N	0.5300	2026	\N	USD	\N	\N	\N	Trpt_Ship (Ener)	\N	.US	NY	^GSPC	NAT
NATO.L	LON:NATO	Future of Defence UCITS ETF Acc (USD)	Defense	Intl	Indu	https://www.marketscreener.com/quote/etf/FUTURE-OF-DEFENCE-UCITS-E-164565936/	https://finance.yahoo.com/quote/NATO.L/	https://hanetf.com/fund/nato-future-of-defence-etf	Exposure to the companies relevant to NATO defence and cyber-def spending	t	\N	\N	\N	\N	USD	\N	\N	\N	Defense	\N	.L	LON	^FTSE	NATO.L
NBIS	NBIS	Nbius Group (Yandex)	TechToProfs	NL	Tech	https://www.marketscreener.com/quote/stock/NEBIUS-GROUP-8037501/	https://finance.yahoo.com/quote/NBIS/	https://group.nebius.com/	AI-infrastruktur: Products and services, herunder GPU clusters. Hollandsk firma, 1370 ansatte.	\N	\N	0.4500	2026	\N	USD	\N	AI-infrastruktur	\N	TechToProfs	\N	.US	NY	^GSPC	NBIS
NCC-B.ST	CPH:NCC-B	NCC	Construction	SE	Indu	https://www.marketscreener.com/quote/stock/NCC-AB-PUBL-6491591/	https://finance.yahoo.com/quote/NCC-B.ST?p=NCC-B.ST	https://www.ncc.se	60% salg 2022 i SE, 15% i DK og rest delt NO og FI	t	\N	0.2500	2026	\N	SEK	\N	\N	\N	Construction	\N	.ST	LON	^OMX	NCC-B.ST
NCNO	NCNO	nCino	TechToProfs	US	Tech	https://www.marketscreener.com/quote/stock/NCINO-INC-109581178/	https://finance.yahoo.com/quote/NCNO?p=NCNO&.tsrc=fin-srch	https://www.ncino.com	\N	\N	\N	0.7500	2026	\N	USD	\N	\N	\N	TechToProfs	\N	.US	NY	^GSPC	NCNO
NDA-FI.HE	HEL:NDA-FI	Nordea	Bank	Finland	Fina	https://www.marketscreener.com/quote/stock/NORDEA-BANK-ABP-46475557/	https://finance.yahoo.com/quote/NDA-FI.HE?p=NDA-FI.HE&.tsrc=fin-srch	https://www.nordea.com	\N	\N	\N	0.7500	2026	\N	EUR	\N	\N	\N	Bank	\N	.HE	LON	^STOXX	NDA-FI.HE
NDA-SE.ST	STO:NDA-SE	Nordea	Bank	SE	Fina	https://www.marketscreener.com/quote/stock/NORDEA-BANK-ABP-46475558/	https://finance.yahoo.com/quote/NDA-SEK.ST?p=NDA-SEK.ST	https://www.nordea.com	\N	\N	\N	0.3500	2026	\N	SEK	\N	\N	\N	Bank	\N	.ST	LON	^OMX	NDA-SE.ST
NDIA.L	LON:NDIA	iShares MSCI India UCITS ETF (USD, Acc)	Country	India	na	https://www.justetf.com/en/etf-profile.html?assetClass=class-equity&country=IN&groupField=index&from=search&isin=IE00BZCQB185#overview	\N	\N	Alternativ: IIND.L (er i GDP)	t	\N	0.6000	2026	\N	USD	\N	\N	\N	Country	\N	.L	LON	^FTSE	NDIA.L
NDSN	NDSN	Nordson Corp	Chemical	US	Indu	https://www.marketscreener.com/quote/stock/NORDSON-CORPORATION-10175/	https://finance.yahoo.com/quote/NDSN/	https://www.nordson.com	Klæbstoffer og andre polymere	\N	\N	0.4500	2026	\N	USD	\N	\N	\N	Other[Indu]	7	.US	NY	^GSPC	NDSN
NEE	NEE	NextEra Energy	Util_Rnwb	US	Util	https://www.marketscreener.com/quote/stock/NEXTERA-ENERGY-6337180/	https://finance.yahoo.com/quote/NEE?p=NEE&.tsrc=fin-srch	https://www.nexteraenergy.com	Kun clear energy (også nuclear)	\N	\N	0.3800	2026	\N	USD	\N	\N	\N	Util_Rnwb	\N	.US	NY	^GSPC	NEE
NEM	NEM	Newmont Corp	Gold	US	Basi	https://www.marketscreener.com/quote/stock/NEWMONT-CORPORATION-13711/	https://finance.yahoo.com/quote/NGT.TO?p=NGT.TO&.tsrc=fin-srch	https://www.newmont.com	NEM og Barrick (B) er største gold-miners. AEM nr. 3	\N	\N	0.3500	2026	\N	USD	\N	\N	\N	Gold	\N	.US	NY	^GSPC	NEM
NEM.DE	ETR:NEM	Nemetschek	TechToProfs	DE	Tech	https://www.marketscreener.com/quote/stock/NEMETSCHEK-SE-436349/	https://finance.yahoo.com/quote/NEM.DE/	www.nemetschek.com	Design-system til byggeri (BIM-software)	\N	\N	0.6300	2026	\N	EUR	\N	\N	\N	TechToProfs	\N	.DE	LON	^GDAXI	NEM.DE
NESN.SW	SWX:NESN	Nestle SA	Food	CH	C-St	https://www.marketscreener.com/quote/stock/NESTLE-S-A-9365334/	https://finance.yahoo.com/quote/NESN.SW?p=NESN.SW&.tsrc=fin-srch	https://www.nestle.com	\N	\N	\N	0.5800	2026	\N	CHF	\N	GRANOLA	t	Food	\N	.SW	LON	^STOXX	NESN.SW
NESTE.HE	HEL:NESTE	Neste OYJ	Rnwb(Ener)	Finland	Ener	https://www.marketscreener.com/quote/stock/NESTE-OYJ-1412495/	https://finance.yahoo.com/quote/NESTE.HE?p=NESTE.HE&.tsrc=fin-srch	https://www.neste.com	Raffinaderi(1:1 olie/rnwb) og tankstationer. Finland, EU, Americas og Baltic	\N	\N	0.5000	2026	\N	EUR	\N	\N	\N	Rnwb(Ener)	\N	.HE	LON	^STOXX	NESTE.HE
NET	NET	Cloudflare  - Class A	TechToProfs	US	Tech	https://www.marketscreener.com/quote/stock/CLOUDFLARE-INC-65956823/	\N	https://www.cloudflare.com	\N	\N	\N	0.6900	2026	\N	USD	\N	\N	\N	TechToProfs	\N	.US	NY	^GSPC	NET
NETC.CO	CPH:NETC	Netcompany	Consulting(Tech)	DK	Tech	https://www.marketscreener.com/quote/stock/NETCOMPANY-GROUP-A-S-44172535/	https://finance.yahoo.com/quote/NETC.CO?p=NETC.CO&.tsrc=fin-srch	https://www.netcompany.com	IT-services ifm. eCommerce. 60% offentlige kunder.	\N	\N	0.5000	2026	\N	DKK	\N	\N	\N	Consulting(Tech)	\N	.CO	LON	^OMXC20	NETC.CO
NEWT	NEWT	NewtekOne	Fintech	US	Fina	https://www.marketscreener.com/quote/stock/NEWTEKONE-INC-22598411/	https://finance.yahoo.com/quote/NEWT?p=NEWT&.tsrc=fin-srch	https://www.newtekone.com	Financial solutions: Newtek Bank (has bank license), Newtek Lending, Newtek Payments, Newtek Insurance, Newtek Payroll, and Newtek Technology	\N	\N	0.3200	2026	\N	USD	\N	\N	\N	Fintech	\N	.US	NY	^GSPC	NEWT
NEX.PA	EPA:NEX	Nexans	Manuf_Special	FR	Indu	https://www.marketscreener.com/quote/stock/NEXANS-4676/	https://finance.yahoo.com/quote/NEX.PA/financials?p=NEX.PA	https://www.nexans.com	Kabler	\N	\N	0.4100	2026	\N	EUR	\N	\N	\N	Manuf_Special	\N	.PA	LON	^FCHI	NEX.PA
NEXA	NEXA	Nexa Resources	Mining	Luxembourg	Basi	https://www.marketscreener.com/quote/stock/NEXA-RESOURCES-S-A-38226938/	https://finance.yahoo.com/quote/NEXA/	https://www.nexaresources.com/	Major zinc-producer (mining and smelter in Brazil and Peru).	\N	\N	0.4500	2026	\N	CAD	\N	\N	\N	Mining	\N	.US	NY	^GSPC	NEXA
NFLX	NFLX	Netflix	TechToCons	US	Tech	https://www.marketscreener.com/quote/stock/NETFLIX-INC-44292425/	\N	https://www.netflix.com	\N	\N	\N	0.3500	2026	\N	USD	\N	\N	\N	TechToCons	\N	.US	NY	^GSPC	NFLX
NGD	NGD	New Gold	Gold	CAN	Basi	https://www.marketscreener.com/quote/stock/NEW-GOLD-INC-1410992/	https://finance.yahoo.com/quote/NGD/	https://www.newgold.com/	Low-cost canadisk gold-mineselskab	\N	\N	\N	\N	\N	USD	\N	\N	\N	Gold	\N	.US	NY	^GSPC	NGD
NHC.AX	ASX:NHC	New Hope Corp	Oil&Gas	AUS	Ener	https://www.marketscreener.com/quote/stock/NEW-HOPE-CORPORATION-LIMI-6496556/	https://finance.yahoo.com/quote/NHC.AX?p=NHC.AX&.tsrc=fin-srch	https://www.newhopegroup.com.au	Kul. Salg: 60% til Japan og Taiwan (2021)	\N	\N	\N	\N	\N	AUD	\N	\N	\N	Oil&Gas	\N	.AX	HKG	^HSI	NHC.AX
NHI	NHI	National Healthcare Investors (Healthcare)	Property	US	REIT	https://www.marketscreener.com/quote/stock/NATIONAL-HEALTH-INVESTORS-13726/	\N	https://www.nhireit.com	\N	t	\N	0.5000	2026	\N	USD	\N	\N	\N	Property	\N	.US	NY	^GSPC	NHI
NHY.OL	OSL:NHY	Norsk Hydro	Mining	NO	Basi	https://www.marketscreener.com/quote/stock/NORSK-HYDRO-ASA-1413211/	https://finance.yahoo.com/quote/NHY.OL?p=NHY.OL&.tsrc=fin-srch	https://www.hydro.com	Aluminium: Produktion og trading	\N	\N	0.4500	2026	\N	NOK	\N	\N	\N	Mining	\N	.OL	LON	^OSEBX	NHY.OL
NIO	NIO	Nio	Automotive	China	C-Di	https://www.marketscreener.com/quote/stock/NIO-INC-45899628/	\N	https://www.nio.com	9866.HK	\N	\N	0.4000	2026	\N	USD	\N	\N	\N	Automotive	\N	.US	NY	^GSPC	NIO
NIU	NIU	Niu Technologies (eScooters)	Automotive	China	C-Di	https://www.marketscreener.com/quote/stock/NIU-TECHNOLOGIES-46676822/	\N	https://www.niu.com	Urban mobility	\N	\N	0.6000	2026	\N	USD	\N	\N	\N	Automotive	\N	.US	NY	^GSPC	NIU
NKE	NKE	NIKE, 	Clothing	US	C-Di	https://www.marketscreener.com/quote/stock/NIKE-INC-13739/	https://finance.yahoo.com/quote/NKE?p=NKE	https://www.nike.com	Sportstøj og accessories	\N	\N	0.6500	2026	\N	USD	\N	\N	\N	Clothing	\N	.US	NY	^GSPC	NKE
NKT.CO	CPH:NKT	NKT	Manuf_Special	DK	Indu	https://www.marketscreener.com/quote/stock/NKT-A-S-1412976/	https://finance.yahoo.com/quote/NKT.CO/financials?p=NKT.CO	https://www.nkt.dk	Kabler	\N	\N	0.6000	2026	\N	DKK	\N	\N	\N	Manuf_Special	\N	.CO	LON	^OMXC20	NKT.CO
NLY	NLY	Annaly Capital Mngt (agency)	Mortgages	US	REIT	https://www.marketscreener.com/quote/stock/ANNALY-CAPITAL-MANAGEMENT-13744/	\N	https://www.annaly.com	\N	t	\N	0.4700	2026	\N	USD	\N	\N	\N	Mortgages	\N	.US	NY	^GSPC	NLY
NLY-PI	NLY-I	Annaly Capital, Preferred Shares Series I	Mortgages	US	REIT	https://finance.yahoo.com/quote/NLY-PI?p=NLY-PI&.tsrc=fin-srch	https://finance.yahoo.com/quote/NLY-PI?p=NLY-PI&.tsrc=fin-srch	https://www.annaly.com	Call date: 30.6.24	t	\N	0.5300	2026	\N	USD	\N	\N	\N	Mortgages	\N	.US	NY	^GSPC	NLY-PI
NNN	NNN	National Retail Properties (net lease)	Property	US	REIT	https://www.marketscreener.com/quote/stock/NATIONAL-RETAIL-PROPERTIE-13759/	https://finance.yahoo.com/quote/NNN?p=NNN&.tsrc=fin-srch	https://www.nnnreit.com	Øget div i 32 år. Ligner WPC.	\N	\N	\N	\N	\N	USD	\N	\N	\N	Property	\N	.US	NY	^GSPC	NNN
NOC	NOC	Northrop Grumman	Defense	US	Indu	https://www.marketscreener.com/quote/stock/NORTHROP-GRUMMAN-CORPORAT-13763/	\N	https://www.northropgrumman.com	\N	\N	\N	0.4000	2026	\N	USD	\N	\N	\N	Defense	\N	.US	NY	^GSPC	NOC
NOD.OL	OSL:NOD	Nordic Semiconductor	Semi	NO	Tech	https://www.marketscreener.com/quote/stock/NORDIC-SEMICONDUCTOR-1413213/	https://finance.yahoo.com/quote/NOD.OL?p=NOD.OL&.tsrc=fin-srch	https://www.nordicsemi.com	\N	\N	\N	0.4500	2026	\N	NOK	\N	\N	\N	Semi	\N	.OL	LON	^OSEBX	NOD.OL
NOVN.SW	SWX:NOVN	Novartis	Pharma	CH	Heal	https://www.marketscreener.com/quote/stock/NOVARTIS-AG-9364983/	https://finance.yahoo.com/quote/NOVN.VX?p=NOVN.VX	https://www.novartis.com	\N	t	\N	0.6700	2026	\N	CHF	\N	GRANOLA	\N	Pharma	\N	.SW	LON	^STOXX	NOVN.SW
NOVO-B.CO	CPH:NOVO-B	Novo Nordisk	Pharma	DK	Heal	https://www.marketscreener.com/quote/stock/NOVO-NORDISK-A-S-1412980/	https://finance.yahoo.com/quote/NOVO-B.CO?p=NOVO-B.CO	https://www.novonordisk.com	\N	t	\N	0.5000	2026	\N	DKK	\N	GRANOLA	\N	Pharma	\N	.CO	LON	^OMXC20	NOVO-B.CO
NOW	NOW	Servicenow	TechToProfs	US	Tech	https://www.marketscreener.com/quote/stock/SERVICENOW-INC-10912979/	https://finance.yahoo.com/quote/NOW/	https://www.servicenow.com	Cloud-based solution for digital workflows. 26000 ansatte.	\N	\N	0.5000	2026	\N	USD	\N	\N	\N	TechToProfs	\N	.US	NY	^GSPC	NOW
NPN.JO	JSE:NPN	Naspers	TechToCons	Sydafrika	Tech	https://www.marketscreener.com/quote/stock/NASPERS-LIMITED-1413396/	https://finance.yahoo.com/quote/NPN.JO?p=NPN.JO&.tsrc=fin-srch	https://www.naspers.com	Consumer internet industry worldwide	\N	\N	0.4500	2026	\N	ZAR	\N	\N	\N	TechToCons	\N	.JO	Other	^DJAFK	NPN.JO
NRG	NRG	NRG Energy	Util_MixedFuel	US	Util	https://www.marketscreener.com/quote/stock/NRG-ENERGY-INC-13792/	https://finance.yahoo.com/quote/NRG?p=NRG&.tsrc=fin-srch	https://www.nrg.com	El-produktion og distr i Øst-USA og Texas (både sort og nuclear energy)	\N	\N	0.6900	2026	\N	USD	\N	AI-infrastruktur	\N	Util_MixedFuel	\N	.US	NY	^GSPC	NRG
NRJL.L	LON:NRJL	Lyxor New Energy (DR) UCITS ETF - Dist	Rnwb(Ener)	UK	Ener	https://www.lyxoretf.dk/en/instit/products/equity-etf/lyxor-new-energy-dr-ucits-etf-dist/fr0010524777/eur	\N	\N	NRJU.L er i USD	\N	\N	\N	\N	\N	GBX	\N	\N	\N	Rnwb(Ener)	\N	.L	LON	^FTSE	NRJL.L
NSIS-B.CO	CPH:NSIS-B	Novonesis (tidl. Novozymes)	Diverse_Basi	DK	Basi	https://www.marketscreener.com/quote/stock/NOVONESIS-A-S-1412985/	\N	https://www.novonesis.com/en	\N	t	\N	0.3100	2026	\N	DKK	\N	\N	\N	Other[Basi]	7	.CO	LON	^OMXC20	NSIS-B.CO
NTDOY	NTDOY	Nintendo (ADR)	Diverse_C-Di	Japan	C-Di	https://www.marketscreener.com/quote/stock/NINTENDO-CO-LTD-6491906/	https://finance.yahoo.com/quote/NTDOY/	https://www.nintendo.com	\N	\N	\N	0.8000	2026	\N	USD	\N	\N	\N	Other[C-Di]	7	.US	NY	^GSPC	NTDOY
NTES	NTES	Netease	TechToCons	China	Tech	https://www.marketscreener.com/quote/stock/NETEASE-INC-10259/	\N	https://www.neteasegames.com/m/	\N	\N	\N	0.5000	2026	\N	USD	\N	\N	\N	TechToCons	\N	.US	NY	^GSPC	NTES
NTG.CO	CPH:NTG	Nordic Transport Group	Trpt_Other	DK	Indu	https://www.marketscreener.com/quote/stock/NTG-NORDIC-TRANSPORT-GROU-59241601/	https://finance.yahoo.com/quote/NTG.CO/	https://ntg.com/	Asset-light freight services through road, rail, air, and ocean internationally	\N	\N	0.2600	2026	\N	DKK	\N	\N	\N	Trpt_Other	\N	.CO	LON	^OMXC20	NTG.CO
NTR	NTR	Nutrien	Agro	CAN	Basi	https://www.marketscreener.com/quote/stock/NUTRIEN-LTD-45013492/	https://finance.yahoo.com/quote/NTR/	https://www.nutrien.com/	Crop improvement. Biz segments: Solutions, Potash, Nitrogen, and Phosphate	\N	\N	\N	\N	\N	USD	\N	\N	\N	Agro	\N	.US	NY	^GSPC	NTR
NTR.TO	TSE:NTR	Nutrien	Agro	CAN	Basi	https://www.marketscreener.com/quote/stock/NUTRIEN-LTD-40177871/	https://finance.yahoo.com/quote/NTR.TO?p=NTR.TO&.tsrc=fin-srch	https://www.nutrien.com	Mineralsk gødning	\N	\N	0.2000	2026	\N	CAD	\N	\N	\N	Agro	\N	.TO	NY	^GSPC	NTR.TO
NU	NU	Nu Holdings 	Fintech	Brazil	Fina	https://www.marketscreener.com/quote/stock/NU-HOLDINGS-LTD-130481391/	https://finance.yahoo.com/quote/NU	https://www.nubank.com.br	Digital bank	t	\N	0.7000	2026	\N	USD	\N	\N	\N	Fintech	\N	.US	NY	^GSPC	NU
NUCL.L	LON:NUCL	VanEck Uranium and Nuclear Technologies UCITS ETF	Rnwb(Ener)	UK	Ener	https://www.marketscreener.com/quote/etf/VANECK-URANIUM-AND-NUCLEA-150391322/	https://finance.yahoo.com/quote/NUKL.DE/	https://www.vaneck.com/dk/en/investments/nuclear-etf/overview/	Indeholder både Uran-virksomheder samt store Nuclear tech som Samsung, Fuji Electric samt Mitsubishi Heavy Industries 	\N	\N	0.5500	2026	\N	USD	\N	\N	\N	Rnwb(Ener)	\N	.L	LON	^FTSE	NUCL.L
NVAX	NVAX	Novavax (protein-vaccine)	Pharma	US	Heal	https://www.marketscreener.com/quote/stock/NOVAVAX-INC-58256108/	\N	https://www.novavax.com	800 ansatte	\N	\N	0.3900	2026	\N	USD	\N	\N	\N	Pharma	\N	.US	NY	^GSPC	NVAX
NVDA	NVDA	Nvidia	Semi	US	Tech	https://www.marketscreener.com/quote/stock/NVIDIA-CORPORATION-57355629/	https://finance.yahoo.com/quote/NVDA?p=NVDA&.tsrc=fin-srch	https://www.nvidia.com	Udvikling af grafik-chips	t	\N	0.4700	2026	\N	USD	\N	Magni7;AI_Core	\N	Semi	\N	.US	NY	^GSPC	NVDA
NVGS	NVGS	Navigator Holdings	Trpt_Ship (Ener)	UK	Ener	https://www.marketscreener.com/quote/stock/NAVIGATOR-HOLDINGS-LTD-14976300/	https://finance.yahoo.com/quote/NVGS?p=NVGS&.tsrc=fin-srch	https://www.navigatorgas.com	LNG tankers	t	\N	0.4400	2026	\N	USD	\N	\N	\N	Trpt_Ship (Ener)	\N	.US	NY	^GSPC	NVGS
NWE	NWE	NorthWestern Corporation	Util_MixedFuel	US	Util	https://www.marketscreener.com/quote/stock/NORTHWESTERN-CORPORATION-3007302/	https://finance.yahoo.com/quote/NWE/profile/	https://www.northwesternenergy.com	Provides electricity and natural gas to residentia and commercial customers in northwest US.	\N	\N	0.4700	2026	\N	USD	\N	\N	\N	Util_MixedFuel	\N	.US	NY	^GSPC	NWE
NXI.PA	EPA:NXI	Nexity (residen & commerc)	Property	FR	REIT	https://www.marketscreener.com/quote/stock/NEXITY-5141/	\N	https://www.nexity.fr	Ejendomshandel Frankrig, mest nybygget	\N	\N	0.3300	2026	\N	EUR	\N	\N	\N	Property	\N	.PA	LON	^FCHI	NXI.PA
NXPI	NXPI	NXP Semiconductors N.V.	Semi	NL	Tech	https://www.marketscreener.com/quote/stock/NXP-SEMICONDUCTORS-N-V-6467512/	https://finance.yahoo.com/quote/NXPI?p=NXPI&.tsrc=fin-srch	https://www.nxp.com	Chips, 50% salg til autos	\N	\N	0.4000	2026	\N	USD	\N	\N	\N	Semi	\N	.US	NY	^GSPC	NXPI
NXST	NXST	Nexstar Media Grp	Media&Educ	US	C-Di	https://www.marketscreener.com/quote/stock/NEXSTAR-MEDIA-GROUP-INC-10298/	https://finance.yahoo.com/quote/NXST?p=NXST&.tsrc=fin-srch	https://www.nexstar.tv	Radio & TV	\N	\N	0.6000	2026	\N	USD	\N	\N	\N	Media&Educ	\N	.US	NY	^GSPC	NXST
O	O	Realty Income Corp (Retail)	Property	US	REIT	https://www.marketscreener.com/quote/stock/REALTY-INCOME-CORPORATION-13868/	https://finance.yahoo.com/quote/O?p=O&.tsrc=fin-srch	https://www.realtyincome.com	En af de største REIT-selskaber (triple-net leases)	\N	\N	0.5600	2026	\N	USD	\N	\N	\N	Property	\N	.US	NY	^GSPC	O
OBDC	OBDC	Blue Owl Capital Corp	BDC	US	Fina	https://www.marketscreener.com/quote/stock/BLUE-OWL-CAPITAL-CORPORAT-64269220/	https://finance.yahoo.com/quote/OBDC?p=OBDC&.tsrc=fin-srch	https://www.blueowlcapitalcorporation.com	Alle mulige slags lån, funds-of-funds og private equity	t	\N	\N	\N	\N	USD	\N	\N	\N	BDC	\N	.US	NY	^GSPC	OBDC
OC	OC	Owens Corning	ConstrHomes	US	C-Di	https://www.marketscreener.com/quote/stock/OWENS-CORNING-35353/	https://finance.yahoo.com/quote/OC?p=OC&.tsrc=fin-srch	https://www.owenscorning.com	Materialer: Isolering, tag og kompositter internationalt	\N	\N	0.6000	2026	\N	USD	\N	\N	\N	ConstrHomes	\N	.US	NY	^GSPC	OC
OCSL	OCSL	Oaktree Specialty Lending Corp	BDC	US	Fina	https://www.marketscreener.com/quote/stock/OAKTREE-SPECIALTY-LENDING-38197373/	https://finance.yahoo.com/quote/OCSL	https://www.oaktreespecialtylending.com	Konservativ BDC	t	\N	0.5600	2026	\N	USD	\N	\N	t	BDC	\N	.US	NY	^GSPC	OCSL
OHI	OHI	Omega Healthcare	Property	US	REIT	https://www.marketscreener.com/quote/stock/OMEGA-HEALTHCARE-INVESTOR-13890/	\N	https://www.omegahealthcare.com	Healthcare-related property	t	\N	0.4000	2026	\N	USD	\N	\N	\N	Property	\N	.US	NY	^GSPC	OHI
OKLO	OKLO	Oklo Inc.	Util_Rnwb	US	Util	https://www.marketscreener.com/quote/stock/OKLO-INC-124598202/	https://finance.yahoo.com/quote/OKLO/	https://www.oklo.com/	Clean energy production and distribution. ALso developing nuclear fuel recycling (to be fully developed 2027). 120 ansatte.	\N	\N	0.5500	2026	\N	USD	\N	AI-infrastruktur	\N	Util_Rnwb	\N	.US	NY	^GSPC	OKLO
OKTA	OKTA	Okta (securing identity)	Cybersecurity	US	Tech	https://www.marketscreener.com/quote/stock/OKTA-INC-34515216/	https://finance.yahoo.com/quote/OKTA?p=OKTA&.tsrc=fin-srch	https://www.okta.com	Peers: Okta, ZS og Crowdstrike (CRWD)	\N	\N	0.3700	2026	\N	USD	\N	\N	\N	Cybersecurity	\N	.US	NY	^GSPC	OKTA
OLP	OLP	One Liberty Properties, Inc.	Property	US	REIT	https://www.marketscreener.com/quote/stock/ONE-LIBERTY-PROPERTIES-IN-13903/	https://finance.yahoo.com/quote/OLP/	https://1liberty.com/	commercial prop.: industrial, retail, restaurant, health and fitness, and theatre properties	\N	\N	0.8000	2026	\N	USD	\N	\N	\N	Property	\N	.US	NY	^GSPC	OLP
OMC	OMC	Omnicom Group	Media&Educ	US	C-Di	https://www.marketscreener.com/quote/stock/OMNICOM-GROUP-INC-13904/	\N	https://www.omnicomgroup.com	Reklame og PR	\N	\N	0.4000	2026	\N	USD	\N	\N	\N	Media&Educ	\N	.US	NY	^GSPC	OMC
OMF	OMF	OneMain Holdings	Services(Fina)	US	Fina	https://www.marketscreener.com/quote/stock/ONEMAIN-HOLDINGS-INC-25209977/	https://finance.yahoo.com/quote/OMF/	http://www.onemainfinancial.com/	Forbrugslån til "nonprime" forbrugere. 7% udbytte. 9000 ansatte.	\N	\N	0.5000	2026	\N	USD	\N	\N	\N	Services(Fina)	\N	.US	NY	^GSPC	OMF
OMV.VI	VIE:OMV	OMV AG	Oil&Gas	Østrig	Ener	https://www.marketscreener.com/quote/stock/OMV-AG-6492022/	https://finance.yahoo.com/quote/OMV.VI/	https://www.omv.com/	Centraleuropas førende olie- og gasgruppe med aktiviteter inden for raffinering, distribution, efterforskning, produktion og kemikalier – primært i Østrig, Rumænien og Tyskland	\N	\N	0.4000	2026	\N	EUR	\N	\N	\N	Oil&Gas	\N	.VI	LON	^STOXX	OMV.VI
ON	ON	ON Semiconductor	Semi	US	Tech	https://www.marketscreener.com/quote/stock/ON-SEMICONDUCTOR-CORPORAT-10340/	\N	https://www.onsemi.com	Mange slags semis, særligt power-semiconductors	\N	\N	0.5500	2026	\N	USD	\N	\N	\N	Semi	\N	.US	NY	^GSPC	ON
ONT.L	LON:ONT	Oxford Nanopore Technologies	Healthcare	US	Heal	https://www.marketscreener.com/quote/stock/OXFORD-NANOPORE-TECHNOLOG-127643608/	https://finance.yahoo.com/quote/ONT.L?p=ONT.L&.tsrc=fin-srch	https://nanoporetech.com	Unik tech til måling af lange molekyler. Især DNA og RNA er hotte.  Børsnoteret 29.9.21.	t	\N	0.5800	2026	\N	GBX	\N	\N	\N	Healthcare	\N	.L	LON	^FTSE	ONT.L
ONTO	ONTO	Onto Innovation 	Semi	US	Tech	https://www.marketscreener.com/quote/stock/ONTO-INNOVATION-INC-10148/	https://finance.yahoo.com/quote/ONTO/	https://ontoinnovation.com/	Design, udvikling og kontrol af semicondutors	\N	\N	0.6000	2026	\N	USD	\N	\N	\N	Semi	\N	.US	NY	^GSPC	ONTO
OPRA	OPRA	Opera	TechToCons	NO	Tech	https://www.marketscreener.com/quote/stock/OPERA-LIMITED-45064808/	https://finance.yahoo.com/quote/OPRA?p=OPRA&.tsrc=fin-srch	https://www.opera.com	Web-browser	\N	\N	0.3500	2026	\N	USD	\N	\N	\N	TechToCons	\N	.US	NY	^GSPC	OPRA
OR.PA	EPA:OR	L'Oreal	Luxury	FR	C-Di	https://www.marketscreener.com/quote/stock/L-OREAL-4666/	https://finance.yahoo.com/quote/OR.PA/	http://www.loreal.com/	Verdens ledende kosmetik-firma	\N	\N	0.4400	2026	\N	EUR	\N	GRANOLA	\N	Luxury	\N	.PA	LON	^FCHI	OR.PA
ORA	ORA	Ormat Technologies	Rnwb(Ener)	US	Ener	https://www.marketscreener.com/quote/stock/ORMAT-TECHNOLOGIES-INC-40449526/	https://finance.yahoo.com/quote/ORA?p=ORA&.tsrc=fin-srch	https://www.ormat.com	Intl. developer og ejer af grønne energianlæg	\N	\N	0.7100	2026	\N	USD	\N	\N	\N	Rnwb(Ener)	\N	.US	NY	^GSPC	ORA
ORA.PA	EPA:ORA	Orange	Telecom	FR	Tele	https://www.marketscreener.com/quote/stock/ORANGE-4649/	\N	https://www.orange.com	\N	\N	\N	0.4000	2026	\N	EUR	\N	\N	\N	Telecom	\N	.PA	LON	^FCHI	ORA.PA
ORCL	ORCL	Oracle Corporation	TechToProfs	US	Tech	https://www.marketscreener.com/quote/stock/ORACLE-CORPORATION-13620698/	https://finance.yahoo.com/quote/ORCL/	https://www.oracle.com	Verden førende udbyder af software til virksomheder	\N	\N	0.3500	2026	\N	USD	\N	\N	\N	TechToProfs	\N	.US	NY	^GSPC	ORCL
ORLY	ORLY	O'Reilly Automotive	Automotive	US	C-Di	https://www.marketscreener.com/quote/stock/O-REILLY-AUTOMOTIVE-INC-10363/	https://finance.yahoo.com/quote/ORLY?p=ORLY&.tsrc=fin-srch	https://www.oreillyauto.com	Autodele og -udstyr	\N	\N	0.4400	2026	\N	USD	\N	\N	\N	Automotive	\N	.US	NY	^GSPC	ORLY
ORNBV.HE	HEL:ORNBV	Orion Oyj	Pharma	Finland	Heal	https://www.marketscreener.com/quote/stock/ORION-OYJ-1412508/	https://finance.yahoo.com/quote/ORNBV.HE?p=ORNBV.HE&.tsrc=fin-srch	https://www.orion.fi	Finlands største pharma. Kun omsætn 1 ma eur	\N	\N	0.7500	2026	\N	EUR	\N	\N	\N	Pharma	\N	.HE	LON	^STOXX	ORNBV.HE
ORSTED.CO	CPH:ORSTED	Orsted (Ørsted)	Util_Rnwb	DK	Util	https://www.marketscreener.com/quote/stock/ORSTED-A-S-28607554/	https://finance.yahoo.com/quote/ORSTED.CO?p=ORSTED.CO&.tsrc=fin-srch	https://www.orsted.com	\N	\N	\N	0.2700	2026	\N	DKK	\N	\N	t	Util_Rnwb	\N	.CO	LON	^OMXC20	ORSTED.CO
OSCR	OSCR	Oscar Health	Insurance	US	Fina	https://www.marketscreener.com/quote/stock/OSCAR-HEALTH-INC-119722488/	https://finance.yahoo.com/quote/OSCR?p=OSCR&.tsrc=fin-srch	https://www.hioscar.com	Full-stack' sundhedsforsikring, altså også levering af sundhedsydelser.  Tech-intensiv fungeren.	\N	\N	0.4500	2026	\N	USD	\N	\N	\N	Insurance	\N	.US	NY	^GSPC	OSCR
OTEX.TO	TSE:OTEX	Open Text Corporation	TechToProfs	CAN	Tech	https://www.marketscreener.com/quote/stock/OPEN-TEXT-CORPORATION-1411156/	https://finance.yahoo.com/quote/OTEX/	https://www.opentext.com/	Information management company; provides software and services	\N	\N	0.4500	2026	\N	CAD	\N	\N	\N	TechToProfs	\N	.TO	NY	^GSPC	OTEX.TO
OVV	OVV	Ovintiv	Oil&Gas	US	Ener	https://www.marketscreener.com/quote/stock/OVINTIV-INC-1409827/	https://finance.yahoo.com/quote/OVV/	http://www.ovintiv.com/	Olie & gas fra USA og Cananda.  Købte NuVista	\N	\N	0.5600	2026	\N	USD	\N	\N	\N	Oil&Gas	\N	.US	NY	^GSPC	OVV
OXY	OXY	Occidental Oil and Gas	Oil&Gas	US	Ener	https://www.marketscreener.com/quote/stock/OCCIDENTAL-PETROLEUM-CORP-13928/	https://finance.yahoo.com/quote/OXY?p=OXY&.tsrc=fin-srch	https://www.oxy.com	Houston	\N	\N	0.5600	2026	\N	USD	\N	\N	\N	Oil&Gas	\N	.US	NY	^GSPC	OXY
PACB	PACB	Pacific BioScience (PacBio)	Healthcare	US	Heal	https://www.marketscreener.com/quote/stock/PACIFIC-BIOSCIENCES-OF-CA-6797675/	\N	https://www.pacb.com	Gensekventering	t	\N	0.6300	2026	\N	USD	\N	\N	\N	Healthcare	\N	.US	NY	^GSPC	PACB
PAH3.DE	ETR:PAH3	Porsche Automobil Holding SE	Automotive	DE	C-Di	https://www.marketscreener.com/quote/stock/PORSCHE-AUTOMOBIL-HOLDING-3938612/	https://finance.yahoo.com/quote/PAH3.DE?p=PAH3.DE&.tsrc=fin-srch	https://www.porsche-se.com	Majority in Volkswagen, Audi, SEAT, SKODA, Bentley, Bugatti, Lamborghini, Porsche, Ducati, Volkswagen Commercial Vehicles, Scania, MAN as weel as VW-branded financial services (sales financing, insurance, etc.)	\N	\N	0.5000	2026	\N	EUR	\N	\N	\N	Automotive	\N	.DE	LON	^GDAXI	PAH3.DE
PANW	PANW	Palo Alto Networks	Cybersecurity	US	Tech	https://www.marketscreener.com/quote/stock/PALO-ALTO-NETWORKS-INC-11067980/	\N	https://www.paloaltonetworks.com	\N	\N	\N	0.6500	2026	\N	USD	\N	\N	\N	Cybersecurity	\N	.US	NY	^GSPC	PANW
PAR	PAR	PAR Technology	TechToProfs	US	Tech	https://www.marketscreener.com/quote/stock/PAR-TECHNOLOGY-CORPORATIO-14138/	\N	https://www.partech.com	\N	\N	\N	0.3500	2026	\N	USD	\N	\N	\N	TechToProfs	\N	.US	NY	^GSPC	PAR
PATH	PATH	UiPath	TechToProfs	US	Tech	https://www.marketscreener.com/quote/stock/UIPATH-INC-121662826/	https://finance.yahoo.com/quote/PATH?p=PATH&.tsrc=fin-srch	https://www.uipath.com	Process automation coupled with gen AI	\N	\N	0.7900	2026	\N	USD	\N	AI_Core	\N	TechToProfs	\N	.US	NY	^GSPC	PATH
PAX	PAX	Patria Investment 	Mortgages	Cayman Islands	REIT	https://www.marketscreener.com/quote/stock/PATRIA-INVESTMENTS-LIMITE-117883773/	https://finance.yahoo.com/quote/PAX?p=PAX&.tsrc=fin-srch	https://www.patria.com	Pantebreve i Latin-Amerika	\N	\N	0.4500	2026	\N	USD	\N	\N	\N	Mortgages	\N	.US	NY	^GSPC	PAX
TJX	TJX	The TJX Companies	Clothing	US	C-Di	https://www.marketscreener.com/quote/stock/THE-TJX-COMPANIES-9894794/	\N	https://www.tjx.com	\N	\N	\N	0.4500	2026	\N	USD	\N	\N	\N	Clothing	\N	.US	NY	^GSPC	TJX
PBR	PBR	Petróleo Brasileiro (Petrobras) (ADR)	Oil&Gas	Brazil	Ener	https://www.marketscreener.com/quote/stock/PETROBRAS-13939/	https://finance.yahoo.com/quote/PBR?p=PBR&.tsrc=fin-srch	https://petrobras.com.br	2 aktier pr ADR	\N	\N	0.3700	2026	\N	USD	\N	\N	\N	Oil&Gas	\N	.US	NY	^GSPC	PBR
PBR-A	PBR.A	Petrobras (pref) (ADR)	Oil&Gas	Brazil	Ener	https://www.marketscreener.com/quote/stock/PETROBRAS-13940/	https://finance.yahoo.com/quote/PBR-A?p=PBR-A&.tsrc=fin-srch	https://petrobras.com.br	Brasiliens ganske veldrevne olieselskab	\N	\N	0.4000	2026	\N	USD	\N	\N	\N	Oil&Gas	\N	.US	NY	^GSPC	PBR-A
PCTY	PCTY	Paylocity	TechToProfs	US	Tech	https://www.marketscreener.com/quote/stock/PAYLOCITY-HOLDING-CORPORA-16043784/	\N	https://www.paylocity.com	Tech provider to manage HR and payroll	\N	\N	0.4700	2026	\N	USD	\N	\N	\N	TechToProfs	\N	.US	NY	^GSPC	PCTY
PD	PD	Pagerduty 	TechToProfs	US	Tech	https://www.marketscreener.com/quote/stock/PAGERDUTY-INC-57143094/	\N	https://www.pagerduty.com	A digital operations management platform	\N	\N	0.4000	2026	\N	USD	\N	\N	\N	TechToProfs	\N	.US	NY	^GSPC	PD
PDD	PDD	Pinduoduo (TEMU)	TechToCons	China	Tech	https://www.marketscreener.com/quote/stock/PINDUODUO-INC-45049866/	https://finance.yahoo.com/quote/PDD?p=PDD&.tsrc=fin-srch	https://pddholdings.com	Bruger TEMU som deres internationale wenshop	\N	\N	0.3800	2026	\N	USD	\N	\N	\N	TechToCons	\N	.US	NY	^GSPC	PDD
PEAB-B.ST	CPH:PEAB-B	PEAB	Construction	SE	Indu	https://www.marketscreener.com/quote/stock/PEAB-AB-PUBL-6491371/	https://finance.yahoo.com/quote/PEAB-B.ST?p=PEAB-B.ST	https://www.peab.com	Entreprenør Sverige	t	\N	0.7500	2026	\N	SEK	\N	\N	\N	Construction	\N	.ST	LON	^OMX	PEAB-B.ST
PEGA	PEGA	Pegasystems	TechToProfs	US	Tech	https://www.marketscreener.com/quote/stock/PEGASYSTEMS-INC-10434/	https://finance.yahoo.com/quote/PEGA?p=PEGA&.tsrc=fin-srch	https://www.pega.com	Platform for IT, international	\N	\N	0.5000	2026	\N	USD	\N	\N	\N	TechToProfs	\N	.US	NY	^GSPC	PEGA
PEP	PEP	Pepsico	Food	US	C-St	https://www.marketscreener.com/quote/stock/PEPSICO-INC-39085159/	\N	https://www.pepsico.com	\N	\N	\N	0.6100	2026	\N	USD	\N	\N	\N	Food	\N	.US	NY	^GSPC	PEP
PFE	PFE	Pfizer	Pharma	US	Heal	https://www.marketscreener.com/quote/stock/PFIZER-INC-23365019/	\N	https://www.pfizer.com	\N	t	\N	0.4000	2026	\N	USD	\N	\N	\N	Pharma	\N	.US	NY	^GSPC	PFE
PFGC	PFGC	Performance Food Group	Distributor	US	C-St	https://www.marketscreener.com/quote/stock/PERFORMANCE-FOOD-GROUP-CO-23894480/	https://finance.yahoo.com/quote/PFGC?p=PFGC&.tsrc=fin-srch	https://www.pfgc.com	Food service til restauranter, cafeterier mm	\N	\N	0.5300	2026	\N	USD	\N	\N	\N	Other[C-St]	7	.US	NY	^GSPC	PFGC
PFLT	PFLT	PennantPark (BDC)	BDC	US	Fina	https://www.marketscreener.com/quote/stock/PENNANTPARK-FLOATING-RATE-7775545/	https://finance.yahoo.com/quote/PFLT?p=PFLT&.tsrc=fin-srch	https://www.pennantpark.com/funds/pflt/	Compared to PFLT, PNNT has a riskier loan portfolio.	\N	\N	0.4700	2026	\N	USD	\N	\N	\N	BDC	\N	.US	NY	^GSPC	PFLT
PG	PG	Procter & Gamble	Distributor	US	C-St	https://www.marketscreener.com/quote/stock/PROCTER-GAMBLE-COMPANY-4838/	\N	https://us.pg.com/	\N	t	\N	0.2800	2026	\N	USD	\N	\N	\N	Other[C-St]	7	.US	NY	^GSPC	PG
PGR	PGR	Progressive	Insurance	US	Fina	https://www.marketscreener.com/quote/stock/PROGRESSIVE-CORPORATION-13995/	\N	https://www.progressive.com	\N	\N	\N	0.4700	2026	\N	USD	\N	\N	\N	Insurance	\N	.US	NY	^GSPC	PGR
PH	PH	Parker Hannefin	Manuf_Big	US	Indu	https://www.marketscreener.com/quote/stock/PARKER-HANNIFIN-CORPORATI-40295173/	https://finance.yahoo.com/quote/PH?p=PH	https://www.parker.com	Motion and Control Technologies (til mange industrier). 55000 ansatte (2022)	\N	\N	0.2200	2026	\N	USD	\N	\N	\N	Manuf_Big	\N	.US	NY	^GSPC	PH
PHM	PHM	Pultegroup	ConstrHomes	US	C-Di	https://www.marketscreener.com/quote/stock/PULTEGROUP-INC-14003/	\N	https://www.pultegroupinc.com	Builder of single-family homes	t	\N	0.5000	2026	\N	USD	\N	\N	\N	ConstrHomes	\N	.US	NY	^GSPC	PHM
PI	PI	Impinj (PI)	Semi	US	Tech	https://www.marketscreener.com/quote/stock/IMPINJ-INC-30049795/	https://finance.yahoo.com/quote/PI/	https://www.impinj.com	RFID-mærkning af varer	\N	\N	0.7500	2026	\N	USD	\N	\N	\N	Semi	\N	.US	NY	^GSPC	PI
PII	PII	Polaris	Holiday	US	C-Di	https://www.marketscreener.com/quote/stock/POLARIS-INC-14008/	\N	https://www.polaris.com	Snowmobiles, golf carts 	\N	\N	0.2800	2026	\N	USD	\N	\N	\N	Holiday	\N	.US	NY	^GSPC	PII
PINE	PINE	Alpine Income Property Trust	Property	US	REIT	https://www.marketscreener.com/quote/stock/ALPINE-INCOME-PROPERTY-TR-76370627/	https://finance.yahoo.com/quote/PINE/	http://www.alpinereit.com/	Net leases in commercial properties	\N	\N	0.5800	2026	\N	USD	\N	\N	\N	Property	\N	.US	NY	^GSPC	PINE
PINS	PINS	Pinterest	TechToCons	US	Tech	https://www.marketscreener.com/quote/stock/PINTEREST-INC-57086058/	https://finance.yahoo.com/quote/PINS?p=PINS&.tsrc=fin-srch	https://www.pinterest.com/	\N	t	\N	0.4400	2026	\N	USD	\N	\N	\N	TechToCons	\N	.US	NY	^GSPC	PINS
PK	PK	Park Hotels & Resorts	Property	US	REIT	https://www.marketscreener.com/quote/stock/PARK-HOTELS-RESORTS-INC-40449829/	\N	https://www.pkhotelsandresorts.com	\N	\N	\N	0.3800	2026	\N	USD	\N	\N	\N	Property	\N	.US	NY	^GSPC	PK
PKX	PKX	POSCO	ConstrMaterials	Sydkorea	Basi	https://www.marketscreener.com/quote/stock/POSCO-HOLDINGS-INC-14041/	https://finance.yahoo.com/quote/PKX?p=PKX&.tsrc=fin-srch	https://www.posco-inc.com	Stålværk, men på vej ind i Lithium og Nikkel	\N	\N	0.3800	1899	\N	USD	0.2500	\N	\N	ConstrMaterials	\N	.US	NY	^GSPC	PKX
PLD	PLD	Prologis (lagerbygninger)	Property	US	REIT	https://www.marketscreener.com/quote/stock/PROLOGIS-INC-14050/	\N	https://www.prologis.com	Amazon's landlord	\N	\N	0.4500	2026	\N	USD	\N	\N	\N	Property	\N	.US	NY	^GSPC	PLD
PLNT	PLNT	Planet Fitness	Diverse_C-Di	US	C-Di	https://www.marketscreener.com/quote/stock/PLANET-FITNESS-INC-23264734/	https://finance.yahoo.com/quote/PLNT/	https://www.planetfitness.com/	Drift og franchise af fitnesscentre og -udstyr	\N	\N	0.6500	2026	\N	USD	\N	\N	\N	Other[C-Di]	\N	.US	NY	^GSPC	PLNT
PLTR	PLTR	Palantir	TechToProfs	US	Tech	https://www.marketscreener.com/quote/stock/PALANTIR-TECHNOLOGIES-INC-113108869/	https://finance.yahoo.com/quote/PLTR?p=PLTR&.tsrc=fin-srch	https://www.palantir.com	Militær og civil datamining	t	\N	0.7400	2026	\N	USD	\N	\N	\N	TechToProfs	\N	.US	NY	^GSPC	PLTR
PLUG	PLUG	Plug Power	Rnwb(Ener)	US	Ener	https://www.marketscreener.com/quote/stock/PLUG-POWER-INC-10490/	\N	https://www.plugpower.com	\N	\N	\N	0.5300	2026	\N	USD	\N	\N	\N	Rnwb(Ener)	\N	.US	NY	^GSPC	PLUG
PLUS.L	LON:PLUS	Plus500	Fintech	Israel	Fina	https://www.marketscreener.com/quote/stock/PLUS500-LTD-13705514/	https://finance.yahoo.com/quote/PLUS.L/	https://www.plus500.com/	Online trading platform til retal-investorer til CFD handel. Som eToro	\N	\N	0.3300	2026	\N	GBX	\N	\N	\N	Fintech	\N	.L	LON	^FTSE	PLUS.L
PM	PM	Philip Morris	Food	US	C-St	https://www.marketscreener.com/quote/stock/PHILIP-MORRIS-INTERNATION-2836703/	https://finance.yahoo.com/quote/PM?p=PM&.tsrc=fin-srch	https://www.pmi.com	Tobak (cigaretter)	\N	\N	0.4500	2026	\N	USD	\N	\N	\N	Food	\N	.US	NY	^GSPC	PM
PMT-PA	PMT-A	PennyMac Mortgage Investment Trust, Series A (preferred)	Mortgages	US	REIT	https://www.marketscreener.com/quote/stock/PENNYMAC-MORTGAGE-INVESTM-5481942/	https://finance.yahoo.com/quote/PMT-PA?p=PMT-PA&.tsrc=fin-srch	https://pmt.pennymac.com	\N	\N	\N	\N	\N	\N	USD	\N	\N	\N	Mortgages	\N	.US	NY	^GSPC	PMT-PA
QTCOM.HE	HEL:QTCOM	QT Group	TechToProfs	Finland	Tech	https://www.marketscreener.com/quote/stock/QT-GROUP-OYJ-30049777/	https://finance.yahoo.com/quote/QTCOM.HE?p=QTCOM.HE&.tsrc=fin-srch	https://www.qt.io	\N	t	\N	0.5000	2026	\N	EUR	\N	\N	t	TechToProfs	\N	.HE	LON	^STOXX	QTCOM.HE
PMT-PB	PMT-B	PennyMac Mortgage Investment Trust, 8.00% Series B Fix/Float Cumulative Redeemable Preferred Shares	Mortgages	US	REIT	https://finance.yahoo.com/quote/PMT-PB?p=PMT-PB&.tsrc=fin-srch	https://finance.yahoo.com/quote/PMT-PB?p=PMT-PB&.tsrc=fin-srch	https://pmt.pennymac.com	\N	\N	\N	0.3100	2026	\N	USD	\N	\N	\N	Mortgages	\N	.US	NY	^GSPC	PMT-PB
PNDORA.CO	CPH:PNDORA	Pandora	Luxury	DK	C-Di	https://www.marketscreener.com/quote/stock/PANDORA-A-S-6705882/	https://finance.yahoo.com/quote/PNDORA.CO?p=PNDORA.CO&.tsrc=fin-srch	https://www.pandoragroup.com	\N	\N	\N	0.2500	2026	\N	DKK	\N	\N	\N	Luxury	\N	.CO	LON	^OMXC20	PNDORA.CO
PNG.V	CVE:PNG	Kraken Robotics	Manuf_Special	CAN	Indu	https://www.marketscreener.com/quote/stock/KRAKEN-ROBOTICS-INC-47302425/	https://finance.yahoo.com/quote/PNG.V/	https://www.krakenrobotics.com/	Marinerobotter, til havundersøgelser, scanning mv. Også defence	\N	\N	0.7200	2026	\N	CAD	\N	\N	\N	Manuf_Special	\N	.V	NY	^GSPC	PNG.V
PODD	PODD	Insulet (insulinpumper)	Healthcare	US	Heal	https://www.marketscreener.com/quote/stock/INSULET-CORPORATION-50468/	https://finance.yahoo.com/quote/PODD?p=PODD&.tsrc=fin-srch	https://www.insulet.com	Medical devices for insulin	\N	\N	\N	\N	\N	USD	\N	\N	\N	Healthcare	\N	.US	NY	^GSPC	PODD
POWL	POWL	Powell Industries	Electronics	US	Indu	https://www.marketscreener.com/quote/stock/POWELL-INDUSTRIES-INC-10520/	https://finance.yahoo.com/quote/POWL/	http://www.powellind.com/	AI-generation relevant med customized electrical improvements	\N	\N	0.5000	2026	\N	USD	\N	AI-infrastruktur	\N	Electronics	\N	.US	NY	^GSPC	POWL
PPC	PPC	Pilgrim's pride corporation	Food	US	C-St	https://www.marketscreener.com/quote/stock/PILGRIM-S-PRIDE-CORPORATI-12243603/	\N	https://www.pilgrims.com	Kylling- og svinekød	\N	\N	0.6000	2026	\N	USD	\N	\N	\N	Food	\N	.US	NY	^GSPC	PPC
PPL.TO	TSE:PPL	Pembina Pipeline Corp. (Canada)	Oil&Gas	CAN	Ener	https://www.marketscreener.com/quote/stock/PEMBINA-PIPELINE-CORPORAT-1411251/	https://finance.yahoo.com/quote/PPL.TO?p=PPL.TO&.tsrc=fin-srch	https://www.pembina.com	Ligner Enbridge.	\N	\N	0.3500	2026	\N	CAD	\N	\N	\N	Oil&Gas	\N	.TO	NY	^GSPC	PPL.TO
PRFD.L	LON:PRFD	Invesco Preferred Shares UCITS ETF Dist (USD)	Diverse_na	Intl	na	https://etf.invesco.com/dk/institutional/en/product/invesco-preferred-shares-ucits-etf-dist/trading-information	https://finance.yahoo.com/quote/PRFD.L?p=PRFD.L&.tsrc=fin-srch	\N	\N	t	\N	0.6000	2026	\N	USD	\N	\N	\N	Diverse_na	\N	.L	LON	^FTSE	PRFD.L
PRU	PRU	Prudential Financial (preferreds)	Insurance	US	Fina	https://www.marketscreener.com/quote/stock/PRUDENTIAL-FINANCIAL-INC-14113/	https://finance.yahoo.com/quote/PRU?p=PRU&.tsrc=fin-srch	https://www.prudential.com	AIA Group vigtigste konkurrent. Der er også PUK (Prudential common stock).	\N	\N	0.3300	2026	\N	USD	\N	\N	\N	Insurance	\N	.US	NY	^GSPC	PRU
PRY.MI	BIT:PRY	Prysmian	Electronics	IT	Indu	https://www.marketscreener.com/quote/stock/PRYSMIAN-S-P-A-252187/	https://finance.yahoo.com/quote/PRY.MI?p=PRY.MI&.tsrc=fin-srch	https://prysmiancableapp.it/	Cables (power)	\N	\N	0.5500	2026	\N	EUR	\N	\N	\N	Electronics	\N	.MI	LON	^STOXX	PRY.MI
PSIX	PSIX	Power Solutions Intl	Defense	US	Indu	https://www.marketscreener.com/quote/stock/POWER-SOLUTIONS-INTERNATI-120793398/	https://finance.yahoo.com/quote/PSIX/	http://www.psiengines.com/	Emission-certified engines and power systems using clean, alternative fuels as well as gasoline and diesel options. 700 anstatte, global sales.	\N	\N	0.3500	2026	\N	USD	\N	\N	\N	Defense	\N	.US	NY	^GSPC	PSIX
PSLV	PSLV	Sprott Physical Silver Trust	Gold	US	Basi	https://www.marketscreener.com/quote/stock/SPROTT-PHYSICAL-SILVER-TR-40331237/	https://finance.yahoo.com/quote/PSLV-U.TO?p=PSLV-U.TO&.tsrc=fin-srch	https://www.sprott.com	Investerer i fysisk sølv. PSLV.TO handles på Saxo	\N	\N	0.6000	2026	\N	USD	\N	\N	\N	Gold	\N	.US	NY	^GSPC	PSLV
PSN.L	LON:PSN	Persimmon	ConstrHomes	UK	C-Di	https://www.marketscreener.com/quote/stock/PERSIMMON-PLC-4002227/	https://finance.yahoo.com/quote/PSN.L/	http://www.persimmonhomes.com/	Stor boligbygger i UK	\N	\N	0.6500	2026	\N	GBX	\N	\N	\N	ConstrHomes	\N	.L	LON	^FTSE	PSN.L
PSTG	PSTG	Pure Storage	TechToProfs	US	Tech	https://www.marketscreener.com/quote/stock/PURE-STORAGE-INC-24203395/	https://finance.yahoo.com/quote/PSTG?p=PSTG&.tsrc=fin-srch	https://www.purestorage.com	Innovative data-storage solutions	\N	\N	0.5500	2026	\N	USD	\N	AI-infrastruktur	\N	TechToProfs	\N	.US	NY	^GSPC	PSTG
PTEC.L	LON:PTEC	Playtech	Holiday	UK	C-Di	https://www.marketscreener.com/quote/stock/PLAYTECH-PLC-11002037/	https://finance.yahoo.com/quote/PTEC.L?p=PTEC.L&.tsrc=fin-srch	https://www.playtech.com	Konkurrent til Evolution	\N	\N	0.4500	2026	\N	GBX	\N	\N	\N	Holiday	\N	.L	LON	^FTSE	PTEC.L
PUB.PA	EPA:PUB	Publicis	Media&Educ	FR	C-Di	https://www.marketscreener.com/quote/stock/PUBLICIS-GROUPE-S-A-4685/	\N	https://www.publicisgroupe.com	Marketing og PR	\N	\N	0.4000	2026	\N	EUR	\N	\N	\N	Media&Educ	\N	.PA	LON	^FCHI	PUB.PA
PVH	PVH	PVH Corp (Phillips-Van Heusen)	Clothing	US	C-Di	https://www.marketscreener.com/quote/stock/PVH-CORP-11900102/	\N	https://www.pvh.com	Tøjmærker, f.eks. Kelvin Klein	t	\N	\N	\N	\N	USD	\N	\N	\N	Clothing	\N	.US	NY	^GSPC	PVH
PYPL	PYPL	PayPal Holdings	Fintech	US	Fina	https://www.marketscreener.com/quote/stock/PAYPAL-HOLDINGS-INC-23377703/	https://finance.yahoo.com/quote/PYPL/	https://www.paypal.com	Payments and banking services. Has bank license.	\N	\N	0.5500	2026	\N	USD	\N	\N	\N	Fintech	\N	.US	NY	^GSPC	PYPL
PAA	PAA	Plains All Ameriacan Pipeline	Oil&Gas	US	Ener	https://www.marketscreener.com/quote/stock/PLAINS-ALL-AMERICAN-PIPEL-13931/	https://finance.yahoo.com/quote/PAA?p=PAA&.tsrc=fin-srch	https://www.plains.com	Olie og gasrørledninger	\N	\N	0.3900	2026	\N	USD	\N	\N	\N	Oil&Gas	\N	.US	NY	^GSPC	PAA
PAAL-B.CO	CPH:PAAL-B	Per Aarsleff	Construction	DK	Indu	https://www.marketscreener.com/quote/stock/PER-AARSLEFF-HOLDING-A-S-1412992/	https://finance.yahoo.com/quote/PAAL-B.CO?p=PAAL-B.CO&.tsrc=fin-srch	https://www.aarsleff.com	DKs største entreprenør. Mest i infrastruktur.	t	\N	0.4200	2026	\N	DKK	\N	\N	\N	Construction	\N	.CO	LON	^OMXC20	PAAL-B.CO
PAAS.TO	TSE:PAAS	Pan American Silver Corp.	Mining	CAN	Basi	https://www.marketscreener.com/quote/stock/PAN-AMERICAN-SILVER-CORP-1411165/	https://finance.yahoo.com/quote/PAAS.TO/	https://panamericansilver.com/	Silver and gold mining. "The World’s Premier Silver Producer"	\N	\N	0.5000	2026	\N	CAD	\N	\N	\N	Mining	\N	.TO	NY	^GSPC	PAAS.TO
QCOM	QCOM	Qualcomm	Semi	US	Tech	https://www.marketscreener.com/quote/stock/QUALCOMM-INC-4897/	\N	https://www.qualcomm.com	27.10.25: Qualcom går ind i datacenter-markedet	\N	\N	0.5800	2026	\N	USD	\N	AI-infrastruktur	\N	Semi	\N	.US	NY	^GSPC	QCOM
QFIN	QFIN	Qfin Holdings (ADR) (tidl.: 360 Digitech, Kina: Qifu Technology)	Fintech	China	Fina	https://www.marketscreener.com/quote/stock/QIFU-TECHNOLOGY-INC-57291588/	https://finance.yahoo.com/quote/QFIN/	https://ir.360shuke.com	Låneformidler, kun i Kina	t	\N	0.5500	2026	\N	USD	\N	\N	\N	Fintech	\N	.US	NY	^GSPC	QFIN
QQ.L	LON:QQ	QinetiQ Group Plc	Defense	UK	Indu	https://www.marketscreener.com/quote/stock/QINETIQ-GROUP-PLC-9590216/	https://finance.yahoo.com/quote/QQ.L/	http://www.qinetiq.com/	Science and engineering company providing technology-based defense solutions.	\N	\N	\N	\N	\N	GBX	\N	\N	\N	Defense	\N	.L	LON	^FTSE	QQ.L
QQQE	QQQE	Direxion NASDAQ-100 Equal Weighted Index Shares	TechToProfs	US	Tech	https://www.direxion.com/product/nasdaq-100-equal-weighted-index-etf	\N	\N	Mest software (Cloud)	\N	\N	0.6800	2026	\N	USD	\N	\N	\N	TechToProfs	\N	.US	NY	^GSPC	QQQE
RACE	RACE	Ferrari	Automotive	IT	C-Di	https://www.marketscreener.com/quote/stock/FERRARI-N-V-25600249/	https://finance.yahoo.com/quote/RACE?p=RACE&.tsrc=fin-srch	https://www.ferrari.com	Røde luksusbiler	\N	\N	0.5500	2026	\N	USD	\N	\N	\N	Automotive	\N	.US	NY	^GSPC	RACE
RAMP	RAMP	LiveRamp Hldg	TechToProfs	US	Tech	https://www.marketscreener.com/quote/stock/LIVERAMP-HOLDINGS-INC-54039111/	https://finance.yahoo.com/quote/RAMP?p=RAMP&.tsrc=fin-srch	https://pmt.pennymac.com	Targeted marketing	\N	\N	0.4500	2026	\N	USD	\N	\N	\N	TechToProfs	\N	.US	NY	^GSPC	RAMP
RBLX	RBLX	Roblox Corp	TechToCons	US	Tech	https://www.marketscreener.com/quote/stock/ROBLOX-CORPORATION-117793644/	https://finance.yahoo.com/quote/RBLX?p=RBLX&.tsrc=fin-srch	https://www.corp.roblox.com	User-generated content, mostly games	\N	\N	0.6000	2026	\N	USD	\N	\N	\N	TechToCons	\N	.US	NY	^GSPC	RBLX
RBOT.L	LON:RBOT	iShares Automation & Robotics UCITS ETF (USD, Acc)	Electronics	US	Indu	https://www.ishares.com/uk/individual/en/products/284219/ishares-automation-robotics-ucits-etf-usd-acc-fund	https://finance.yahoo.com/quote/RBOT.L?p=RBOT.L&.tsrc=fin-srch	\N	Er ARKQ-analog	\N	\N	0.2500	2026	\N	USD	\N	\N	\N	Electronics	\N	.L	LON	^FTSE	RBOT.L
RDDT	RDDT	Reddit	TechToCons	US	Tech	https://www.marketscreener.com/quote/stock/REDDIT-INC-167442757/	https://finance.yahoo.com/quote/RDDT/	https://redditinc.com/	Social medieplatform	\N	\N	0.4700	2026	\N	USD	\N	\N	\N	TechToCons	\N	.US	NY	^GSPC	RDDT
REGN	REGN	Regeneron	Pharma	US	Heal	https://www.marketscreener.com/quote/stock/REGENERON-PHARMACEUTICALS-10649/	\N	https://www.regeneron.com	\N	\N	\N	0.4200	2026	\N	USD	\N	\N	\N	Pharma	\N	.US	NY	^GSPC	REGN
REMX.L	LON:REMX	VanEck Rare Earth and Strategic Metals UCITS ETF (Acc, USD)	Mining	Intl	Basi	https://www.marketscreener.com/quote/etf/VANECK-RARE-EARTH-AND-STR-127859035/	https://finance.yahoo.com/quote/REMX.L/	https://www.vaneck.com/dk/en/investments/rare-earth-etf/overview/	Globally diversified set of the largest and most liquid companies involved in the rare earth and strategic metals industry	t	\N	0.4400	2026	\N	GBX	\N	\N	\N	Mining	\N	.L	LON	^FTSE	REMX.L
REP.MC	BME:REP	Repsol YPF	Oil&Gas	ES	Ener	https://www.marketscreener.com/quote/stock/REPSOL-S-A-75044/	\N	https://www.repsol.com	\N	\N	\N	0.6500	2026	\N	EUR	\N	\N	\N	Oil&Gas	\N	.MC	LON	^STOXX	REP.MC
RHM.DE	ETR:RHM	Rheinmetal AG	Defense	DE	Indu	https://www.marketscreener.com/quote/stock/RHEINMETALL-AG-436527/	https://finance.yahoo.com/quote/RHM.DE?p=RHM.DE&.tsrc=fin-srch	https://www.rheinmetall.de	Våben og ammunition	t	\N	0.1800	2026	\N	EUR	\N	\N	\N	Defense	\N	.DE	LON	^GDAXI	RHM.DE
RI.PA	EPA:RI	Pernod Ricard	Food	FR	C-St	https://www.marketscreener.com/quote/stock/PERNOD-RICARD-4681/	https://finance.yahoo.com/quote/RI.PA?p=RI.PA&.tsrc=fin-srch	https://www.pernod-ricard.com	Premium and Prestige spirits and wines. Verdens nr 2 efter Diageo	\N	\N	0.4700	2026	\N	EUR	\N	\N	\N	Food	\N	.PA	LON	^FCHI	RI.PA
RIO.L	LON:RIO	Rio Tinto	Mining	UK	Basi	https://www.marketscreener.com/quote/stock/RIO-TINTO-PLC-9590196/	https://finance.yahoo.com/quote/RIO.L/	https://www.riotinto.com	Mineselsk., 64% af salg er jernmalm	t	\N	0.5500	2026	\N	GBX	\N	\N	\N	Mining	\N	.L	LON	^FTSE	RIO.L
RIOT	RIOT	Riot Blockchain	Crypto	US	Fina	https://www.marketscreener.com/quote/stock/RIOT-BLOCKCHAIN-INC-38481086/	https://finance.yahoo.com/quote/RIOT?p=RIOT&.tsrc=fin-srch	https://www.riotplatforms.com	Bitcoin	\N	\N	0.3500	2026	\N	USD	\N	\N	\N	Crypto	\N	.US	NY	^BTC	RIOT
RITM	RITM	Rithm Capital (tidl. New Residential)	Mortgages	US	REIT	https://www.marketscreener.com/quote/stock/RITHM-CAPITAL-CORP-18444767/	\N	https://www.rithmcap.com	Servicing Rights-business (MSR...). Minder om ABR.	t	\N	0.5800	2026	\N	USD	\N	\N	\N	Mortgages	\N	.US	NY	^GSPC	RITM
RIVN	RIVN	Rivian	Automotive	US	C-Di	https://www.marketscreener.com/quote/stock/RIVIAN-AUTOMOTIVE-INC-129226108/	https://finance.yahoo.com/quote/RIVN?p=RIVN&.tsrc=fin-srch	https://www.rivian.com	Passenger vehicles (notably pick-ups and sport utility vehicles) and commercial vehicles (electric delivery vans)	\N	\N	0.4000	2026	\N	USD	\N	\N	\N	Automotive	\N	.US	NY	^GSPC	RIVN
RKLB	RKLB	Rocket lab	Consulting(Indu)	US	Indu	https://www.marketscreener.com/quote/stock/ROCKET-LAB-USA-INC-126208072/	https://finance.yahoo.com/quote/RKLB/	https://www.rocketlabusa.com/	Designer og producerer små og mellemklasse raketter, rumfartøjer og rumfartøjskomponenter	\N	\N	0.3500	2026	\N	USD	\N	\N	\N	Other[Indu]	\N	.US	NY	^GSPC	RKLB
RL	RL	Ralph Lauren Corporation	Clothing	US	C-Di	https://www.marketscreener.com/quote/stock/RALPH-LAUREN-CORPORATION-14256/	https://finance.yahoo.com/quote/RL?p=RL	https://corporate.ralphlauren.com	Apparel, accessories etc.	\N	\N	0.4400	2026	\N	USD	\N	\N	\N	Clothing	\N	.US	NY	^GSPC	RL
RLJ-PA	RLJ-A	RLJ Lodging Trust, Series A Cumulative Pref	Property	US	REIT	https://www.marketscreener.com/quote/stock/RLJ-LODGING-TRUST-37788313/	\N	https://www.rljlodgingtrust.com	Top i PFFA. Cannot be called (but converted to commons)	\N	\N	0.7400	2026	\N	USD	\N	\N	\N	Property	\N	.US	NY	^GSPC	RLJ-PA
RMD	RMD	Resmed	Electronics_Medical	US	Indu	https://www.marketscreener.com/quote/stock/RESMED-INC-14259/	https://finance.yahoo.com/quote/RMD/profile?p=RMD	https://www.resmed.com	\N	\N	\N	0.4100	2026	\N	USD	\N	\N	\N	Other[Indu]	7	.US	NY	^GSPC	RMD
RMS.PA	EPA:RMS	Hermès	Luxury	FR	C-Di	https://www.marketscreener.com/quote/stock/HERMES-INTERNATIONAL-4657/	\N	https://www.hermes.com/index_default.html	Luksusprodukter: Tøj, lædervarer	\N	\N	0.7500	2026	\N	EUR	\N	\N	\N	Luxury	\N	.PA	LON	^FCHI	RMS.PA
RNO.PA	EPA:RNO	Renault	Automotive	FR	C-Di	https://www.marketscreener.com/quote/stock/RENAULT-4688/	\N	https://www.renaultgroup.com	\N	\N	\N	0.8000	2026	\N	EUR	\N	\N	\N	Automotive	\N	.PA	LON	^FCHI	RNO.PA
ROAD	ROAD	Construction Partners	Construction	US	Indu	https://www.marketscreener.com/quote/stock/CONSTRUCTION-PARTNERS-INC-43256783/	https://finance.yahoo.com/quote/ROAD/	http://www.constructionpartners.net/	1325 ansatte. Offentlige og private anlægsarbejder/infrastruktur, især asfaltarbejder	\N	\N	0.5000	2026	\N	USD	\N	\N	\N	Construction	\N	.US	NY	^GSPC	ROAD
ROCK-B.CO	CPH:ROCK-B	Rockwool International Class B	ConstrMaterials	DK	Basi	https://www.marketscreener.com/quote/stock/ROCKWOOL-INTERNATIONAL-A-1413002/	https://finance.yahoo.com/quote/ROCK-B.CO?p=ROCK-B.CO&.tsrc=fin-srch	https://www.rockwool.com/group/	\N	t	\N	0.2900	2026	\N	DKK	\N	\N	\N	ConstrMaterials	\N	.CO	LON	^OMXC20	ROCK-B.CO
ROG.SW	SWX:ROG	Roche	Pharma	CH	Heal	https://www.marketscreener.com/quote/stock/ROCHE-HOLDING-AG-9364975/	https://finance.yahoo.com/quote/ROG.VX?p=ROG.VX	https://www.roche.com	\N	t	\N	0.5000	2026	\N	CHF	\N	GRANOLA	\N	Pharma	\N	.SW	LON	^STOXX	ROG.SW
ROKO-B.ST	STO:ROKO-B	Röko	Investment	SE	Fina	https://www.marketscreener.com/quote/stock/ROKO-AB-184093473/	https://finance.yahoo.com/quote/ROKO-B.ST/	https://www.roko.se/	Opkøber SME.virksomheder uanset branche i Europa for at få "evigt ejerskab"	\N	\N	0.4000	2026	\N	SEK	\N	\N	\N	Investment	\N	.ST	LON	^OMX	ROKO-B.ST
ROKU	ROKU	Roku	Media&Educ	US	C-Di	https://www.marketscreener.com/quote/stock/ROKU-INC-37892974/	\N	https://www.roku.com	Connects users to streaming services	\N	\N	0.3700	2026	\N	USD	\N	\N	\N	Media&Educ	\N	.US	NY	^GSPC	ROKU
ROOT	ROOT	Root	Insurance	US	Fina	https://www.marketscreener.com/quote/stock/ROOT-INC-114338470/	https://finance.yahoo.com/quote/ROOT/	https://inc.joinroot.com/	Bil- og lejeforsikringer	\N	\N	0.3800	2026	\N	USD	\N	\N	\N	Insurance	\N	.US	NY	^GSPC	ROOT
ROST	ROST	Ross Stores	Clothing	US	C-Di	https://www.marketscreener.com/quote/stock/ROSS-STORES-INC-4927/	https://finance.yahoo.com/quote/ROST?p=ROST&.tsrc=fin-srch	https://www.rossstores.com	Apparel and home fashion stores	\N	\N	0.4000	2026	\N	USD	\N	\N	\N	Clothing	\N	.US	NY	^GSPC	ROST
RR.L	LON:RR	Rolls-Royce	Manuf_Special	UK	Indu	https://www.marketscreener.com/quote/stock/ROLLS-ROYCE-HOLDINGS-PLC-4004084/	https://finance.yahoo.com/quote/RR.L/	https://finance.yahoo.com/quote/RR.L/	Civil airspace, power systems, defense	\N	\N	0.6200	2026	\N	GBX	\N	\N	\N	Manuf_Special	\N	.L	LON	^FTSE	RR.L
RRC	RRC	Range Resources	Oil&Gas	CAN	Ener	https://www.marketscreener.com/quote/stock/RANGE-RESOURCES-CORPORATI-14288/	https://finance.yahoo.com/quote/RRC?p=RRC&.tsrc=fin-srch	https://www.rangeresources.com	Blandt største ikke-statslige nat gas-producenter i verden	\N	\N	0.7500	2026	\N	USD	\N	\N	\N	Oil&Gas	\N	.US	NY	^GSPC	RRC
RS	RS	Reliance Steel & Aluminium	Diverse_Basi	US	Basi	https://www.marketscreener.com/quote/stock/RELIANCE-STEEL-ALUMINUM-14292/	https://finance.yahoo.com/quote/RS?p=RS&.tsrc=fin-srch	https://reliance.com	Metal processing services and metal products	\N	\N	0.4500	2026	\N	USD	\N	\N	\N	Other[Basi]	7	.US	NY	^GSPC	RS
RSG	RSG	Republic Services	EnvironServices	US	Indu	https://www.marketscreener.com/quote/stock/REPUBLIC-SERVICES-INC-14296/	https://finance.yahoo.com/quote/RSG?p=RSG&.tsrc=fin-srch	https://www.republicservices.com	Affaldshåndtering. US nr 2 efter Waste Mngt (WM) og foran Waste Connections (WCN)	\N	\N	0.5500	2026	\N	USD	\N	\N	\N	Other[Indu]	7	.US	NY	^GSPC	RSG
RTX	RTX	RTX (Raytheon)	Defense	US	Indu	https://www.marketscreener.com/quote/stock/RAYTHEON-TECHNOLOGIES-COR-4840/	https://finance.yahoo.com/quote/RTX?p=RTX&.tsrc=fin-srch	https://www.rtx.com	Også aerospace	\N	\N	0.3100	2026	\N	USD	\N	\N	\N	Defense	\N	.US	NY	^GSPC	RTX
RUN	RUN	Sunrun	Rnwb(Ener)	US	Ener	https://www.marketscreener.com/quote/stock/SUNRUN-INC-23249842/	https://finance.yahoo.com/quote/RUN?p=RUN&.tsrc=fin-srch	https://www.sunrun.com	\N	t	\N	0.6500	2026	\N	USD	\N	\N	\N	Rnwb(Ener)	\N	.US	NY	^GSPC	RUN
RWAY	RWAY	Runway Growth Finance	BDC	US	Fina	https://www.marketscreener.com/quote/stock/RUNWAY-GROWTH-FINANCE-COR-128506328/	https://finance.yahoo.com/quote/RWAY/	http://www.runwaygrowth.com/	Kapital til Silicon Valley-ventures	\N	\N	0.2500	2026	\N	USD	\N	\N	\N	BDC	\N	.US	NY	^GSPC	RWAY
RWE.DE	ETR:RWE	RWE AG	Util_MixedFuel	DE	Util	https://www.marketscreener.com/quote/stock/RWE-AG-436529/	https://finance.yahoo.com/quote/RWE.DE/profile/	https://www.rwe.com	Gnerates and supplies electricity from renewable and conventional sources in Germany, the United Kingdom, rest of Europe, North America, and internationally. Også gas.	\N	\N	0.4100	2026	\N	EUR	\N	\N	\N	Util_MixedFuel	\N	.DE	LON	^GDAXI	RWE.DE
RY.TO	TSE:RY	Royal Bank of Canada	Bank	CAN	Fina	https://www.marketscreener.com/quote/stock/ROYAL-BANK-OF-CANADA-1411559/	\N	https://www.rbcroyalbank.com	\N	\N	\N	0.5000	2026	\N	CAD	\N	\N	\N	Bank	\N	.TO	NY	^GSPC	RY.TO
RYA.IR	ISE:RYA	Ryanair Hldg	Trpt_Airline	Irland	Indu	https://www.marketscreener.com/quote/stock/RYANAIR-HOLDINGS-PLC-1412410/	https://finance.yahoo.com/quote/RYA.IR?p=RYA.IR&.tsrc=fin-srch	https://www.ryanair.com	Lavpris-flyselskab	\N	\N	0.5500	2026	\N	EUR	\N	\N	\N	Trpt_Airline	\N	.IR	LON	^FTSE	RYA.IR
S	S	SentinelOne	Cybersecurity	US	Tech	https://www.marketscreener.com/quote/stock/SENTINELONE-INC-124221575/	https://finance.yahoo.com/quote/S?p=S&.tsrc=fin-srch	https://www.sentinelone.com	Higrowth	\N	\N	0.2500	2026	\N	USD	\N	\N	\N	Cybersecurity	\N	.US	NY	^GSPC	S
S63.SI	SGX:S63	Singapore Technologies Engineering	Defense	Singapore	Indu	https://www.marketscreener.com/quote/stock/SINGAPORE-TECHNOLOGIES-EN-6491153/	https://finance.yahoo.com/quote/S63.SI/	http://www.stengg.com/	Aerospace, smart city, defense and public security	\N	\N	0.4100	2026	\N	SGD	\N	\N	\N	Defense	\N	.SI	HKG	^HSI	S63.SI
SACH	SACH	Sachem Capital	Mortgages	US	REIT	https://www.marketscreener.com/quote/stock/SACHEM-CAPITAL-CORP-33969990/	\N	https://www.sachemcapitalcorp.com	Mindre virks. Kortfristede lån mod pant i fast ejendom.	\N	\N	0.5000	2026	\N	USD	\N	\N	\N	Mortgages	\N	.US	NY	^GSPC	SACH
SAF.PA	EPA:SAF	Safran	Defense	FR	Indu	https://www.marketscreener.com/quote/stock/SAFRAN-4696/	https://finance.yahoo.com/quote/SAF.PA/	http://www.safran-group.com/	Defense & aerospace. 96000 ansatte	\N	\N	0.3900	2026	\N	EUR	\N	\N	\N	Defense	\N	.PA	LON	^FCHI	SAF.PA
SAM	SAM	Boston Beer	Food	US	C-St	https://www.marketscreener.com/quote/stock/THE-BOSTON-BEER-COMPANY-14318/	\N	https://www.bostonbeer.com	Øl	\N	\N	0.4000	2026	\N	USD	\N	\N	\N	Food	\N	.US	NY	^GSPC	SAM
SAMPO.HE	CPH:SAMPO	Sampo	Insurance	Finland	Fina	https://www.marketscreener.com/quote/stock/SAMPO-OYJ-42062213/	https://finance.yahoo.com/quote/SAMPO.HE?p=SAMPO.HE	https://www.sampo.com	\N	t	\N	0.4500	2026	\N	EUR	\N	\N	\N	Insurance	\N	.HE	LON	^STOXX	SAMPO.HE
SAN.PA	EPA:SAN	Sanofi	Pharma	FR	Heal	https://www.marketscreener.com/quote/stock/SANOFI-4698/	https://finance.yahoo.com/quote/SAN.PA?p=SAN.PA&.tsrc=fin-srch	https://www.sanofi.com	Pharma	t	\N	0.6300	2026	\N	EUR	\N	GRANOLA	t	Pharma	\N	.PA	LON	^FCHI	SAN.PA
SAP.DE	ETR:SAP	SAP	TechToProfs	DE	Tech	https://www.marketscreener.com/quote/stock/SAP-SE-436555/	https://finance.yahoo.com/quote/SAP.DE?p=SAP.DE&.tsrc=fin-srch	https://www.sap.com	Enterprise Mngt Systems	\N	\N	0.3500	2026	\N	EUR	\N	GRANOLA	\N	TechToProfs	\N	.DE	LON	^GDAXI	SAP.DE
SAR	SAR	Sarotoga Investment Corp. (BDC)	BDC	US	Fina	https://www.marketscreener.com/quote/stock/SARATOGA-INVESTMENT-CORP-4892586/	https://finance.yahoo.com/quote/SAR	https://www.saratogainvestmentcorp.com/	Manages CLOs	t	\N	0.2500	2026	\N	USD	\N	\N	\N	BDC	\N	.US	NY	^GSPC	SAR
SBAC	SBAC	SBA Communications (towers)	Property	US	REIT	https://www.marketscreener.com/quote/stock/SBA-COMMUNICATIONS-CORPOR-33339190/	\N	https://www.sbasite.com	\N	\N	\N	0.5500	2026	\N	USD	\N	\N	\N	Property	\N	.US	NY	^GSPC	SBAC
SBLK	SBLK	Star Bulk Carriers Corp	Trpt_Ship	Greece	Indu	https://www.marketscreener.com/quote/stock/STAR-BULK-CARRIERS-CORP-28710714/	https://finance.yahoo.com/quote/SBLK?p=SBLK&.tsrc=fin-srch	https://www.starbulk.com	Major bulks (iron ore, coal and grain), and minor bulks (bauxite, fertilizers and steel)	\N	\N	0.5000	2026	\N	USD	\N	\N	\N	Trpt_Ship	\N	.US	NY	^GSPC	SBLK
SBRA	SBRA	Sabra Health Care	Property	US	REIT	https://www.marketscreener.com/quote/stock/SABRA-HEALTH-CARE-REIT-I-6844461/	\N	https://www.sabrahealth.com	Nursing facilities	t	\N	0.3800	2026	\N	USD	\N	\N	\N	Property	\N	.US	NY	^GSPC	SBRA
SCATC.OL	OSL:SCATC	Scatec	Rnwb(Ener)	NO	Ener	https://www.marketscreener.com/quote/stock/SCATEC-ASA-18138342/	https://finance.yahoo.com/quote/SSO.OL?p=SSO.OL&.tsrc=fin-srch	https://www.scatecsolar.com	Til 2020: Scatec Solar	t	\N	0.3700	2026	\N	NOK	\N	\N	\N	Rnwb(Ener)	\N	.OL	LON	^OSEBX	SCATC.OL
SCCO	SCCO	Southern Copper Co.	Mining	US	Basi	https://www.marketscreener.com/quote/stock/SOUTHERN-COPPER-CORPORATI-40449537/	\N	https://www.southerncoppercorp.com	\N	\N	\N	0.3700	2026	\N	USD	\N	\N	\N	Mining	\N	.US	NY	^GSPC	SCCO
SCHW	SCHW	Charles Schwab	Services(Fina)	US	Fina	https://www.marketscreener.com/quote/stock/CHARLES-SCHWABB-9603993/	\N	https://www.schwab.com	Børsmægler og bank	\N	\N	0.6000	2026	\N	USD	\N	\N	\N	Services(Fina)	\N	.US	NY	^GSPC	SCHW
SCMN.SW	SWX:SCMN	Swisscom	Telecom	CH	Tele	https://www.marketscreener.com/quote/stock/SWISSCOM-AG-2955930/	https://finance.yahoo.com/quote/SCMN.SW?p=SCMN.SW&.tsrc=fin-srch	https://www.swisscom.com	\N	\N	\N	0.5000	2026	\N	CHF	\N	\N	\N	Telecom	\N	.SW	LON	^STOXX	SCMN.SW
SDF.DE	ETR:SDF	K+S	Agro	DE	Basi	https://www.marketscreener.com/quote/stock/K-S-AG-8586280/	https://finance.yahoo.com/quote/SDF.DE?p=SDF.DE&.tsrc=fin-srch	https://www.k-plus-s.com	Salt og potaske	\N	\N	0.4000	2026	\N	EUR	\N	\N	\N	Agro	\N	.DE	LON	^GDAXI	SDF.DE
SDZ.SW	SWX:SDZ	Sandoz	Pharma	CH	Heal	https://www.marketscreener.com/quote/stock/SANDOZ-GROUP-AG-160016887/	https://finance.yahoo.com/quote/SDZ.SW?p=SDZ.SW&.tsrc=fin-srch	https://www.sandoz.com	Novartis udskilte i  okt 2023 sine generiske aktiviteter i Sandoz	t	\N	\N	\N	\N	CHF	\N	\N	\N	Pharma	\N	.SW	LON	^STOXX	SDZ.SW
SE	SE	Sea 	TechToCons	Singapore	Tech	https://www.marketscreener.com/quote/stock/SEA-LIMITED-38150303/	\N	https://www.sea.com	Kombi af Amazon-Activision-Paypal	\N	\N	0.4400	2026	\N	USD	\N	\N	\N	TechToCons	\N	.US	NY	^GSPC	SE
SEB-A.ST	STO:SEB-A	Skandinaviska Enskilda Banken	Bank	SE	Fina	https://www.marketscreener.com/quote/stock/ENSKILDA-BANKEN-6491107/	https://finance.yahoo.com/quote/SEB-A.ST?p=SEB-A.ST&.tsrc=fin-srch	https://seb.se	\N	t	\N	0.4000	2026	\N	SEK	\N	\N	\N	Bank	\N	.ST	LON	^OMX	SEB-A.ST
SEDG	SEDG	SolarEdge	Rnwb(Indu)	Israel	Indu	https://www.marketscreener.com/quote/stock/SOLAREDGE-TECHNOLOGIES-IN-21452890/	\N	https://www.solaredge.com	Invertere, batterier, styring af solceller	t	\N	0.4500	2026	\N	USD	\N	\N	\N	Rnwb(Indu)	\N	.US	NY	^GSPC	SEDG
SFL	SFL	SFL Corp (Ship Finance International)	Trpt_Ship	US	Indu	https://www.marketscreener.com/quote/stock/SFL-CORPORATION-LTD-14366/	https://finance.yahoo.com/quote/SFL?p=SFL&.tsrc=fin-srch	https://www.sflcorp.com	\N	\N	\N	0.5500	2026	\N	USD	\N	\N	\N	Trpt_Ship	\N	.US	NY	^GSPC	SFL
SFM	SFM	Sprouts Farmers Market	Retail	US	C-St	https://www.marketscreener.com/quote/stock/SPROUTS-FARMERS-MARKET-IN-13792498/	https://finance.yahoo.com/quote/SFM?p=SFM&.tsrc=fin-srch	https://www.sprouts.com	natural and organic food retailer	\N	\N	0.4000	2026	\N	USD	\N	\N	\N	Retail	\N	.US	NY	^GSPC	SFM
SFTBY	SFTBY	Softbank Group Corp (ADR)	Investment	US	Fina	https://www.marketscreener.com/quote/stock/SOFTBANK-GROUP-CORP-120791974/	https://finance.yahoo.com/quote/9984.T/	https://group.softbank/en	SoftBank Group Corp is a holding company comprising  "Investment Business" of Holding Companies (e.g. telecom in Japan and abroad), SoftBank Vision Funds, SoftBank, Arm, and Other segments	\N	\N	0.4500	2026	\N	USD	0.5000	\N	\N	Investment	\N	.US	NY	^GSPC	SFTBY
SGO.PA	EPA:SGO	Saint-Gobain	ConstrMaterials	FR	Basi	https://www.marketscreener.com/quote/stock/COMPAGNIE-DE-SAINT-GOBAIN-4697/	\N	https://www.saint-gobain.com	\N	\N	\N	0.5800	2026	\N	EUR	\N	\N	\N	ConstrMaterials	\N	.PA	LON	^FCHI	SGO.PA
SGOL	SGOL	Guld, metallisk	Gold	US	Basi	https://www.etf.com/SGOL	https://finance.yahoo.com/quote/SGOL?p=SGOL&.tsrc=fin-srch	\N	Investerer i fysisk guld (boullion gold)	\N	\N	0.3000	2026	\N	USD	\N	\N	\N	Gold	\N	.US	NY	^GSPC	SGOL
SHB-A.ST	STO:SHB-A	Svenska Handelsbanken	Bank	SE	Fina	https://www.marketscreener.com/quote/stock/SVENSKA-HANDELSBANKEN-AB-22252916/	https://finance.yahoo.com/quote/SHB-A.ST?p=SHB-A.ST&.tsrc=fin-srch	https://www.handelsbanken.com	Ledende svensk erhvervs-bank	t	\N	0.3000	2026	\N	SEK	\N	\N	\N	Bank	\N	.ST	LON	^OMX	SHB-A.ST
SHEL.L	LON:SHEL	Shell	Oil&Gas	UK	Ener	https://www.marketscreener.com/quote/stock/SHELL-PLC-130945922/	https://finance.yahoo.com/quote/RDSB.L?p=RDSB.L&.tsrc=fin-srch	https://shell.com	Ingen udbytteskat i UK	t	\N	0.4500	2026	\N	GBX	\N	\N	\N	Oil&Gas	\N	.L	LON	^FTSE	SHEL.L
SHL.DE	ETR:SHL	Siemens Healthineers	Healthcare	DE	Heal	https://www.marketscreener.com/quote/stock/SIEMENS-HEALTHINEERS-AG-42379342/	https://finance.yahoo.com/quote/SHL.DE/	https://www.siemens-healthineers.com	SEMHF og SMMNY	\N	\N	0.4000	2026	\N	EUR	\N	\N	\N	Healthcare	\N	.DE	LON	^GDAXI	SHL.DE
SHLS	SHLS	Shoals Technologies	Rnwb(Indu)	US	Indu	https://www.marketscreener.com/quote/stock/SHOALS-TECHNOLOGIES-GROUP-118138631/	https://finance.yahoo.com/quote/SHLS?p=SHLS&.tsrc=fin-srch	https://www.shoals.com	Electrical balance of system (EBOS) solutions and components. 700 ansatte.	\N	\N	0.4700	2026	\N	USD	\N	\N	\N	Rnwb(Indu)	\N	.US	NY	^GSPC	SHLS
SHW	SHW	Sherwin-Williams (paint)	Manuf_Special	US	Indu	https://www.marketscreener.com/quote/stock/THE-SHERWIN-WILLIAMS-COMP-14390/	\N	https://www.sherwin-williams.com	31.3.21: Split 3.1	\N	\N	0.5800	2026	\N	USD	\N	\N	\N	Manuf_Special	\N	.US	NY	^GSPC	SHW
SIE.DE	ETR:SIE	Siemens	Manuf_Big	DE	Indu	https://www.marketscreener.com/quote/stock/SIEMENS-AG-56358595/	\N	https://www.siemens.de	\N	t	\N	\N	\N	\N	EUR	\N	\N	\N	Manuf_Big	\N	.DE	LON	^GDAXI	SIE.DE
SIG	SIG	Signet Jewelers	Luxury	US	C-Di	https://www.marketscreener.com/quote/stock/SIGNET-JEWELERS-LIMITED-14394/	https://finance.yahoo.com/quote/SIG?p=SIG&.tsrc=fin-srch	https://www.signetjewelers.com/our-home/default.aspx	\N	\N	\N	0.7400	2026	\N	USD	\N	\N	\N	Luxury	\N	.US	NY	^GSPC	SIG
SINCH.ST	STO:SINCH	Sinch AB	TechToProfs	SE	Tech	https://www.marketscreener.com/quote/stock/SINCH-AB-PUBL-54785943/	https://finance.yahoo.com/quote/SINCH.ST?p=SINCH.ST&.tsrc=fin-srch	https://www.sinch.com	Cloud-computing service	t	\N	0.3500	2026	\N	SEK	\N	\N	\N	TechToProfs	\N	.ST	LON	^OMX	SINCH.ST
SJM	SJM	JM Smucker	Food	US	C-St	https://www.marketscreener.com/quote/stock/THE-JM-SMUCKER-COMPANY-14400/	\N	https://www.jmsmucker.com	\N	\N	\N	0.3500	2026	\N	USD	\N	\N	\N	Food	\N	.US	NY	^GSPC	SJM
SKA-B.ST	CPH:SKA-B	Skanska	Construction	SE	Indu	https://www.marketscreener.com/quote/stock/SKANSKA-AB-6491108/	https://finance.yahoo.com/quote/SKA-B.ST?p=SKA-B.ST	https://www.skanska.com	\N	t	\N	\N	\N	\N	SEK	\N	\N	\N	Construction	\N	.ST	LON	^OMX	SKA-B.ST
SKF-B.ST	STO:SKF-B	SKF AB Class B	Manuf_Special	SE	Indu	https://www.marketscreener.com/quote/stock/AB-SKF-6493347/	https://finance.yahoo.com/quote/SKF-B.ST/	https://www.skf.com/	Products and services on bearings and units, seals, lubrication systems, condition monitoring. Including robots.	\N	\N	0.3500	2026	\N	SEK	\N	\N	\N	Manuf_Special	\N	.ST	LON	^OMX	SKF-B.ST
SKT	SKT	Tanger Factory Outlet	Property	US	REIT	https://www.marketscreener.com/quote/stock/TANGER-INC-14407/	\N	https://www.tanger.com	Outlet shopping centers	\N	\N	0.2100	2026	\N	USD	\N	\N	\N	Property	\N	.US	NY	^GSPC	SKT
SLB	SLB	Schlumberger	Oil&Gas	US	Ener	https://www.marketscreener.com/quote/stock/SCHLUMBERGER-LIMITED-14411/	https://finance.yahoo.com/quote/SLB/	https://www.slb.com/	Teknologi til energiindustri (6,7 mia/20% i USA, 2023)	\N	\N	0.6700	2026	\N	USD	\N	\N	\N	Oil&Gas	\N	.US	NY	^GSPC	SLB
SLP	SLP	Simulations Plus, Inc.	Healthcare	US	Heal	https://www.marketscreener.com/quote/stock/SIMULATIONS-PLUS-INC-771786/	https://finance.yahoo.com/quote/SLP/	http://www.simulations-plus.com/	Softwareløsninger ifm. udvikling af lægemidler 	\N	\N	\N	\N	\N	USD	\N	\N	\N	Healthcare	\N	.US	NY	^GSPC	SLP
SLP.L	LON:SLP	Sylvania Platinum Ltd	Mining	Sydafrika	Basi	https://www.marketscreener.com/quote/stock/SYLVANIA-PLATINUM-LIMITED-7671108/	https://finance.yahoo.com/quote/SLP.L/	http://www.sylvaniaplatinum.com/	Platin, palladium og rhodium i sydafrikanske miner	\N	\N	0.4000	2026	\N	GBX	\N	\N	\N	Mining	\N	.L	LON	^FTSE	SLP.L
SMCI	SMCI	Super Micro Computer	TechToProfs	US	Tech	https://www.marketscreener.com/quote/stock/SUPER-MICRO-COMPUTER-INC-45456111/	https://finance.yahoo.com/quote/SMCI?p=SMCI&.tsrc=fin-srch	https://www.supermicro.com	Servers til hi-end-computing	t	\N	0.7500	2026	\N	USD	\N	\N	\N	TechToProfs	\N	.US	NY	^GSPC	SMCI
SMG	SMG	Scotts Miracle-Gro Comp	Agro	US	Basi	https://www.marketscreener.com/quote/stock/THE-SCOTTS-MIRACLE-GRO-CO-40246792/	https://finance.yahoo.com/quote/SMG?p=SMG&.tsrc=fin-srch	https://www.scottsmiraclegro.com	Hydroponisk og traditionelt havebrug	\N	\N	0.4500	2026	\N	USD	\N	\N	\N	Agro	\N	.US	NY	^GSPC	SMG
SMH.L	LON:SMH	VanEck Vectors Semiconductor UCITS ETF (USD)	Semi	UK	Tech	https://www.vaneck.com/dk/en/etf/equity/smh/overview?country=dk&audience=pi	https://finance.yahoo.com/quote/SMH.L?p=SMH.L&.tsrc=fin-srch	\N	\N	\N	\N	0.6000	2026	\N	USD	\N	\N	\N	Semi	\N	.L	LON	^FTSE	SMH.L
SMMT	SMMT	Summit Therapeutics	Pharma	US	Heal	https://www.marketscreener.com/quote/stock/SUMMIT-THERAPEUTICS-INC-21452860/	https://finance.yahoo.com/quote/SMMT/	http://www.smmttx.com/	105 ansatte. Cancer-udvikling, inkl. licenser fra Akeso. Ligner Genmab.	\N	\N	0.5000	2026	\N	USD	\N	\N	\N	Pharma	\N	.US	NY	^GSPC	SMMT
SMR	SMR	NuScale Power Corporation	Util_Rnwb	US	Util	https://www.marketscreener.com/quote/stock/NUSCALE-POWER-CORPORATION-137238735/	https://finance.yahoo.com/quote/SMR/	https://www.nuscalepower.com/en	Atomkraft, små modulære reaktorer	\N	\N	0.2800	2026	\N	USD	\N	\N	\N	Util_Rnwb	\N	.US	NY	^GSPC	SMR
SMSN.L	LON:BC94	Samsung Electronics	ElectrComponents	Sydkorea	Tech	https://www.marketscreener.com/quote/stock/SAMSUNG-ELECTRONICS-CO--4000986/	https://finance.yahoo.com/quote/BC94.L/profile?p=BC94.L	https://www.samsung.com	SMSN.L (MktScr) = BC94.L (GF)	\N	\N	0.5800	2026	\N	GBX	\N	\N	\N	ElectrComponents	\N	.L	LON	^FTSE	SMSN.L
SN.L	LON:SN	Smith & Nephew Plc	Healthcare	UK	Heal	https://www.marketscreener.com/quote/stock/SMITH-NEPHEW-PLC-9590181/company/	https://www.marketscreener.com/quote/stock/SMITH-NEPHEW-PLC-9590181/	https://www.smith-nephew.com/en	Medical products and equipments	\N	\N	0.4200	2026	\N	GBX	\N	\N	\N	Healthcare	\N	.L	LON	^FTSE	SN.L
SNAP	SNAP	SNAP 	TechToCons	US	Tech	https://www.marketscreener.com/quote/stock/SNAP-INC-34091150/	\N	https://www.snap.com	\N	\N	\N	0.4400	2026	\N	USD	\N	\N	\N	TechToCons	\N	.US	NY	^GSPC	SNAP
SNDK	SNDK	Sandisk Corp	ElectrComponents	US	Tech	https://www.marketscreener.com/quote/stock/SANDISK-CORPORATION-182801077/	https://finance.yahoo.com/quote/SNDK/	https://www.sandisk.com/	Flash memory	\N	\N	0.2700	2026	\N	USD	\N	\N	\N	ElectrComponents	\N	.US	NY	^GSPC	SNDK
SNI.OL	OSL:SNI	Stolt-Nielsen	Trpt_Ship	Bermuda	Indu	https://www.marketscreener.com/quote/stock/STOLT-NIELSEN-LIMITED-1413281/	https://finance.yahoo.com/quote/SNI.OL?p=SNI.OL&.tsrc=fin-srch	https://www.stolt-nielsen.com	Integrated infrastructure company: Bulk-liquid, chemicals, edible oils and LNG logistics (terminals, containers, and tanker vessels) plus land-based aquaculture	\N	\N	\N	\N	\N	NOK	\N	\N	\N	Trpt_Ship	\N	.OL	LON	^OSEBX	SNI.OL
SNOW	SNOW	Snowflake	TechToProfs	US	Tech	https://www.marketscreener.com/quote/stock/SNOWFLAKE-INC-112440376/	https://finance.yahoo.com/quote/SNOW?p=SNOW&.tsrc=fin-srch	https://www.snowflake.com	Data warehousing	\N	\N	0.5000	2026	\N	USD	\N	\N	\N	TechToProfs	\N	.US	NY	^GSPC	SNOW
SNPS	SNPS	Synopsys	TechToProfs	US	Tech	https://www.marketscreener.com/quote/stock/SYNOPSYS-INC-4908/	https://finance.yahoo.com/quote/SNPS?p=SNPS&.tsrc=fin-srch	https://www.synopsys.com	Software til chip-design og -verifikation. Køber Ansys (ANSS) 2025h1	\N	\N	0.7000	2026	\N	USD	\N	\N	\N	TechToProfs	\N	.US	NY	^GSPC	SNPS
SO	SO	Southern Company	Util_MixedFuel	US	Util	https://www.marketscreener.com/quote/stock/SOUTHERN-COMPANY-14441/	https://finance.yahoo.com/quote/SO/	https://www.southerncompany.com	Generation, transmission, and distribution of electricity and gas. Partnerskab med Microsoft om 3 centre	\N	\N	0.6300	2026	\N	USD	\N	\N	\N	Util_MixedFuel	\N	.US	NY	^GSPC	SO
SOFI	SOFI	SoFi Technologies	Fintech	US	Fina	https://www.marketscreener.com/quote/stock/SOFI-TECHNOLOGIES-INC-115884899/	https://finance.yahoo.com/quote/SOFI/	http://www.sofi.com/	Fintech med speciale i personlige lån til folk med høj kreditværdighed. Har bank-licens og modtager derfor indlån. 5000 absatte, Has bank license.	\N	\N	0.4500	2026	\N	USD	\N	\N	\N	Fintech	\N	.US	NY	^GSPC	SOFI
SOLV	SOLV	Solventum Corporation	Healthcare	US	Heal	https://www.marketscreener.com/quote/stock/SOLVENTUM-CORPORATION-167578502/	https://finance.yahoo.com/quote/SOLV/	https://www.solventum.com/en-us/home/	Udvikler og sælger instrumenter til medicinsk brug samt software til hospitaler ol.	\N	\N	0.2800	2026	\N	USD	\N	\N	\N	Healthcare	\N	.US	NY	^GSPC	SOLV
SONY	SONY	Sony	Electronics	US	Indu	https://www.marketscreener.com/quote/stock/SONY-GROUP-CORPORATION-14432/	\N	https://www.sony.com/ja/	Elecatronics and entertainment products	\N	\N	0.5000	2026	\N	USD	\N	\N	\N	Electronics	\N	.US	NY	^GSPC	SONY
SOUN	SOUN	SoundHound AI, 	Consulting(Tech)	US	Tech	https://www.marketscreener.com/quote/stock/SOUNDHOUND-AI-INC-137037471/	https://finance.yahoo.com/quote/SOUN/	https://www.soundhound.com/	Udvikler løsninger til AI samtale-/stemmeassistenter	\N	\N	0.7800	2026	\N	USD	\N	\N	\N	Consulting(Tech)	\N	.US	NY	^GSPC	SOUN
SOYB	SOYB	Teucrium Soybean Fund	Agro	US	Basi	https://www.marketscreener.com/quote/etf/TEUCRIUM-SOYBEAN-FUND-U-29426325/	https://finance.yahoo.com/quote/SOYB?p=SOYB&.tsrc=fin-srch	\N	Soybeens	\N	\N	0.7100	2026	\N	USD	\N	\N	\N	Agro	\N	.US	NY	^GSPC	SOYB
SPG	SPG	Simon Property Group	Property	US	REIT	https://www.marketscreener.com/quote/stock/SIMON-PROPERTY-GROUP-INC-14452/	\N	https://www.simon.com	\N	\N	\N	0.3900	2026	\N	USD	\N	\N	\N	Property	\N	.US	NY	^GSPC	SPG
SPOT	SPOT	Spotify	TechToCons	Luxembourg	Tech	https://www.marketscreener.com/quote/stock/SPOTIFY-TECHNOLOGY-S-A-42589613/	https://finance.yahoo.com/quote/SPOT?p=SPOT&.tsrc=fin-srch	https://www.spotify.com	Digital musik-streaming	\N	\N	0.5000	2026	\N	USD	\N	\N	\N	TechToCons	\N	.US	NY	^GSPC	SPOT
SPXC	SPXC	SPX Corp (heating, cooling and ventilation / HVAC)	Electronics	US	Indu	https://www.marketscreener.com/quote/stock/SPX-TECHNOLOGIES-INC-14462/	\N	https://www.spx.com	\N	\N	\N	\N	\N	\N	USD	\N	\N	\N	Electronics	\N	.US	NY	^GSPC	SPXC
SQM	SQM	Sociedad Química y Minera de Chile	Agro	Chile	Basi	https://www.marketscreener.com/quote/stock/SOCIEDAD-QU-MICA-Y-MINERA-40246783/	https://finance.yahoo.com/quote/SQM?p=SQM&.tsrc=fin-srch	https://www.sqm.com	Lithium-råmateriale, iod og gødning	\N	\N	0.3300	2026	\N	USD	\N	\N	\N	Agro	\N	.US	NY	^GSPC	SQM
SRE	SRE	Sempra	Util_MixedFuel	US	Util	https://www.marketscreener.com/quote/stock/SEMPRA-14471/	https://finance.yahoo.com/quote/SRE/	https://www.sempra.com/	Største util i US. 3 areas of activity: distribution of natural gas (56.8% of sales); transmission of electricity (25.9%); and development of energy infrastructures (17.3%)	\N	\N	0.5000	2026	\N	USD	\N	\N	\N	Util_MixedFuel	\N	.US	NY	^GSPC	SRE
SSE.L	LON:SSE	SSE plc	Util_MixedFuel	UK	Util	https://www.marketscreener.com/quote/stock/SSE-PLC-4000881/	https://finance.yahoo.com/quote/SSE.L/	https://www.sse.com	Generation and distribution of electricity generatet from water, gas, coal, oil, and multi fuel. Covers southern central England and the north of Scotland	\N	\N	0.6100	2026	\N	GBX	\N	\N	\N	Util_MixedFuel	\N	.L	LON	^FTSE	SSE.L
SSRM	SSRM	SSR Mining	Gold	US	Basi	https://www.marketscreener.com/quote/stock/SSR-MINING-INC-37333388/	https://finance.yahoo.com/quote/SSRM/	https://www.ssrmining.com/	3.største US guld-producent. Miner i USA, Can, Argentina og Tyrkiet	\N	\N	0.6000	2026	\N	USD	\N	\N	\N	Gold	\N	.US	NY	^GSPC	SSRM
SSW.JO	JSE:SSW	Sibanye Stillwater	Diverse_Basi	Sydafrika	Basi	https://www.marketscreener.com/quote/stock/SIBANYE-STILLWATER-LIMITE-103499149/	https://finance.yahoo.com/quote/SSW.JO/	https://www.sibanyestillwater.com/	Udvinding - via opkøb 2025 af US-virks inden for recycling - af ædle metaller. Største inde for platin. 58000 ansatte, oms 112 mia ZAR (40 mia DKK) (TTM, jul 2025). US-ticker: SBSW	\N	\N	0.5800	2026	\N	ZAR	\N	\N	\N	Other[Basi]	\N	.JO	Other	^DJAFK	SSW.JO
STAN.L	LON:STAN	Standard Chartered PLC	Bank	UK	Fina	https://www.marketscreener.com/quote/stock/STANDARD-CHARTERED-PLC-4003394/	https://finance.yahoo.com/quote/STAN.L?p=STAN.L&.tsrc=fin-srch	https://www.sc.com	Bank	\N	\N	0.4000	2026	\N	GBX	\N	\N	\N	Bank	\N	.L	LON	^FTSE	STAN.L
STEP	STEP	Stepstone Group	Investment	US	Fina	https://www.marketscreener.com/quote/stock/STEPSTONE-GROUP-INC-112440379/	\N	https://www.stepstonegroup.com	Investment solutions, advisory and data services	\N	\N	0.7000	2026	\N	USD	\N	\N	\N	Investment	\N	.US	NY	^GSPC	STEP
STLA	STLA	Stellantis	Automotive	NL	C-Di	https://www.marketscreener.com/quote/stock/STELLANTIS-N-V-117883697/	https://finance.yahoo.com/quote/STLA?p=STLA&.tsrc=fin-srch	https://www.stellantis.com	Fiat, Citroen, Peugoet, Opel, Chrysler, Jeep, Alfa Romeo, m.fl.  Højt udbytte.	\N	\N	0.4500	2026	\N	USD	\N	\N	t	Automotive	\N	.US	NY	^GSPC	STLA
STM	STM	STMicroelectronics	Semi	NL	Tech	https://www.marketscreener.com/quote/stock/STMICROELECTRONICS-N-V-14494/	\N	https://www.st.com	Hollandsk chip-maker, men noteret også på NYSE. Infenion og STMicro er eneste EU-chipmakers.	\N	\N	0.6000	2026	\N	USD	\N	\N	\N	Semi	\N	.US	NY	^GSPC	STM
STNE	STNE	StoneCo Ltd	Fintech	Cayman Islands	Fina	https://www.marketscreener.com/quote/stock/STONECO-LTD-46772609/	https://finance.yahoo.com/quote/STNE/	stoneco.com.br	Finansiel teknologi og softwareløsninger. Cloudbaseret platform, til at kunderne kan oprette forbindelse, modtage betaling og vækste deres forretning	\N	\N	0.4000	2026	\N	USD	\N	\N	\N	Fintech	\N	.US	NY	^GSPC	STNE
STNG	STNG	Scorpio Tankers	Trpt_Ship (Ener)	US	Ener	https://www.marketscreener.com/quote/stock/SCORPIO-TANKERS-INC-54095367/	https://finance.yahoo.com/quote/STNG?p=STNG&.tsrc=fin-srch	https://www.scorpiotankers.com	Product tanker (refined petro-products)	\N	\N	0.4500	2026	\N	USD	\N	\N	\N	Trpt_Ship (Ener)	\N	.US	NY	^GSPC	STNG
STR.VI	VIE:STR	Strabag, Wien	Construction	Østrig	Indu	https://www.marketscreener.com/quote/stock/STRABAG-SE-6499406/	https://finance.yahoo.com/quote/STR.VI?p=STR.VI&.tsrc=fin-srch	https://www.strabag.com	No 3 (efter ACS og Vinci) blandt entreprenører i Europa (75000 ansatte)	\N	\N	0.2800	2026	\N	EUR	\N	\N	\N	Construction	\N	.VI	LON	^STOXX	STR.VI
STRL	STRL	Sterling Infrastructure, Inc.	Construction	US	Indu	https://www.marketscreener.com/quote/stock/STERLING-INFRASTRUCTURE-I-10981/	https://finance.yahoo.com/quotes/STRL,AMPGZ/	https://www.strlco.com/	Alle slags byggerier, men især tekniske byggerier (datacentre, men også til transport- og fremstillingsvirks)	\N	\N	\N	\N	\N	USD	\N	AI-infrastruktur	\N	Construction	\N	.US	NY	^GSPC	STRL
STWD	STWD	Starwood Property	Mortgages	US	REIT	https://www.marketscreener.com/quote/stock/STARWOOD-PROPERTY-TRUST-5513252/	https://finance.yahoo.com/quote/STWD?p=STWD&.tsrc=fin-srch	https://www.starwoodpropertytrust.com	Commercial buildings mortages (58%). Rest residential and infrastructure plus servicing. Offices only 13% (2023Q3).	t	\N	0.5000	2026	\N	USD	\N	\N	\N	Mortgages	\N	.US	NY	^GSPC	STWD
STX	STX	Seagate Technology Holdings	TechToProfs	US	Tech	https://www.marketscreener.com/quote/stock/SEAGATE-TECHNOLOGY-HOLDIN-14501/	https://finance.yahoo.com/quote/STX/	https://www.seagate.com/	Data storage teknologi	\N	\N	0.5000	2026	\N	USD	\N	\N	\N	TechToProfs	\N	.US	NY	^GSPC	STX
STZ	STZ	Constellation Brands	Food	US	C-St	https://www.marketscreener.com/quote/stock/CONSTELLATION-BRANDS-INC-14502/	\N	https://www.cbrands.com	American producers of wines, spirits and beers (Corona-øl f.eks.)	\N	\N	0.5000	2026	\N	USD	\N	\N	t	Food	\N	.US	NY	^GSPC	STZ
SU.PA	EPA:SU	Schneider Electric SE	Rnwb(Ener)	FR	Ener	https://www.marketscreener.com/quote/stock/SCHNEIDER-ELECTRIC-SE-4699/	https://finance.yahoo.com/quote/SU.PA/	https://www.se.com/ww/en/	Energi-/strømstyring, automatisering for virksomheder, datacentre mv	\N	\N	0.6500	2026	\N	EUR	\N	\N	\N	Rnwb(Ener)	\N	.PA	LON	^FCHI	SU.PA
SU.TO	TSE:SU	Suncor Energy	Oil&Gas	CAN	Ener	https://www.marketscreener.com/quote/stock/SUNCOR-ENERGY-INC-1411810/	https://finance.yahoo.com/quote/SU.TO?p=SU.TO&.tsrc=fin-srch	https://www.suncor.com	Crude oil from tar sand	\N	\N	\N	\N	\N	CAD	\N	\N	\N	Oil&Gas	\N	.TO	NY	^GSPC	SU.TO
SUHJY	SUHJY	Sun Hung Kai	Property	China	REIT	https://www.marketscreener.com/quote/stock/SUN-HUNG-KAI-PROPERTIES-L-1412602/	https://finance.yahoo.com/quote/SUHJY?p=SUHJY	https://www.shkp.com	\N	\N	\N	0.6200	2026	\N	USD	\N	\N	\N	Property	\N	.US	NY	^GSPC	SUHJY
SUI	SUI	Sun Communities (ejer jord under huse)	Property	US	REIT	https://www.marketscreener.com/quote/stock/SUN-COMMUNITIES-INC-14510/	\N	https://www.suncommunities.com	\N	\N	\N	0.5300	2026	\N	USD	\N	\N	\N	Property	\N	.US	NY	^GSPC	SUI
SUJP.L	LON:SUJP	iShares MSCI Japan SRI UCITS ETF ACC  USD	Country	UK	na	https://www.marketscreener.com/quote/etf/ISHARES-MSCI-JAPAN-SRI-UC-65337852/	https://finance.yahoo.com/quote/SUJP.L/	\N	Japan. Øverste Hitachi med 5,2%. I alt ca 50 aktier	\N	\N	0.3000	2026	\N	USD	\N	\N	\N	Country	\N	.L	LON	^FTSE	SUJP.L
SWED-A.ST	CPH:SWED-A	Swedbank	Bank	SE	Fina	https://www.marketscreener.com/quote/stock/SWEDBANK-AB-6496651/	https://finance.yahoo.com/quote/SWED-A.ST?p=SWED-A.ST	https://www.swedbank.com	\N	t	\N	0.5000	2026	\N	SEK	\N	\N	\N	Bank	\N	.ST	LON	^OMX	SWED-A.ST
SWK	SWK	Stanley Black & Decker	Manuf_Special	US	Indu	https://www.marketscreener.com/quote/stock/STANLEY-BLACK-DECKER-INC-14522/	\N	https://www.stanleyblackanddecker.com	\N	\N	\N	0.5000	2026	\N	USD	\N	\N	\N	Manuf_Special	\N	.US	NY	^GSPC	SWK
SWKS	SWKS	Skyworks Solutions	Semi	US	Tech	https://www.marketscreener.com/quote/stock/SKYWORKS-SOLUTIONS-INC-11014/	\N	https://www.skyworksinc.com	High-performance, mixed signal semi-conductors	t	\N	0.3700	2026	\N	USD	\N	\N	\N	Semi	\N	.US	NY	^GSPC	SWKS
SWP.PA	EPA:SWP	Sword Group S.E.	Defense	Luxembourg	Indu	https://www.marketscreener.com/quote/stock/SWORD-GROUP-SE-5125/	https://finance.yahoo.com/quote/SWP.PA/	http://www.sword-group.com/	IT services, including those for the defense sector.	\N	\N	0.5000	2026	\N	EUR	\N	\N	\N	Defense	\N	.PA	LON	^FCHI	SWP.PA
SXLK.L	LON:SXLK	SPDR S&P U.S. Technology Select Sector UCITS ETF (Acc)	TechToProfs	US	Tech	https://www.ssga.com/dk/en_gb/intermediary/etfs/funds/spdr-sp-us-technology-select-sector-ucits-etf-acc-zpdt-gy	https://finance.yahoo.com/quote/SXLK.L?p=SXLK.L&.tsrc=fin-srch	\N	\N	\N	\N	0.3900	2026	\N	GBX	\N	\N	\N	TechToProfs	\N	.L	LON	^FTSE	SXLK.L
SYK	SYK	Stryker	Healthcare	US	Heal	https://www.marketscreener.com/quote/stock/STRYKER-CORPORATION-14536/	https://finance.yahoo.com/quote/SYK/	https://www.stryker.com	orthopedic equipments	\N	\N	0.6000	2026	\N	USD	\N	\N	\N	Healthcare	\N	.US	NY	^GSPC	SYK
SYM	SYM	Symbotic	Manuf_Special	US	Indu	https://www.marketscreener.com/quote/stock/SYMBOTIC-INC-139195255/	https://finance.yahoo.com/quote/SYM?p=SYM&.tsrc=fin-srch	https://www.symbotic.com	AI-udviklet robottekn. til lager	\N	\N	0.3700	2026	\N	USD	\N	\N	\N	Manuf_Special	\N	.US	NY	^GSPC	SYM
SYY	SYY	Sysco Corporation	Food	US	C-St	https://www.marketscreener.com/quote/stock/SYSCO-CORPORATION-14540/	https://finance.yahoo.com/quote/SYY?p=SYY&.tsrc=fin-srch	https://www.sysco.com	Fødevareservice	\N	\N	0.6000	2026	\N	USD	\N	\N	\N	Food	\N	.US	NY	^GSPC	SYY
SAAB-B.ST	STO:SAAB-B	SAAB	Defense	SE	Indu	https://www.marketscreener.com/quote/stock/SAAB-AB-PUBL-6491624/	https://finance.yahoo.com/quote/SAAB-B.ST?p=SAAB-B.ST&.tsrc=fin-srch	https://www.saab.com	Anti-tank missiler	\N	\N	0.6500	2026	\N	SEK	\N	\N	\N	Defense	\N	.ST	LON	^OMX	SAAB-B.ST
T.TO	TSE:T	Telus	Telecom	CAN	Tele	https://www.marketscreener.com/quote/stock/TELUS-CORPORATION-1411858/	\N	https://www.telus.com	Godt udbytte	\N	\N	\N	\N	\N	CAD	\N	\N	\N	Telecom	\N	.TO	NY	^GSPC	T.TO
TAC	TAC	TransAlta Corp	Util_MixedFuel	US	Util	https://www.marketscreener.com/quote/stock/TRANSALTA-CORPORATION-14543/	https://finance.yahoo.com/quote/TAC?p=TAC&.tsrc=fin-srch	https://www.transalta.com	Production, and sale of electric energy from Hydro, Wind and Solar, and Gas. Located in Alberta, British Columbia, and Ontario	\N	\N	0.3700	2026	\N	USD	\N	\N	\N	Util_MixedFuel	\N	.US	NY	^GSPC	TAC
TAK	TAK	Takeda Pharmaceutical Company Limited	Pharma	Japan	Heal	https://www.marketscreener.com/quote/stock/TAKEDA-PHARMACEUTICAL-COM-49728873/	https://finance.yahoo.com/quote/TAK/	https://www.takeda.com/	Japansk medicinalvirksomhed	\N	\N	0.5500	2026	\N	USD	\N	\N	\N	Pharma	\N	.US	NY	^GSPC	TAK
TAL	TAL	TAL Education Grp	Media&Educ	China	C-Di	https://www.marketscreener.com/quote/stock/TAL-EDUCATION-GROUP-6765125/	https://finance.yahoo.com/quote/TAL/	https://www.100tal.com/	After school tutoring and smart learning solutions in China	\N	\N	0.5000	2026	\N	USD	\N	\N	\N	Media&Educ	\N	.US	NY	^GSPC	TAL
TASK	TASK	TaskUs	TechToProfs	US	Tech	https://www.marketscreener.com/quote/stock/TASKUS-INC-123529035/	https://finance.yahoo.com/quote/TASK?p=TASK&.tsrc=fin-srch	https://www.taskus.com	Børsnoteret midt-2021. 3 service lines: Digital Cust Experience, Trust and Safety, AI Services. 'The picks and shovels of digital economy'. Meta+Doordash største kunder, 30% af salg (2023)	\N	\N	0.5000	2026	\N	USD	\N	\N	\N	TechToProfs	\N	.US	NY	^GSPC	TASK
TCEHY	TCEHY	Tencent	TechToCons	China	Tech	https://www.marketscreener.com/quote/stock/TENCENT-HOLDINGS-LIMITED-3045861/	https://finance.yahoo.com/quote/TCEHY?p=TCEHY&.tsrc=fin-srch	https://www.tencent.com	\N	\N	\N	0.4400	2026	\N	USD	\N	\N	\N	TechToCons	\N	.US	NY	^GSPC	TCEHY
TCOM	TCOM	Trip.com Intl	Holiday	China	C-Di	https://www.marketscreener.com/quote/stock/TRIP-COM-GROUP-LIMITED-40311225/	\N	https://www.group.trip.com	Travel-platform	\N	\N	0.3500	2026	\N	USD	\N	\N	\N	Holiday	\N	.US	NY	^GSPC	TCOM
TD.TO	TSE:TD	Toronto Dominion	Bank	CAN	Fina	https://www.marketscreener.com/quote/stock/THE-TORONTO-DOMINION-BANK-1411888/	\N	https://www.td.com	\N	\N	\N	0.7100	2026	\N	CAD	\N	\N	\N	Bank	\N	.TO	NY	^GSPC	TD.TO
TDIV.AS	AMS:TDIV	VanEck Morningstar Developed Markets Dividend Leaders UCITS ETF (Dist, EUR)	Diverse_na	Intl	na	https://www.marketscreener.com/quote/etf/VANECK-MORNINGSTAR-DEVELO-27753099/	https://finance.yahoo.com/quote/TDIV.AS/	https://www.vaneck.com/uk/en/investments/dividend-etf/overview/	Div fra aktive selskaber (inkl. finansielle), men ikke rene kapital-forvaltere (BDC, REIT etc.)	t	\N	0.3500	2026	\N	EUR	\N	\N	\N	Diverse_na	\N	.AS	LON	^AEX	TDIV.AS
TDOC	TDOC	Teladoc Health	Healthcare	US	Heal	https://www.marketscreener.com/quote/stock/TELADOC-HEALTH-INC-22762533/	\N	https://www.teladochealth.com	Telemedicin	\N	\N	0.5000	2026	\N	USD	\N	\N	\N	Healthcare	\N	.US	NY	^GSPC	TDOC
TEAM	TEAM	Atlassian	TechToProfs	US	Tech	https://www.marketscreener.com/quote/stock/ATLASSIAN-CORPORATION-25531314/	\N	https://www.atlassian.com	Project- og team-sw/system	t	\N	0.3500	2026	\N	USD	\N	\N	\N	TechToProfs	\N	.US	NY	^GSPC	TEAM
TECK	TECK	Teck Resources	Mining	CAN	Basi	https://www.marketscreener.com/quote/stock/TECK-RESOURCES-LIMITED-29331/	https://finance.yahoo.com/quote/TECK/	https://www.teck.com/	Properties in Asia, the Americas, and Europe. It offers copper, zinc, and lead concentrates. Also refined zinc, lead, and silver. Produces lead, precious metals, molybdenum, fertilizers, and other metals.	\N	\N	0.5300	2026	\N	USD	\N	\N	\N	Mining	\N	.US	NY	^GSPC	TECK
TECK-B.TO	TSE:TECK.B	Teck Resources 	Mining	CAN	Basi	https://www.marketscreener.com/quote/stock/TECK-RESOURCES-LIMITED-1411898/	https://finance.yahoo.com/quote/TECK-B.TO?p=TECK-B.TO&.tsrc=fin-srch	https://www.teck.com	Metalliske råvarer og metallurgiske kul	\N	\N	0.6800	2026	\N	CAD	\N	\N	\N	Mining	\N	.TO	NY	^GSPC	TECK-B.TO
TEF	TEF	Telefonica (Spain)	Telecom	ES	Tele	https://www.marketscreener.com/quote/stock/TELEF-NICA-S-A-14572/	https://finance.yahoo.com/quote/VIV?p=VIV&.tsrc=fin-srch	https://www.telefonica.com	\N	\N	\N	0.6300	2026	\N	USD	\N	\N	\N	Telecom	\N	.US	NY	^GSPC	TEF
TEF.MC	BME:TEF	Telefonica S.A.	Telecom	ES	Tele	https://www.marketscreener.com/quote/stock/TELEF-NICA-S-A-68962/	https://finance.yahoo.com/quote/TEF?p=TEF&.tsrc=fin-srch	https://www.telefonica.com	Spaniens største telecom-selskab	\N	\N	0.4400	2026	\N	EUR	\N	\N	\N	Telecom	\N	.MC	LON	^STOXX	TEF.MC
TEL	TEL	TE Connectivity	Electronics	CH	Indu	https://www.marketscreener.com/quote/stock/TE-CONNECTIVITY-LTD-52802/	https://finance.yahoo.com/quote/TEL?p=TEL&.tsrc=fin-srch	https://www.deutsch.net	Schweitziske præcisionskomponenter til EVs	\N	\N	0.2800	2026	\N	USD	\N	\N	\N	Electronics	\N	.US	NY	^GSPC	TEL
TEL.OL	OSL:TEL	Telenor ASA	Telecom	NO	Tele	https://www.marketscreener.com/quote/stock/TELENOR-ASA-1413298/	https://finance.yahoo.com/quote/TEL.OL?p=TEL.OL&.tsrc=fin-srch	https://www.telenor.no/	Norges største telco. 'Slow but steady'	\N	\N	0.5000	2026	\N	NOK	\N	\N	\N	Telecom	\N	.OL	LON	^OSEBX	TEL.OL
TEL2-B.ST	STO:TEL2-B	Tele2 AB	Telecom	SE	Tele	https://www.marketscreener.com/quote/stock/TELE2-AB-13247047/	\N	https://www.tele2.com	En af EUs største telecom. Sverige og 3 baltiske lande.	\N	\N	0.6700	2026	\N	SEK	\N	\N	\N	Telecom	\N	.ST	LON	^OMX	TEL2-B.ST
TELIA.ST	STO:TELIA	Telia Company AB	Telecom	SE	Tele	https://www.marketscreener.com/quote/stock/TELIA-COMPANY-AB-6491092/	https://finance.yahoo.com/quote/TELIA.ST?p=TELIA.ST&.tsrc=fin-srch	https://www.teliasonera.com	\N	\N	\N	0.4000	2026	\N	SEK	\N	\N	\N	Telecom	\N	.ST	LON	^OMX	TELIA.ST
TEN	TEN	Tsakos Energy Navigatio	Trpt_Ship (Ener)	Greece	Ener	https://www.marketscreener.com/quote/stock/TSAKOS-ENERGY-NAVIGATION--14634/	https://finance.yahoo.com/quote/TEN/	https://www.tenn.gr	Crude oil and petroleum product shipping	\N	\N	0.6300	2026	\N	EUR	\N	\N	\N	Trpt_Ship (Ener)	\N	.US	NY	^GSPC	TEN
TER	TER	Teradyne	Semi	US	Tech	https://www.marketscreener.com/quote/stock/TERADYNE-INC-47342162/	\N	https://www.teradyne.com	Udstyr til testning af elektronik (chips, moduler, udstyr)	\N	\N	0.7800	2026	\N	USD	\N	\N	\N	Semi	\N	.US	NY	^GSPC	TER
TEVA	TEVA	Teva Pharmacutical (ADR)	Pharma	Israel	Heal	https://www.marketscreener.com/quote/stock/TEVA-PHARMACEUTICAL-INDUS-40246797/	\N	https://www.tevapharm.com	\N	\N	\N	0.5300	2026	\N	USD	\N	\N	\N	Pharma	\N	.US	NY	^GSPC	TEVA
TFC	TFC	Truist	Bank	US	Fina	https://www.marketscreener.com/quote/stock/TRUIST-FINANCIAL-CORPORAT-11773/	https://finance.yahoo.com/quote/TFC?p=TFC&.tsrc=fin-srch	https://www.truist.com	Vækstende mellemstor regional bank, 54000 ansatte.	\N	\N	0.3900	2026	\N	USD	\N	\N	\N	Bank	\N	.US	NY	^GSPC	TFC
TGA.L	LON:TGA	Thungela Resources  (kul)	Oil&Gas	Sydafrika	Ener	https://www.marketscreener.com/quote/stock/THUNGELA-RESOURCES-LIMITE-121503953/	https://finance.yahoo.com/quote/TGA.L?p=TGA.L&.tsrc=fin-srch	https://www.thungela.com	Pure-play i kul.	t	\N	0.6000	2026	\N	GBX	\N	\N	\N	Oil&Gas	\N	.L	LON	^FTSE	TGA.L
TGT	TGT	Target Corporation	Retail	US	C-St	https://www.marketscreener.com/quote/stock/TARGET-CORPORATION-12291/	https://finance.yahoo.com/quote/TGT?p=TGT&.tsrc=fin-srch	https://www.target.com	Retail distribution, household, beauty, furnishing, electronics, sporting, toys, apparal	\N	\N	0.5500	2026	\N	USD	\N	\N	t	Retail	\N	.US	NY	^GSPC	TGT
THC	THC	Tenet Healthcare	Healthcare	US	Heal	https://www.marketscreener.com/quote/stock/TENET-HEALTHCARE-CORPORAT-11877509/	https://finance.yahoo.com/quote/THC/	https://www.tenethealth.com/	2 segments: Hospital Operations and Services, and Ambulatory Care. 86000 ansatte.	\N	\N	0.5500	2026	\N	USD	\N	\N	\N	Healthcare	\N	.US	NY	^GSPC	THC
TLN	TLN	Talen Energy Corp	Util_MixedFuel	US	Util	https://www.marketscreener.com/quote/stock/TALEN-ENERGY-CORPORATION-155304469/	https://finance.yahoo.com/quote/TLN/	http://www.talenenergy.com/	Houston, TX; 5000 ansatte. TLN produces and distributes electricity fra gas, nuclear and others. 50% of sales is from Susquehanna nuclear 2 GW-facility, which powers a developing Amazon Web Services data center to be using 960 MW.	\N	\N	0.4500	2026	\N	USD	\N	AI-infrastruktur	\N	Util_MixedFuel	\N	.US	NY	^GSPC	TLN
TLS	TLS	Telos Corp	Cybersecurity	US	Tech	https://www.marketscreener.com/quote/stock/TELOS-CORPORATION-115501546/	https://finance.yahoo.com/quote/TLS?p=TLS&.tsrc=fin-srch	https://www.telos.com	Cyber, cloud, and enterprise security solutions worldwide	\N	\N	0.3200	2026	\N	USD	\N	\N	\N	Cybersecurity	\N	.US	NY	^GSPC	TLS
TM	TM	Toyota Motor Corp.	Automotive	Japan	C-Di	https://www.marketscreener.com/quote/stock/TOYOTA-MOTOR-CORPORATION-14614/	https://finance.yahoo.com/quote/TM?p=TM&.tsrc=fin-srch	https://global.toyota/jp/	7203.JP. På vej ind i solid-state batteries til først hybrids og senere full-electric EV.	\N	\N	0.6000	2026	\N	USD	\N	\N	\N	Automotive	\N	.US	NY	^GSPC	TM
TMO	TMO	Thermo Fisher Scientific	Manuf_Special	US	Indu	https://www.marketscreener.com/quote/stock/THERMO-FISHER-SCIENTIFIC--14623/	\N	https://www.thermofisher.com	\N	\N	\N	0.3300	2026	\N	USD	\N	\N	\N	Manuf_Special	\N	.US	NY	^GSPC	TMO
TMUS	TMUS	T-Mobile	Telecom	US	Tele	https://www.marketscreener.com/quote/stock/T-MOBILE-US-24717887/	https://finance.yahoo.com/quote/TMUS?p=TMUS&.tsrc=fin-srch	https://www.t-mobile.com	\N	\N	\N	0.5000	2026	\N	USD	\N	\N	\N	Telecom	\N	.US	NY	^GSPC	TMUS
TNK	TNK	Teekay Tankers	Trpt_Ship	Bermuda	Indu	https://www.marketscreener.com/quote/stock/TEEKAY-TANKERS-LTD-433824/	https://finance.yahoo.com/quote/TNK/analysis/	https://www.teekay.com/business/tankers	Crude oil and refined oil products	\N	\N	0.6500	2026	\N	USD	\N	\N	\N	Trpt_Ship	\N	.US	NY	^GSPC	TNK
TOELY	TOELY	Tokyo Electron  (ADR	Semi	Japan	Tech	https://www.marketscreener.com/quote/stock/TOKYO-ELECTRON-LIMITED-120792118/	https://finance.yahoo.com/quote/TOELY/	https://www.tel.co.jp	Semiconductor-equipment. 2 ADR = 1 stk 8035.T	t	\N	0.6100	2026	\N	USD	\N	\N	\N	Semi	\N	.US	NY	^GSPC	TOELY
TOM.OL	OSL:TOM	Tomra Systems	Manuf_Special	NO	Indu	https://www.marketscreener.com/quote/stock/TOMRA-SYSTEMS-ASA-1413304/	https://finance.yahoo.com/quote/TOM.OL?p=TOM.OL&.tsrc=fin-srch	https://www.tomra.com	\N	t	\N	0.6100	2026	\N	NOK	\N	\N	\N	Manuf_Special	\N	.OL	LON	^OSEBX	TOM.OL
TOU.TO	TSE:TOU	Tourmaline Oil Corp	Oil&Gas	CAN	Ener	https://www.marketscreener.com/quote/stock/TOURMALINE-OIL-CORP-6908477/	https://finance.yahoo.com/quote/TOU.TO?p=TOU.TO&.tsrc=fin-srch	https://www.tourmalineoil.com	Oil & gas fra Vest-Canada	\N	\N	0.4000	2026	\N	CAD	\N	\N	\N	Oil&Gas	\N	.TO	NY	^GSPC	TOU.TO
TPH	TPH	Tri Pointe Group	ConstrHomes	US	C-Di	https://www.marketscreener.com/quote/stock/TRI-POINTE-HOMES-INC-12455217/	\N	https://www.tripointehomes.com	Homebuilding	\N	\N	0.3800	2026	\N	USD	\N	\N	\N	ConstrHomes	\N	.US	NY	^GSPC	TPH
TPR	TPR	Tapestry	Luxury	US	C-Di	https://www.marketscreener.com/quote/stock/TAPESTRY-INC-38530108/	\N	https://www.tapestry.com	Luxery accessories	\N	\N	\N	\N	\N	USD	\N	\N	\N	Luxury	\N	.US	NY	^GSPC	TPR
TPVG	TPVG	TriplePoint Venture Growth BDC Corp	BDC	US	Fina	https://www.marketscreener.com/quote/stock/TRIPLEPOINT-VENTURE-GROWT-15933327/	https://finance.yahoo.com/quote/TPVG?p=TPVG&.tsrc=fin-srch	https://www.tpvg.com/	Early stage investments, mest i IT and healthcare-selskaber	t	\N	0.5000	2026	\N	USD	\N	\N	\N	BDC	\N	.US	NY	^GSPC	TPVG
TRI.TO	TSE:TRI	Thomson Reuters	Consulting(Tech)	CAN	Tech	https://www.marketscreener.com/quote/stock/THOMSON-REUTERS-CORPORATI-47342166/	https://finance.yahoo.com/quote/TRI.TO?p=TRI.TO&.tsrc=fin-srch	https://www.thomsonreuters.com	Lev. af business information	\N	\N	0.3900	2026	\N	CAD	\N	\N	\N	Consulting(Tech)	\N	.TO	NY	^GSPC	TRI.TO
TRIFOR.CO	CPH:TRIFOR	Trifork	Consulting(Tech)	DK	Tech	https://www.marketscreener.com/quote/stock/TRIFORK-GROUP-AG-123353473/	https://finance.yahoo.com/quote/TRIFOR.CO	https://www.trifork.com	Softwre udvikling henh. investering i iværksættere	\N	\N	0.4000	2026	\N	DKK	\N	\N	\N	Consulting(Tech)	\N	.CO	LON	^OMXC20	TRIFOR.CO
TRMB	TRMB	Trimble	Manuf_Special	US	Indu	https://www.marketscreener.com/quote/stock/TRIMBLE-INC-11147/	\N	https://www.trimble.com	\N	\N	\N	0.3000	2026	\N	USD	\N	\N	\N	Manuf_Special	\N	.US	NY	^GSPC	TRMB
TRMD-A.CO	CPH:TRMD-A	Torm PLC	Trpt_Ship (Ener)	UK	Ener	https://www.marketscreener.com/quote/stock/TORM-PLC-27114630/	https://finance.yahoo.com/quote/TRMD-A.CO?p=TRMD-A.CO&.tsrc=fin-srch	https://www.torm.com	Oil products transport	t	\N	0.5300	2026	\N	DKK	\N	\N	\N	Trpt_Ship (Ener)	\N	.CO	LON	^OMXC20	TRMD-A.CO
TRN.MI	BIT:TRN	Terna S.p.A.	Util_MixedFuel	IT	Util	https://www.marketscreener.com/quote/stock/TERNA-S-P-A-135034/	https://finance.yahoo.com/quote/TEZNY/	https://terna.it/	Transmission af el i Italien og internationalt	\N	\N	0.7200	2026	\N	EUR	\N	\N	\N	Util_MixedFuel	\N	.MI	LON	^STOXX	TRN.MI
TROW	TROW	T. Rowe Price	Investment	US	Fina	https://www.marketscreener.com/quote/stock/T-ROWE-PRICE-GROUP-INC-40311214/	\N	https://www.troweprice.com	\N	\N	\N	0.3700	2026	\N	USD	\N	\N	\N	Investment	\N	.US	NY	^GSPC	TROW
TRTX	TRTX	TPG RE Finance Trust (commercial)	Mortgages	US	REIT	https://www.marketscreener.com/quote/stock/TPG-RE-FINANCE-TRUST-INC-36911439/	\N	https://www.tpgrefinance.com	\N	\N	\N	0.6000	2026	\N	USD	\N	\N	\N	Mortgages	\N	.US	NY	^GSPC	TRTX
TRV	TRV	The Travellers Companies	Insurance	US	Fina	https://www.marketscreener.com/quote/stock/THE-TRAVELERS-COMPANIES-I-14449/	\N	https://www.travelers.com	\N	\N	\N	0.5000	2026	\N	USD	\N	\N	\N	Insurance	\N	.US	NY	^GSPC	TRV
TRYG.CO	CPH:TRYG	Tryg Forsiking	Insurance	DK	Fina	https://www.marketscreener.com/quote/stock/TRYG-A-S-1413048/	https://finance.yahoo.com/quote/TRYG.CO?p=TRYG.CO&.tsrc=fin-srch-v1	https://www.tryg.com	Non-life insurance af næsten enhver art, 2/3 private kunder	t	\N	0.4500	2026	\N	DKK	\N	\N	\N	Insurance	\N	.CO	LON	^OMXC20	TRYG.CO
TSCO	TSCO	Tractor Supply Comp	Retail	US	C-St	https://www.marketscreener.com/quote/stock/TRACTOR-SUPPLY-COMPANY-11162/	https://finance.yahoo.com/quote/TSCO?p=TSCO&.tsrc=fin-srch	https://www.tractorsupply.com	Retailer, traditionelle landbo-produkter (næsten nostalgi)	\N	\N	0.5000	2026	\N	USD	\N	\N	\N	Retail	\N	.US	NY	^GSPC	TSCO
TSLA	TSLA	Tesla	Automotive	US	C-Di	https://www.marketscreener.com/quote/stock/TESLA-INC-6344549/	\N	https://www.tesla.com	Biler	t	\N	0.6000	2026	\N	USD	\N	Magni7	\N	Automotive	\N	.US	NY	^GSPC	TSLA
TSLX	TSLX	Sixth Street Specialty Lending	BDC	US	Fina	https://www.marketscreener.com/quote/stock/SIXTH-STREET-SPECIALTY-LE-16056545/	https://finance.yahoo.com/quote/TSLX?p=TSLX&.tsrc=fin-srch	https://sixthstreetspecialtylending.com	Lending to middle-market companies	\N	\N	0.4500	2026	\N	USD	\N	\N	\N	BDC	\N	.US	NY	^GSPC	TSLX
TSM	TSM	Taiwan Semiconductor (TSMC)	Semi	Taiwan	Tech	https://www.marketscreener.com/quote/stock/TAIWAN-SEMICONDUCTOR-MANU-40246786/	\N	https://www.tsmc.com	\N	t	\N	0.5000	2026	\N	USD	\N	\N	\N	Semi	\N	.US	NY	^GSPC	TSM
TSN	TSN	Tyson	Food	US	C-St	https://www.marketscreener.com/quote/stock/TYSON-FOODS-INC-14672/	\N	https://www.tysonfoods.com	\N	\N	\N	0.2800	2026	\N	USD	\N	\N	\N	Food	\N	.US	NY	^GSPC	TSN
TT	TT	Trane Technologies PLC	Electronics	Irland	Indu	https://www.marketscreener.com/quote/stock/TRANE-TECHNOLOGIES-PLC-13109/	https://finance.yahoo.com/quote/TT?p=TT&.tsrc=fin-srch	https://www.company.ingersollrand.com	HVAC-udstyr, bla. væskekøling til datacentre	\N	\N	0.5500	2026	\N	USD	\N	AI-infrastruktur	\N	Electronics	\N	.US	NY	^GSPC	TT
TTD	TTD	Trade Desk (sw)	TechToProfs	US	Tech	https://www.marketscreener.com/quote/stock/THE-TRADE-DESK-INC-31370485/	https://finance.yahoo.com/quote/TTD/	https://www.thetradedesk.com	Does digital advertising campaigns across ad formats, channels and devices	\N	\N	0.6500	2026	\N	USD	\N	\N	\N	TechToProfs	\N	.US	NY	^GSPC	TTD
TTE.PA	EPA:TTE	TotalEnergies	Oil&Gas	FR	Ener	https://www.marketscreener.com/quote/stock/TOTAL-SE-4717/	https://finance.yahoo.com/quote/FP.PA/profile?p=FP.PA	https://totalenergies.com	\N	t	\N	0.2500	2026	\N	EUR	\N	\N	t	Oil&Gas	\N	.PA	LON	^FCHI	TTE.PA
TWLO	TWLO	Twilio	TechToProfs	US	Tech	https://www.marketscreener.com/quote/stock/TWILIO-INC-28734706/	\N	https://www.twilio.com	\N	\N	\N	0.5300	2026	\N	USD	\N	\N	\N	TechToProfs	\N	.US	NY	^GSPC	TWLO
TXN	TXN	Texas Instruments	Semi	US	Tech	https://www.marketscreener.com/quote/stock/TEXAS-INSTRUMENTS-INCORPO-9730651/	\N	https://www.ti.com	\N	\N	\N	\N	\N	\N	USD	\N	\N	\N	Semi	\N	.US	NY	^GSPC	TXN
TXRH	TXRH	Texas Roadhouse	Restaurants	US	C-Di	https://www.marketscreener.com/quote/stock/TEXAS-ROADHOUSE-INC-11195/	\N	https://www.texasroadhouse.com	Ejer 566 rest. + 101 francheises i 49 stater og 10 andre lande. 73000 ansatte. HQ i Kentucky (!)	t	\N	0.5000	2026	\N	USD	\N	\N	\N	Restaurants	\N	.US	NY	^GSPC	TXRH
U	U	Unity Software	TechToProfs	US	Tech	https://www.marketscreener.com/quote/stock/UNITY-SOFTWARE-INC-112492634/	\N	https://www.unity.com	Platform for Video Game Developers	\N	\N	0.3500	2026	\N	USD	\N	\N	\N	TechToProfs	\N	.US	NY	^GSPC	U
UA	UA	Under Armour, 	Luxury	US	C-Di	https://www.marketscreener.com/quote/stock/UNDER-ARMOUR-INC-27114114/	https://finance.yahoo.com/quote/UA?p=UA&.tsrc=fin-srch	https://www.underarmour.com	Apparal, footwear, accessories	\N	\N	0.6500	2026	\N	USD	\N	\N	\N	Luxury	\N	.US	NY	^GSPC	UA
UAL	UAL	United Airlines	Trpt_Airline	US	Indu	https://www.marketscreener.com/quote/stock/UNITED-AIRLINES-HOLDINGS-45899617/	https://finance.yahoo.com/quote/UAL?p=UAL&.tsrc=fin-srch	https://www.united.com	Airline	\N	\N	0.3000	2026	\N	USD	\N	\N	\N	Trpt_Airline	\N	.US	NY	^GSPC	UAL
UBER	UBER	Uber	Trpt_Other	US	Indu	https://www.marketscreener.com/quote/stock/UBER-TECHNOLOGIES-INC-57860975/	https://finance.yahoo.com/quote/UBER?p=UBER&.tsrc=fin-srch	https://www.uber.com	Delivery and shared ride	\N	\N	0.4400	2026	\N	USD	\N	\N	\N	Trpt_Other	\N	.US	NY	^GSPC	UBER
UBSG.SW	SWX:UBSGE	UBS Group	Bank	CH	Fina	https://www.marketscreener.com/quote/stock/UBS-GROUP-AG-19156942/	https://finance.yahoo.com/quote/UBSG.SW?p=UBSG.SW&.tsrc=fin-srch	https://www.ubs.com	Formueforvaltning og investering	t	\N	0.4200	2026	\N	CHF	\N	\N	\N	Bank	\N	.SW	LON	^STOXX	UBSG.SW
UEC	UEC	Uranium Energy	Rnwb(Ener)	US	Ener	https://www.marketscreener.com/quote/stock/URANIUM-ENERGY-CORP-62414/	https://finance.yahoo.com/quote/UEC/	http://www.uraniumenergy.com/	Vertikalt integreret producent af uran. 171 ansatte.	\N	\N	0.4500	2026	\N	USD	\N	AI-infrastruktur	\N	Rnwb(Ener)	\N	.US	NY	^GSPC	UEC
UIE.CO	CPH:UIE	UIE PLC (United Intl. Enterpr.)	Food	DK	C-St	https://www.marketscreener.com/quote/stock/UIE-PLC-1413049/	https://finance.yahoo.com/quote/UIE.CO/	https://uie.dk/	6600 ansatte. Moderselskab for Malaysiske 'United Plantations' (børs kode i US: UP) og holding for et par minoritetsinvesteringer i uafhængige selskaber	\N	\N	0.5300	2026	\N	DKK	\N	\N	\N	Food	\N	.CO	LON	^OMXC20	UIE.CO
ULTA	ULTA	Ulta Beauty, 	Luxury	US	C-Di	https://www.marketscreener.com/quote/stock/ULTA-BEAUTY-INC-65158/	https://finance.yahoo.com/quote/ULTA?p=ULTA	https://www.ulta.com	Cosmetics sales and beauty stores	\N	\N	\N	\N	\N	USD	\N	\N	\N	Luxury	\N	.US	NY	^GSPC	ULTA
ULVR.L	LON:ULVR	Unilever	Distributor	UK	C-St	https://www.marketscreener.com/quote/stock/UNILEVER-PLC-9590186/	\N	https://www.unilever.com	Beaty&Personal Care, Home care and Foods & Refreshment	\N	\N	0.4000	2026	\N	GBX	\N	\N	\N	Other[C-St]	7	.L	LON	^FTSE	ULVR.L
UMC	UMC	United Microelectronics (ADR)	Semi	Taiwan	Tech	https://www.marketscreener.com/quote/stock/UNITED-MICROELECTRONICS-C-6494400/	https://finance.yahoo.com/quote/UMC?p=UMC&.tsrc=fin-srch	https://www.umc.com	Global semiconductor foundry	\N	\N	0.7900	2026	\N	USD	\N	\N	\N	Semi	\N	.US	NY	^GSPC	UMC
UNH	UNH	UnitedHealth	Healthcare	US	Heal	https://www.marketscreener.com/quote/stock/UNITEDHEALTH-GROUP-14750/	\N	https://www.unitedhealthgroup.com	Sundhedsforsikring & health management	t	\N	0.5300	2026	\N	USD	\N	\N	\N	Healthcare	\N	.US	NY	^GSPC	UNH
UNM	UNM	Unum Group	Insurance	US	Fina	https://www.marketscreener.com/quote/stock/UNUM-GROUP-14751/	https://finance.yahoo.com/quote/UNM?p=UNM&.tsrc=fin-srch	https://www.unum.com	Livsforsikring, pension o.lign. Sælges til arbejdsgivere.	\N	\N	0.6000	2026	\N	USD	\N	\N	\N	Insurance	\N	.US	NY	^GSPC	UNM
UNP	UNP	Union Pacific	Trpt_Other	US	Indu	https://www.marketscreener.com/quote/stock/UNION-PACIFIC-CORPORATION-14754/	\N	https://www.up.com	\N	\N	\N	0.5600	2026	\N	USD	\N	\N	\N	Trpt_Other	\N	.US	NY	^GSPC	UNP
UPS	UPS	United Parcel Service, Inc.	Trpt_Other	US	Indu	https://www.marketscreener.com/quote/stock/UNITED-PARCEL-SERVICE-INC-14758/	https://finance.yahoo.com/news/teradata-shares-jump-q4-adjusted-145733449.html	https://www.ups.com/us/en/home	\N	\N	\N	0.6700	2026	\N	USD	\N	\N	\N	Trpt_Other	\N	.US	NY	^GSPC	UPS
UPST	UPST	Upstart Holdings, 	Fintech	US	Fina	https://www.marketscreener.com/quote/stock/UPSTART-HOLDINGS-INC-116603056/	https://finance.yahoo.com/quote/UPST/	https://www.upstart.com/	AI-baseret låneplatform, der forbinder forbrugere med låneudbydere og tilbyder lån som privatlån, billån og boliglån via en cloud-baseret software	t	\N	0.4700	2026	\N	USD	\N	\N	\N	Fintech	\N	.US	NY	^GSPC	UPST
URNU.DE	ETR:URNU	Global X Uranium UCITS ETF (Acc) - USD	Rnwb(Ener)	Intl	Ener	https://www.marketscreener.com/quote/etf/GLOBAL-X-URANIUM-UCITS-ET-136849368/	https://finance.yahoo.com/quote/URNU.DE/	https://globalxetfs.eu/funds/urnu/	55% af holdings er energiselskaber	\N	\N	0.4500	2026	\N	EUR	\N	AI-infrastruktur	\N	Rnwb(Ener)	\N	.DE	LON	^GDAXI	URNU.DE
USAR	USAR	USA Rare Earth	Mining	US	Basi	https://www.marketscreener.com/quote/stock/USA-RARE-EARTH-INC-184731986/	https://finance.yahoo.com/quote/USAR/	https://www.usare.com/	30 ansatte. 20260126: Regering påtænker lån på 1,3B + 277 mio lån + ejerandel for bygning af "mine-to-magnet chain"	\N	\N	\N	\N	\N	USD	\N	\N	\N	Mining	\N	.US	NY	^GSPC	USAR
UTHR	UTHR	United Therapeutics	Pharma	US	Heal	https://www.marketscreener.com/quote/stock/UNITED-THERAPEUTICS-CORPO-11262/	https://finance.yahoo.com/quote/UTHR/	https://www.unither.com/	1200 ansatte. Hypertensions-medicin og pulver-inhalator som drug delivery device	\N	\N	0.4700	2026	\N	USD	\N	\N	\N	Pharma	\N	.US	NY	^GSPC	UTHR
UUUU	UUUU	Energy Fuels	Rnwb(Ener)	US	Ener	https://www.marketscreener.com/quote/stock/ENERGY-FUELS-INC-15378996/	https://finance.yahoo.com/quote/UUUU/	https://www.energyfuels.com/	Critical minerals focused on uranium, rare earth elements, heavy mineral sands (HMS). Producer of natural uranium concentrate,	\N	\N	0.4500	2026	\N	CAD	\N	\N	\N	Rnwb(Ener)	\N	.US	NY	^GSPC	UUUU
V	V	Visa	TechToCons	US	Tech	https://www.marketscreener.com/quote/stock/VISA-INC-2277468/	\N	https://usa.visa.com	\N	\N	\N	\N	\N	\N	USD	\N	\N	\N	TechToCons	\N	.US	NY	^GSPC	V
VALE	VALE	Vale S.A.	Mining	Brazil	Basi	https://www.marketscreener.com/quote/stock/VALE-S-A-14249/	https://finance.yahoo.com/quote/VALE?p=VALE&.tsrc=fin-srch	https://www.vale.com	Brasiliansk jern-malm til Kina	\N	\N	0.7500	2026	\N	USD	\N	\N	\N	Mining	\N	.US	NY	^GSPC	VALE
VALT.L	LON:VALT	Valterra Platinum	Mining	Sydafrika	Basi	https://www.marketscreener.com/quote/stock/VALTERRA-PLATINUM-LIMITED-189712763/	https://finance.yahoo.com/quote/VALT.L/	https://www.valterraplatinum.com/	20000 ansatte. Production in South Africa and other contries: Platinum, palladium, rhodium, ruthenium, iridium, osmium, nickel, copper, cobalt, and chrome, as well as gold and sodium sulphate	\N	\N	0.5000	2026	\N	GBX	\N	\N	\N	Mining	\N	.L	LON	^FTSE	VALT.L
VEI.OL	OSL:VEI	Veidekke	Construction	NO	Indu	https://www.marketscreener.com/quote/stock/VEIDEKKE-ASA-1413310/	https://finance.yahoo.com/quote/VEI.OL?p=VEI.OL&.tsrc=fin-srch	https://www.veidekke.com	60% salg Norge, 34% Sverige.	t	\N	\N	\N	\N	NOK	\N	\N	\N	Construction	\N	.OL	LON	^OSEBX	VEI.OL
VFC	VFC	VF Corp	Clothing	US	C-Di	https://www.marketscreener.com/quote/stock/VF-CORPORATION-14798/	\N	https://www.vfc.com	\N	\N	\N	0.4500	2026	\N	USD	\N	\N	\N	Clothing	\N	.US	NY	^GSPC	VFC
VHYL.L	LON:VHYL	FTSE All-World High Dividend Yield UCITS ETF (USD) Distributing	Diverse_na	Intl	na	https://www.vanguardinvestor.co.uk/investments/vanguard-ftse-all-world-high-dividend-yield-ucits-etf-usd-distributing	https://finance.yahoo.com/quote/VHYL.L?p=VHYL.L&.tsrc=fin-srch	\N	\N	\N	\N	0.2500	2026	\N	USD	\N	\N	\N	Diverse_na	\N	.L	LON	^FTSE	VHYL.L
VICI	VICI	VICI properties (hospitality)	Property	US	REIT	https://www.marketscreener.com/quote/stock/VICI-PROPERTIES-INC-40580878/	https://finance.yahoo.com/quote/VICI?p=VICI&.tsrc=fin-srch	https://www.viciproperties.com	Landlord of Las Vegas	\N	\N	0.4000	2026	\N	USD	\N	\N	\N	Property	\N	.US	NY	^GSPC	VICI
VIE.PA	EPA:VIE	Veolia Environment	EnvironServices	FR	Indu	https://www.marketscreener.com/quote/stock/VEOLIA-ENVIRONNEMENT-4726/	https://finance.yahoo.com/quote/VIE.PA?p=VIE.PA&.tsrc=fin-srch	https://www.veolia.com	Environmental management (miljø- og affalds-service)	\N	\N	0.5000	2026	\N	EUR	\N	\N	\N	Other[Indu]	7	.PA	LON	^FCHI	VIE.PA
VIG	VIG	Dividend appreciation (ETF)	Diverse_na	US	na	http://www.marketscreener.com/VANGUARD-VANGUD-DI-29425436/	\N	\N	DGRO er alternativ til VIG	t	\N	0.4500	2026	\N	USD	\N	\N	\N	Diverse_na	\N	.US	NY	^GSPC	VIG
VIK	VIK	Viking Holdings	Holiday	US	C-Di	https://www.marketscreener.com/quote/stock/VIKING-HOLDINGS-LTD-169323809/	https://finance.yahoo.com/quote/VIK/	http://www.viking.com/	Luksus-rejser med oplevelser	\N	\N	\N	\N	\N	USD	\N	\N	\N	Holiday	\N	.US	NY	^GSPC	VIK
VIPS	VIPS	Vipshop (discounter China)	Retail	China	C-St	https://www.marketscreener.com/quote/stock/VIPSHOP-HOLDINGS-LIMITED-10246804/	https://finance.yahoo.com/quote/VIPS?p=VIPS&.tsrc=fin-srch	https://www.vip.com	Backed af Tencent og JD.com	\N	\N	0.3700	2026	\N	USD	\N	\N	\N	Retail	\N	.US	NY	^GSPC	VIPS
VITL-UN.TO	TSX:VITL.UN	Northwest Healthcare Properties	Property	CAN	REIT	https://www.marketscreener.com/quote/stock/NORTHWEST-HEALTHCARE-PROP-6500948/	https://finance.yahoo.com/quote/VITL-UN.TO?p=VITL-UN.TO&.tsrc=fin-srch	https://www.nwhp.ca	\N	t	\N	0.7900	2026	\N	CAD	\N	\N	\N	Property	\N	.TO	NY	^GSPC	VITL-UN.TO
VKTX	VKTX	Viking Therapeutics	Pharma	US	Heal	https://www.marketscreener.com/quote/stock/VIKING-THERAPEUTICS-INC-17937582/	https://finance.yahoo.com/quote/VKTX/	https://www.vikingtherapeutics.com	29 ansatte. Udfordrer Novo og Lilly	\N	\N	0.6300	2026	\N	USD	\N	\N	\N	Pharma	\N	.US	NY	^GSPC	VKTX
VOD.L	LON:VOD	Vodafone	Telecom	UK	Tele	https://www.marketscreener.com/quote/stock/VODAFONE-GROUP-PLC-15867071/	https://finance.yahoo.com/quote/VOD.L?p=VOD.L&.tsrc=fin-srch	https://www.vodafone.com	Verdens største teleselskab. 	\N	\N	0.5500	2026	\N	GBX	\N	\N	\N	Telecom	\N	.L	LON	^FTSE	VOD.L
VOLCAR-B.ST	STO:VOLCAR-B	Volvo Car	Automotive	SE	C-Di	https://www.marketscreener.com/quote/stock/VOLVO-CAR-AB-PUBL--128506374/	https://finance.yahoo.com/quote/VOLCAR-B.ST?p=VOLCAR-B.ST&.tsrc=fin-srch	https://www.volvocars.com	Biler. Moderselsk.: Geely	\N	\N	0.4400	2026	\N	SEK	\N	\N	\N	Automotive	\N	.ST	LON	^OMX	VOLCAR-B.ST
VOLV-B.ST	CPH:VOLV-B	Volvo B	Manuf_Special	SE	Indu	https://www.marketscreener.com/quote/stock/AB-VOLVO-6492152/	https://finance.yahoo.com/quote/VOLV-B.ST?p=VOLV-B.ST	https://www.volvogroup.com	Entreprenør-maskiner og lastbiler	t	\N	0.4700	2026	\N	SEK	\N	\N	\N	Manuf_Special	\N	.ST	LON	^OMX	VOLV-B.ST
VOW.DE	ETR:VOW	Volkswagen (common shares)	Automotive	DE	C-Di	https://www.marketscreener.com/quote/stock/VOLKSWAGEN-AG-56414516/	https://finance.yahoo.com/quote/VOW.DE?p=VOW.DE&.tsrc=fin-srch	https://www.volkswagen-group.com	u/stemmeret	\N	\N	0.2900	2026	\N	EUR	\N	\N	\N	Automotive	\N	.DE	LON	^GDAXI	VOW.DE
VOW3.DE	ETR:VOW3	Volkswagen (preferred)	Automotive	DE	C-Di	https://www.marketscreener.com/quote/stock/VOLKSWAGEN-AG-436737/	https://finance.yahoo.com/quote/VOW3.DE?p=VOW3.DE&.tsrc=fin-srch	https://www.volkswagen-group.com	Ca. 4,8% udb	\N	\N	0.2500	2026	\N	EUR	\N	\N	\N	Automotive	\N	.DE	LON	^GDAXI	VOW3.DE
VPN.L	LON:VPN	Global X Data Center REITs & Digital Infrastructure UCITS (Acc, USD)	Property	Intl	REIT	https://www.marketscreener.com/quote/etf/GLOBAL-X-DATA-CENTER-REIT-130552958/	https://finance.yahoo.com/quote/VPN.L/	https://www.globalxetfs.com/funds/dtcr	26 data centre. Top5: Equinix (14%), Digital Realty, American Tower, Crown Castle, Nextdc	\N	\N	0.4500	2026	\N	USD	\N	\N	\N	Property	\N	.L	LON	^FTSE	VPN.L
VRNS	VRNS	Varonis Technologies Hldg	Cybersecurity	US	Tech	https://www.marketscreener.com/quote/stock/VARONIS-SYSTEMS-INC-45013468/	https://finance.yahoo.com/quote/VRNS?p=VRNS&.tsrc=fin-srch	https://www.varonis.com	Hypervoksende. Net-security-software	\N	\N	0.5500	2026	\N	USD	\N	\N	\N	Cybersecurity	\N	.US	NY	^GSPC	VRNS
VRT	VRT	Vertiv	Electronics	US	Indu	https://www.marketscreener.com/quote/stock/VERTIV-HOLDINGS-CO-45109447/	https://finance.yahoo.com/quote/VRT/	https://www.vertiv.com	Specialsystemer til monitorering og styring af digital infrastructure	\N	\N	0.5500	2026	\N	USD	\N	AI-infrastruktur	\N	Electronics	\N	.US	NY	^GSPC	VRT
VRTX	VRTX	Vertex	Pharma	US	Heal	https://www.marketscreener.com/quote/stock/VERTEX-PHARMACEUTICALS-IN-11321/	https://finance.yahoo.com/quote/VRTX?p=VRTX&.tsrc=fin-srch	https://www.vrtx.com	Cystisk fibrose, nyresvigt og andre alvorlige sygdomme. 3400 ansatte.	t	\N	0.5500	2026	\N	USD	\N	\N	\N	Pharma	\N	.US	NY	^GSPC	VRTX
VST	VST	Vistra Corp	Util_MixedFuel	US	Util	https://www.marketscreener.com/quote/stock/VISTRA-CORP-34858180/	https://finance.yahoo.com/quote/VST/	http://vistracorp.com/	Electricity generation by gas, nuclear, solar etc. Sale in Texas and across US. 4870 ansatte, 41 MW. 	\N	\N	\N	\N	\N	USD	\N	AI-infrastruktur	\N	Util_MixedFuel	\N	.US	NY	^GSPC	VST
VTR	VTR	Ventas (Healthcare)	Property	US	REIT	https://www.marketscreener.com/quote/stock/VENTAS-INC-14836/	\N	https://www.ventasreit.com	\N	\N	\N	0.5500	2026	\N	USD	\N	\N	\N	Property	\N	.US	NY	^GSPC	VTR
VTRS	VTRS	Viatris (Upjohn+Mylan)	Pharma	US	Heal	https://www.marketscreener.com/quote/stock/VIATRIS-INC-115117632/	https://finance.yahoo.com/quote/VTRS?p=VTRS&.tsrc=fin-srch	https://www.viatris.com	\N	\N	\N	0.5900	2026	\N	USD	\N	\N	\N	Pharma	\N	.US	NY	^GSPC	VTRS
VTS	VTS	Vitesse Energy	Oil&Gas	US	Ener	https://www.marketscreener.com/quote/stock/VITESSE-ENERGY-INC-149076045/	https://finance.yahoo.com/quote/VTS/	http://vitesse-vts.com/	Eftersøgning efter olie og royalty-baseret udlicensering af produktion. IPO 1.9.23	\N	\N	0.6300	2026	\N	USD	\N	\N	\N	Oil&Gas	\N	.US	NY	^GSPC	VTS
VTY.L	LON:VTY	Vistry	ConstrHomes	UK	C-Di	https://www.marketscreener.com/quote/stock/VISTRY-GROUP-PLC-9590160/	https://finance.yahoo.com/quote/VTY.L/	http://www.vistrygroup.co.uk/	Største i socialt boligbyggeri i UK. 18000 enheder pr år.	\N	\N	0.4000	2026	\N	GBX	\N	\N	\N	ConstrHomes	\N	.L	LON	^FTSE	VTY.L
VWS.CO	CPH:VWS	Vestas	Rnwb(Indu)	DK	Indu	https://www.marketscreener.com/quote/stock/VESTAS-WIND-SYSTEMS-A-S-121357143/	https://finance.yahoo.com/quote/VWS.CO?p=VWS.CO&.tsrc=fin-srch	https://www.vestas.com	\N	t	\N	0.5000	2026	\N	DKK	\N	\N	\N	Rnwb(Indu)	\N	.CO	LON	^OMXC20	VWS.CO
VZ	VZ	Verizon	Telecom	US	Tele	https://www.marketscreener.com/quote/stock/VERIZON-COMMUNICATIONS-4830/	\N	https://www.verizon.com	\N	t	\N	0.2100	2026	\N	USD	\N	\N	\N	Telecom	\N	.US	NY	^GSPC	VZ
WB	WB	Weibo	TechToCons	China	Tech	https://www.marketscreener.com/quote/stock/WEIBO-CORPORATION-16300127/	\N	https://ir.weibo.com	SINA (og BABA) ejer reelt Weibo	\N	\N	0.5900	2026	\N	USD	\N	\N	\N	TechToCons	\N	.US	NY	^GSPC	WB
WBD	WBD	Warner Bros. Discovery	Media&Educ	US	C-Di	https://www.marketscreener.com/quote/stock/WARNER-BROS-DISCOVERY-I-136094563/	https://finance.yahoo.com/quote/WBDWV?p=WBDWV&.tsrc=fin-srch	https://www.wbd.com	Warner Media + Discovery (DISCA)	t	\N	0.4500	2026	\N	USD	\N	\N	\N	Media&Educ	\N	.US	NY	^GSPC	WBD
WCLD.L	LON:WCLD	WisdomTree Cloud Computing UCITS ETF - USD Acc	TechToProfs	UK	Tech	https://www.wisdomtree.eu/en-gb/etfs/thematic/wcld---wisdomtree-cloud-computing-ucits-etf---usd-acc	https://finance.yahoo.com/quote/WCLD.L?p=WCLD.L&.tsrc=fin-srch	\N	\N	t	\N	0.5600	2026	\N	USD	\N	\N	\N	TechToProfs	\N	.L	LON	^FTSE	WCLD.L
WDAY	WDAY	Workday	TechToProfs	US	Tech	https://www.marketscreener.com/quote/stock/WORKDAY-INC-37866670/	\N	https://www.workday.com	\N	\N	\N	0.6000	2026	\N	USD	\N	\N	\N	TechToProfs	\N	.US	NY	^GSPC	WDAY
WDH	WDH	Waterdrop	Insurance	China	Fina	https://www.marketscreener.com/quote/stock/WATERDROP-INC-122374816/	https://finance.yahoo.com/quote/WDH/	https://www.waterdrop-inc.com/	Digital insurance marketplace in China	\N	\N	0.6000	2026	\N	USD	\N	\N	\N	Insurance	\N	.US	NY	^GSPC	WDH
WELL	WELL	Welltower (Healthcare)	Property	US	REIT	https://www.marketscreener.com/quote/stock/WELLTOWER-INC-24156984/	\N	https://www.welltower.com	\N	\N	\N	0.4500	2026	\N	USD	\N	\N	\N	Property	\N	.US	NY	^GSPC	WELL
WEN	WEN	Wendy's	Restaurants	US	C-Di	https://www.marketscreener.com/quote/stock/THE-WENDY-S-COMPANY-9691436/	\N	https://www.wendys.com	\N	\N	\N	\N	\N	\N	USD	\N	\N	t	Restaurants	\N	.US	NY	^GSPC	WEN
WFC	WFC	Wells Fargo Bank	Bank	US	Fina	https://www.marketscreener.com/quote/stock/WELLS-FARGO-COMPANY-14861/	\N	https://www.wellsfargo.com	\N	\N	\N	0.3900	2026	\N	USD	\N	\N	\N	Bank	\N	.US	NY	^GSPC	WFC
WHR	WHR	Whirlpool corporation	ConstrHomes	US	C-Di	https://www.marketscreener.com/quote/stock/WHIRLPOOL-14872/	https://finance.yahoo.com/quote/WHR?p=WHR	https://www.whirlpoolcorp.com	Hvidevarer mv.	\N	\N	\N	\N	\N	USD	\N	\N	\N	ConstrHomes	\N	.US	NY	^GSPC	WHR
WING	WING	Wingstop	Restaurants	US	C-Di	https://www.marketscreener.com/quote/stock/WINGSTOP-INC-22448204/	https://finance.yahoo.com/quote/WING/	http://www.wingstop.com/	Chicken-wings mm. Globale ambitioner	\N	\N	\N	\N	\N	USD	\N	\N	\N	Restaurants	\N	.US	NY	^GSPC	WING
WISE.L	LON:WISE	Wise plc	Fintech	UK	Fina	https://www.marketscreener.com/quote/stock/WISE-PLC-124542474/	https://finance.yahoo.com/quote/WISE.L?p=WISE.L&.tsrc=fin-srch	https://www.wise.com	Global money transfer later expanded into multi-currency accounts and debit cards	\N	\N	\N	\N	\N	GBX	\N	\N	\N	Fintech	\N	.L	LON	^FTSE	WISE.L
WIX	WIX	Wix.Com	TechToProfs	US	Tech	https://www.marketscreener.com/quote/stock/WIX-COM-LTD-14825939/	\N	https://www.wix.com	\N	\N	\N	0.4000	2026	\N	USD	\N	\N	\N	TechToProfs	\N	.US	NY	^GSPC	WIX
WK	WK	Workiva 	TechToProfs	US	Tech	https://www.marketscreener.com/quote/stock/WORKIVA-INC-19157126/	https://finance.yahoo.com/quote/WK/	https://www.workiva.com	Regulatory (compliance) process automation	t	\N	0.4200	2026	\N	USD	\N	\N	\N	TechToProfs	\N	.US	NY	^GSPC	WK
WMB	WMB	Williams Companies	Oil&Gas	US	Ener	https://www.marketscreener.com/quote/stock/WILLIAMS-COMPANIES-14884/	https://finance.yahoo.com/quote/WMB?p=WMB&.tsrc=fin-srch	https://www.williams.com	Gas pipelines i US. Ligner Enbridge, men er pure play gas	\N	\N	\N	\N	\N	USD	\N	\N	\N	Oil&Gas	\N	.US	NY	^GSPC	WMB
WMT	WMT	Walmart	Retail	US	C-St	https://www.marketscreener.com/quote/stock/WALMART-INC-4841/	https://finance.yahoo.com/quote/WMT?p=WMT&.tsrc=fin-srch	https://www.corporate.walmart.com	Hypermarkets	\N	\N	\N	\N	\N	USD	\N	\N	\N	Retail	\N	.US	NY	^GSPC	WMT
WNUC.DE	ETR:WNUC	WisdomTree Uranium and Nuclear Energy UCITS ETF Acc - USD	Rnwb(Ener)	Intl	Ener	https://www.marketscreener.com/quote/etf/WISDOMTREE-URANIUM-AND-NU-184320741/	https://finance.yahoo.com/quote/WNUC.DE/	https://www.wisdomtree.eu/en-gb/etfs/thematic/nclr---wisdomtree-uranium-and-nuclear-energy-ucits-etf---usd-acc	60% af holdings er energiselskaber	t	\N	0.6000	2026	\N	EUR	\N	AI-infrastruktur	\N	Rnwb(Ener)	\N	.DE	LON	^GDAXI	WNUC.DE
WPC	WPC	WP Carey  (commercial bldgs)	Property	US	REIT	https://www.marketscreener.com/quote/stock/W-P-CAREY-INC-11613132/	\N	https://www.wpcarey.com	Triple-net-leases. Offices, retail centers, industrial facilities	\N	\N	0.5000	2026	\N	USD	\N	\N	\N	Property	\N	.US	NY	^GSPC	WPC
XDW0.L	LON:XDW0	Xtracker MSCI World Energy UCITS ETF 1C (USD)	Oil&Gas	Intl	Ener	https://etf.dws.com/sv-se/IE00BM67HM91-msci-world-energy-ucits-etf-1c/	https://finance.yahoo.com/quote/XDW0.L?p=XDW0.L&.tsrc=fin-srch	\N	IXC og IOGP.L er også mulgheder til at tracke Oil globalt	t	\N	0.4000	2026	\N	USD	\N	\N	\N	Oil&Gas	\N	.L	LON	^FTSE	XDW0.L
XHR	XHR	Xenia Hotels & Resorts	Property	US	REIT	https://www.marketscreener.com/quote/stock/XENIA-HOTELS-RESORTS-INC-20798727/	https://finance.yahoo.com/quote/XHR/	https://www.xeniareit.com/	Luxury and upper upscale hotels and resorts	\N	\N	0.4400	2026	\N	USD	\N	\N	\N	Property	\N	.US	NY	^GSPC	XHR
XNIF.L	LON:XNIF	Xtrackers Nifty 50 Swap UCITS ETF 1C (Acc, GBP)	Country	India	na	https://www.londonstockexchange.com/stock/XNIF/deutsche-bank/company-page	https://finance.yahoo.com/quote/XNIF.L/	\N	50 største indiske virksomheder trackes. Størst: HDFC Bank	\N	\N	0.3500	2026	\N	GBX	\N	\N	\N	Country	\N	.L	LON	^FTSE	XNIF.L
XOM	XOM	Exxon Mobile	Oil&Gas	US	Ener	https://www.marketscreener.com/quote/stock/EXXON-MOBIL-CORPORATION-4822/	\N	https://www.exxonmobil.com	\N	t	\N	0.2500	2026	\N	USD	\N	\N	\N	Oil&Gas	\N	.US	NY	^GSPC	XOM
XPEV	XPEV	XPeng	Automotive	China	C-Di	https://www.marketscreener.com/quote/stock/XPENG-INC-111319154/	https://finance.yahoo.com/quote/XPEV?p=XPEV&.tsrc=fin-srch	https://www.xpeng.com	\N	\N	\N	0.6200	2026	\N	USD	\N	\N	\N	Automotive	\N	.US	NY	^GSPC	XPEV
XRN	XRN	Chinon Real Estate (Global Medical REIT)	Property	US	REIT	https://www.marketscreener.com/quote/stock/CHIRON-REAL-ESTATE-INC-29159907/	https://finance.yahoo.com/quote/XRN/	https://www.globalmedicalreit.com	Leases those facilities to physician groups and regional and national healthcare systems in US	\N	\N	0.5500	2026	\N	USD	\N	\N	\N	Property	\N	.US	NY	^GSPC	XRN
XYF	XYF	X Financial	Fintech	US	Fina	https://www.marketscreener.com/quote/stock/X-FINANCIAL-46246571/	https://finance.yahoo.com/quote/XYF/	http://www.xiaoyinggroup.com/	Formidling af lån og investeringsmuligheder (kun Kina)	\N	\N	0.4500	2026	\N	USD	\N	\N	\N	Fintech	\N	.US	NY	^GSPC	XYF
XYL	XYL	Xylem (water and wastewater)	Manuf_Special	US	Indu	https://www.marketscreener.com/quote/stock/XYLEM-INC-9391714/	https://finance.yahoo.com/quote/XYL?p=XYL&.tsrc=fin-srch	https://www.xylem.com	Water and waste water infrastructure	\N	\N	0.4700	2026	\N	USD	\N	\N	\N	Manuf_Special	\N	.US	NY	^GSPC	XYL
XYZ	XYZ	Block (Square)	Fintech	US	Fina	https://www.marketscreener.com/quote/stock/BLOCK-INC-24935553/	https://finance.yahoo.com/quote/XYZ/	https://block.xyz	the bank of the future	\N	\N	0.6000	2026	\N	USD	\N	\N	\N	Fintech	\N	.US	NY	^GSPC	XYZ
YAR.OL	OSL:YAR	Yara Intl	Agro	NO	Basi	https://www.marketscreener.com/quote/stock/YARA-INTERNATIONAL-ASA-1413319/	https://finance.yahoo.com/quote/YAR.OL?p=YAR.OL&.tsrc=fin-srch	https://www.yara.com	Production and global sales of ammonium- and urea-based fertilizers. Equipment and solutions.	\N	\N	0.5500	2026	\N	NOK	\N	\N	\N	Agro	\N	.OL	LON	^OSEBX	YAR.OL
YUM	YUM	Yum Brands	Restaurants	US	C-Di	https://www.marketscreener.com/quote/stock/YUM-BRANDS-INC-46353249/	https://finance.yahoo.com/quote/YUM?p=YUM&.tsrc=fin-srch	https://www.yum.com	\N	\N	\N	0.4400	2026	\N	USD	\N	\N	\N	Restaurants	\N	.US	NY	^GSPC	YUM
ZAL.DE	ETR:ZAL	Zalando	TechToCons	DE	Tech	https://www.marketscreener.com/quote/stock/ZALANDO-SE-18100088/	\N	https://www.zalando.de	Distributør af sko og tøj. Europas no 1.	t	\N	0.3000	2026	\N	EUR	\N	\N	\N	TechToCons	\N	.DE	LON	^GDAXI	ZAL.DE
ZEAL.CO	CPH:ZEAL	Zealand Pharma	Pharma	DK	Heal	https://www.marketscreener.com/quote/stock/ZEALAND-PHARMA-A-S-6970764/	https://finance.yahoo.com/quote/ZEAL.CO?p=ZEAL.CO&.tsrc=fin-srch	https://www.zealandpharma.com	Peptid-baserede lægemidler	\N	\N	0.4000	2026	\N	DKK	\N	\N	\N	Pharma	\N	.CO	LON	^OMXC20	ZEAL.CO
ZETA	ZETA	Zeta Global Hdgs	TechToProfs	US	Tech	https://www.marketscreener.com/quote/stock/ZETA-GLOBAL-HOLDINGS-CORP-123552310/	https://finance.yahoo.com/quote/ZETA/	https://www.zetaglobal.com	AI til marketing aktiviteter i 15 verticals: Retail, financial services, telecom	t	\N	0.4200	2026	\N	USD	\N	\N	\N	TechToProfs	\N	.US	NY	^GSPC	ZETA
ZGN	ZGN	Ermenegildo Zegna	Luxury	IT	C-Di	https://www.marketscreener.com/quote/stock/ERMENEGILDO-ZEGNA-N-V-130945896/	https://finance.yahoo.com/quote/ZGN?p=ZGN&.tsrc=fin-srch	https://www.zegnagroup.com	Luksus-beklædning, især herretøj	\N	\N	0.4500	2026	\N	USD	\N	\N	\N	Luxury	\N	.US	NY	^GSPC	ZGN
ZIM	ZIM	ZIM Integrated Shipping Serv 	Trpt_Ship	Israel	Indu	https://www.marketscreener.com/quote/stock/ZIM-INTEGRATED-SHIPPING-S-118263450/	https://finance.yahoo.com/quote/ZIM?p=ZIM&.tsrc=fin-srch	https://www.zim.com	Cargo transp on all major global routes	t	\N	0.6000	2026	\N	USD	\N	\N	\N	Trpt_Ship	\N	.US	NY	^GSPC	ZIM
ZM	ZM	Zoom Communications	TechToProfs	US	Tech	https://www.marketscreener.com/quote/stock/ZOOM-VIDEO-COMMUNICATIONS-57086220/	\N	https://www.zoom.us	\N	\N	\N	\N	\N	\N	USD	\N	\N	\N	TechToProfs	\N	.US	NY	^GSPC	ZM
ZS	ZS	Zscaler	Cybersecurity	US	Tech	https://www.marketscreener.com/quote/stock/ZSCALER-INC-42379366/	\N	https://www.zscaler.com	Peers: Okta, ZS og Crowdstrike (CRWD)	\N	\N	\N	\N	\N	USD	\N	\N	\N	Cybersecurity	\N	.US	NY	^GSPC	ZS
ZURN.SW	SWX:ZURN	Zurich Insurance Group	Insurance	CH	Fina	https://www.marketscreener.com/quote/stock/ZURICH-INSURANCE-GROUP-LT-2955923/	https://finance.yahoo.com/quote/ZURN.SW/	https://www.zurich.com/	Alle slags forsikringer. Globalt. 63000 ansatte	\N	\N	\N	\N	\N	CHF	\N	\N	\N	Insurance	\N	.SW	LON	^STOXX	ZURN.SW
AAK.ST	STO:AAK	Aarhuskarlshamn	Food	SE	C-St	https://www.marketscreener.com/quote/stock/AAK-AB-44231497/	https://finance.yahoo.com/quote/AAK.ST	https://www.aak.com	Fremstiller vegetabilske olier. Specialist indenfor dette felt	\N	\N	\N	\N	\N	SEK	\N	\N	\N	Food	\N	.ST	LON	^OMX	AAK.ST
AAL	AAL	American Airlines	Trpt_Airline	US	Indu	https://www.marketscreener.com/quote/stock/AMERICAN-AIRLINES-GROUP-I-15171667/	https://www.aa.com/	https://www.aa.com	Airline	\N	\N	\N	\N	\N	USD	\N	\N	\N	Trpt_Airline	\N	.US	NY	^GSPC	AAL
AAL.L	LON:AAL	Anglo American	Mining	UK	Basi	https://www.marketscreener.com/quote/stock/ANGLO-AMERICAN-PLC-4007113/	https://finance.yahoo.com/quote/AAL.L?p=AAL.L&.tsrc=fin-srch	https://www.angloamerican.com	\N	t	\N	\N	\N	\N	GBX	\N	\N	\N	Mining	\N	.L	LON	^FTSE	AAL.L
AAON	AAON	AAON	Construction	US	Indu	https://www.marketscreener.com/quote/stock/AAON-INC-8199/	https://finance.yahoo.com/quote/AAON/	https://www.aaon.com	Fremstiller og sælger løsninger til køling og ventilation	\N	\N	\N	\N	\N	USD	\N	\N	\N	Construction	\N	.US	NY	^GSPC	AAON
AAP	AAP	Advance auto parts	Automotive	US	C-Di	https://www.marketscreener.com/quote/stock/ADVANCE-AUTO-PARTS-INC-11492/	https://finance.yahoo.com/quote/AAP?p=AAP&.tsrc=fin-srch	https://www.advanceautoparts.com	Autodele af enhver art	\N	\N	\N	\N	\N	USD	\N	\N	\N	Automotive	\N	.US	NY	^GSPC	AAP
AAPL	AAPL	Apple	TechToCons	US	Tech	https://www.marketscreener.com/quote/stock/APPLE-INC-4849/	https://finance.yahoo.com/quote/AAPL/	https://www.apple.com	\N	t	\N	\N	\N	\N	EUR	\N	Magni7	\N	TechToCons	\N	.US	NY	^GSPC	AAPL
\.


--
-- Data for Name: yfinance; Type: TABLE DATA; Schema: public; Owner: sm
--

COPY public.yfinance (ticker, fetched_date, currency, previous_close, current_price, dividend_rate, dividend_yield_pct, ex_div_date, pe_ttm, pe_fwd, ps_ttm, profit_margin, float_shares, book_value, pb, eps_ttm, eps_fwd, dividend_last, date_dividend_last, target_high_price, target_low_price, target_mean_price, target_median_price, recommendation_mean, recommendation_key, number_of_analysts, revenue_total, revenue_per_share, free_cash_flow, earnings_growth, revenue_growth, gross_margin, ebitda_margin, operating_margin, trailing_peg, full_time_employees) FROM stdin;
\.


--
-- Name: aux_deciles pk_aux_deciles; Type: CONSTRAINT; Schema: public; Owner: sm
--

ALTER TABLE ONLY public.aux_deciles
    ADD CONSTRAINT pk_aux_deciles PRIMARY KEY (indicator, decile);


--
-- Name: aux_win_loss pk_aux_win_loss; Type: CONSTRAINT; Schema: public; Owner: sm
--

ALTER TABLE ONLY public.aux_win_loss
    ADD CONSTRAINT pk_aux_win_loss PRIMARY KEY (daynum, ticker);


--
-- Name: cal pk_cal; Type: CONSTRAINT; Schema: public; Owner: sm
--

ALTER TABLE ONLY public.cal
    ADD CONSTRAINT pk_cal PRIMARY KEY (daynum);


--
-- Name: longi pk_longi; Type: CONSTRAINT; Schema: public; Owner: sm
--

ALTER TABLE ONLY public.longi
    ADD CONSTRAINT pk_longi PRIMARY KEY (ticker, daynum, indicator);


--
-- Name: longi_grp pk_longi_grp; Type: CONSTRAINT; Schema: public; Owner: sm
--

ALTER TABLE ONLY public.longi_grp
    ADD CONSTRAINT pk_longi_grp PRIMARY KEY (group_label, daynum, indicator);


--
-- Name: prices pk_prices; Type: CONSTRAINT; Schema: public; Owner: sm
--

ALTER TABLE ONLY public.prices
    ADD CONSTRAINT pk_prices PRIMARY KEY (ticker, daynum);


--
-- Name: stocks pk_stocks; Type: CONSTRAINT; Schema: public; Owner: sm
--

ALTER TABLE ONLY public.stocks
    ADD CONSTRAINT pk_stocks PRIMARY KEY (ticker);


--
-- Name: yfinance pk_yfinance; Type: CONSTRAINT; Schema: public; Owner: sm
--

ALTER TABLE ONLY public.yfinance
    ADD CONSTRAINT pk_yfinance PRIMARY KEY (ticker, fetched_date);


--
-- Name: cal uq_cal_date; Type: CONSTRAINT; Schema: public; Owner: sm
--

ALTER TABLE ONLY public.cal
    ADD CONSTRAINT uq_cal_date UNIQUE (date);


--
-- Name: ix_aux_win_loss_ticker; Type: INDEX; Schema: public; Owner: sm
--

CREATE INDEX ix_aux_win_loss_ticker ON public.aux_win_loss USING btree (ticker);


--
-- Name: ix_longi_daynum; Type: INDEX; Schema: public; Owner: sm
--

CREATE INDEX ix_longi_daynum ON public.longi USING btree (daynum);


--
-- Name: ix_longi_grp_daynum; Type: INDEX; Schema: public; Owner: sm
--

CREATE INDEX ix_longi_grp_daynum ON public.longi_grp USING btree (daynum);


--
-- Name: ix_longi_grp_indicator; Type: INDEX; Schema: public; Owner: sm
--

CREATE INDEX ix_longi_grp_indicator ON public.longi_grp USING btree (indicator);


--
-- Name: ix_longi_grp_label; Type: INDEX; Schema: public; Owner: sm
--

CREATE INDEX ix_longi_grp_label ON public.longi_grp USING btree (group_label);


--
-- Name: ix_longi_indicator; Type: INDEX; Schema: public; Owner: sm
--

CREATE INDEX ix_longi_indicator ON public.longi USING btree (indicator);


--
-- Name: ix_longi_ticker; Type: INDEX; Schema: public; Owner: sm
--

CREATE INDEX ix_longi_ticker ON public.longi USING btree (ticker);


--
-- Name: ix_prices_daynum; Type: INDEX; Schema: public; Owner: sm
--

CREATE INDEX ix_prices_daynum ON public.prices USING btree (daynum);


--
-- Name: ix_prices_ticker; Type: INDEX; Schema: public; Owner: sm
--

CREATE INDEX ix_prices_ticker ON public.prices USING btree (ticker);


--
-- Name: ix_yfinance_fetched; Type: INDEX; Schema: public; Owner: sm
--

CREATE INDEX ix_yfinance_fetched ON public.yfinance USING btree (fetched_date);


--
-- Name: ix_yfinance_ticker; Type: INDEX; Schema: public; Owner: sm
--

CREATE INDEX ix_yfinance_ticker ON public.yfinance USING btree (ticker);


--
-- Name: aux_win_loss fk_aux_win_loss_daynum; Type: FK CONSTRAINT; Schema: public; Owner: sm
--

ALTER TABLE ONLY public.aux_win_loss
    ADD CONSTRAINT fk_aux_win_loss_daynum FOREIGN KEY (daynum) REFERENCES public.cal(daynum);


--
-- Name: longi fk_longi_daynum; Type: FK CONSTRAINT; Schema: public; Owner: sm
--

ALTER TABLE ONLY public.longi
    ADD CONSTRAINT fk_longi_daynum FOREIGN KEY (daynum) REFERENCES public.cal(daynum);


--
-- Name: longi_grp fk_longi_grp_daynum; Type: FK CONSTRAINT; Schema: public; Owner: sm
--

ALTER TABLE ONLY public.longi_grp
    ADD CONSTRAINT fk_longi_grp_daynum FOREIGN KEY (daynum) REFERENCES public.cal(daynum);


--
-- Name: prices fk_prices_daynum; Type: FK CONSTRAINT; Schema: public; Owner: sm
--

ALTER TABLE ONLY public.prices
    ADD CONSTRAINT fk_prices_daynum FOREIGN KEY (daynum) REFERENCES public.cal(daynum);


--
-- Name: SCHEMA public; Type: ACL; Schema: -; Owner: pg_database_owner
--

GRANT ALL ON SCHEMA public TO sm;


--
-- PostgreSQL database dump complete
--

\unrestrict 2h4FsPUy2nnSLfGk4j21taq5CksF7rN2MKL4tY9IP8QFXTlipidGCCz4Fvnyyx1

